﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;
using InventoryManagement.DataAccessLogic;

namespace InventoryManagement
{
    public partial class frmUser : Form
    {
        UserModel objUserModel = null;
        IGenericRepository<UserModel> objUserDal = null;
        IGenericRepository<CompanyModel> objCompanyDal = null;

        public frmUser()
        {
            InitializeComponent();
        }

        private void frmUser_Load(object sender, EventArgs e)
        {
            objUserDal = new UserDAL();
            objCompanyDal = new CompanyDAL();

            cboCompany.DataSource = objCompanyDal.GetAll();
            cboCompany.ValueMember = "Code";
            cboCompany.DisplayMember = "Name";
            
            ClearFields();
            txtFirstName.Select();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtFirstName.Text.Trim() == "")
            {
                txtFirstName.Focus();
                MessageBox.Show("Please enter first name.", common.strProjectTitle, MessageBoxButtons.OK,MessageBoxIcon.Stop);
            }
            else if (txtLastName.Text.Trim() == "")
            {
                txtLastName.Focus();
                MessageBox.Show("Please enter last name.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtUserId.Text.Trim() == "")
            {
                txtUserId.Focus();
                MessageBox.Show("Please enter user id.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtPassword.Text.Trim() == "")
            {
                txtPassword.Focus();
                MessageBox.Show("Please enter password.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtMobile.Text.Trim() == "")
            {
                txtMobile.Focus();
                MessageBox.Show("Please enter mobile.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtEmail.Text.Trim() == "")
            {
                txtEmail.Focus();
                MessageBox.Show("Please enter email.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (cboRole.Text.Trim() == "Select")
            {
                cboRole.Focus();
                MessageBox.Show("Please select role.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (cboStatus.Text.Trim() == "Select")
            {
                cboStatus.Focus();
                MessageBox.Show("Please select status.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (cboCompany.Text.Trim() == "")
            {
                cboCompany.Focus();
                MessageBox.Show("Please select company name.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                Cursor = Cursors.WaitCursor;
                objUserModel = new UserModel();
                objUserModel.FirstName = txtFirstName.Text.Trim();
                objUserModel.LastName = txtLastName.Text.Trim();
                objUserModel.UserID = txtUserId.Text.Trim();
                objUserModel.Password = common.EncryptString(common.strKey, txtPassword.Text.Trim());
                objUserModel.Mobile = txtMobile.Text.Trim();
                objUserModel.Email = txtEmail.Text.Trim();
                objUserModel.Role = cboRole.Text.Trim();
                objUserModel.CompanyCode = cboCompany.SelectedValue.ToString();
                objUserModel.IsActive = cboStatus.Text.Trim();
                objUserModel.CreatedBy = common.strUserEmail;

                if (btnSave.Text == "Save")
                {
                    objUserModel.Code = 0;
                    objUserDal.Add(objUserModel);
                    ClearFields();
                    //MessageBox.Show("User details saved successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    objUserModel.Code = Convert.ToInt32(txtCode.Text);
                    objUserDal.Update(objUserModel);
                    ClearFields();
                    //MessageBox.Show("User details updated successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Cursor = Cursors.Default;
            }
        }
    
        private void ClearFields()
        {
            txtCode.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtUserId.Text = "";
            txtPassword.Text = "";
            txtMobile.Text = "";
            txtEmail.Text = "";
            cboRole.SelectedIndex = 0;
            cboStatus.SelectedIndex = 0;
            cboCompany.SelectedIndex = -1;
            dgvData.Enabled = true;
            btnSave.Text = "Save";
            DisplayData();
            txtFirstName.Focus();
        }

        private void DisplayData()
        {
            List<UserModel> lstFilteredData = null;
            List<UserModel> lstFilteredData1 = null;

            List<UserModel> lstData = objUserDal.GetAll();
            
            if (txtFirstNameSearch.Text != "")
            {
                lstFilteredData = lstData.Where(x => x.FirstName.Contains(txtFirstNameSearch.Text)).ToList();
            }
            else
            {
                lstFilteredData = lstData;
            }

            if (txtLastNameSearch.Text != "")
            {
                lstFilteredData1 = lstFilteredData.Where(x => x.LastName.Contains(txtLastNameSearch.Text)).ToList();
            }
            else
            {
                lstFilteredData1 = lstFilteredData;
            }
            
            dgvData.DataSource = lstFilteredData1;
        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (e.ColumnIndex == 0)
                {
                    txtCode.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["CustomerCode"].Value);
                    txtFirstName.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["FirstName"].Value);
                    txtLastName.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["LastName"].Value);
                    txtUserId.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["UserID"].Value);
                    txtPassword.Text = common.DecryptString(common.strKey, Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Password"].Value));
                    txtMobile.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Mobile"].Value);
                    txtEmail.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Email"].Value);
                    cboRole.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Role"].Value);
                    cboStatus.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Status"].Value);
                    cboCompany.SelectedValue = Convert.ToInt32(dgvData.Rows[e.RowIndex].Cells["CompanyCode"].Value);
                    
                    btnSave.Text = "Update";
                    dgvData.Enabled = false;
                    txtFirstName.Focus();
                }
                if (e.ColumnIndex == 1)
                {
                    if (MessageBox.Show("Do you want to delete?", common.strProjectTitle, MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        Int32 code = Convert.ToInt32(dgvData.Rows[e.RowIndex].Cells["CustomerCode"].Value);
                        objUserDal.Delete(code);

                        ClearFields();
                        //MessageBox.Show("User details deleted successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }            
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtFirstNameSearch_TextChanged(object sender, EventArgs e)
        {
            DisplayData();
        }

        private void txtLastNameSearch_TextChanged(object sender, EventArgs e)
        {
            DisplayData();
        }
    }
}
