﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;
using InventoryManagement.DataAccessLogic;

namespace InventoryManagement
{
    public partial class frmEmployee : Form
    {
        EmployeeModel objEmployeeModel = null;
        IGenericRepository<EmployeeModel> objEmployeeDal = null;

        public frmEmployee()
        {
            InitializeComponent();
        }

        private void frmCustomer_Load(object sender, EventArgs e)
        {
            objEmployeeDal = new EmployeeDAL();
            ClearFields();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (txtName.Text.Trim() == "")
            {
                txtName.Focus();
                MessageBox.Show("Please enter name.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtEmail.Text.Trim() == "")
            {
                txtEmail.Focus();
                MessageBox.Show("Please enter email.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtPhone.Text.Trim() == "")
            {
                txtPhone.Focus();
                MessageBox.Show("Please enter phone.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtDepartment.Text.Trim() == "")
            {
                txtDepartment.Focus();
                MessageBox.Show("Please enter department.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtDesignation.Text.Trim() == "")
            {
                txtDesignation.Focus();
                MessageBox.Show("Please enter designation.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtSalary.Text.Trim() == "")
            {
                txtSalary.Focus();
                MessageBox.Show("Please enter salary.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (cboStatus.Text.Trim() == "Select")
            {
                cboStatus.Focus();
                MessageBox.Show("Please select status.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                Cursor = Cursors.WaitCursor;
                objEmployeeModel = new EmployeeModel();
                objEmployeeModel.EmployeeName = txtName.Text.Trim();
                objEmployeeModel.Email= txtEmail.Text.Trim();
                objEmployeeModel.Phone = txtPhone.Text.Trim();
                objEmployeeModel.Department = txtDepartment.Text.Trim();
                objEmployeeModel.Designation = txtDesignation.Text.Trim();
                objEmployeeModel.Status = cboStatus.Text.Trim();
                objEmployeeModel.Salary = txtSalary.Text.Trim();
                objEmployeeModel.JoinDate = dtpJoinDate.Text.Trim();
                objEmployeeModel.CreatedBy = common.strUserEmail;

                if (btnSave.Text == "Save")
                {
                    objEmployeeDal.Add(objEmployeeModel);
                    ClearFields();
                    //MessageBox.Show("Employee saved successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    objEmployeeModel.EmployeeID = Convert.ToString(txtCode.Text);
                    objEmployeeDal.Update(objEmployeeModel);
                    ClearFields();
                    //MessageBox.Show("Employee updated successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Cursor = Cursors.Default;
            }
        }

        private void ClearFields()
        {
            dtpJoinDate.Value = Convert.ToDateTime(DateTime.Now.ToString("dd-MMM-yyyy"));
            txtCode.Text = "";
            txtName.Text = "";
            txtEmail.Text = "";
            txtPhone.Text = "";
            txtDepartment.Text = "";
            txtDesignation.Text = "";
            txtSalary.Text = "";
            btnSave.Text = "Save";
            cboStatus.SelectedIndex = 0;
            dgvData.Enabled = true;
            txtName.Select();
            DisplayData();            
        }

        private void DisplayData()
        {
            List<EmployeeModel> lstFilteredData = null;
            List<EmployeeModel> lstData = objEmployeeDal.GetAll();

            if (txtNameSearch.Text != "")
            {
                lstFilteredData = lstData.Where(x => x.EmployeeName.Contains(txtNameSearch.Text)).ToList();
            }
            else
            {
                lstFilteredData = lstData;
            }

            dgvData.DataSource = lstFilteredData;
        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (e.ColumnIndex == 0)
                {
                    if (common.strUserRole == "Admin")
                    {
                        txtCode.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Code"].Value);
                        txtName.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["EmployeeName"].Value);
                        txtEmail.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Email"].Value);
                        txtPhone.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Phone"].Value);
                        txtDepartment.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Department"].Value);
                        txtDesignation.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Designation"].Value);
                        dtpJoinDate.Value = Convert.ToDateTime(dgvData.Rows[e.RowIndex].Cells["JoinDate"].Value);
                        txtSalary.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Salary"].Value);
                        cboStatus.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Status"].Value);

                        btnSave.Text = "Update";
                        dgvData.Enabled = false;
                        txtName.Select();
                    }
                    else
                    {
                        MessageBox.Show("You do not have appropriate permission for this action.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                if (e.ColumnIndex == 1)
                {
                    if (common.strUserRole == "Admin")
                    {
                        if (MessageBox.Show("Do you want to delete?", common.strProjectTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            Int32 code = Convert.ToInt32(dgvData.Rows[e.RowIndex].Cells["Code"].Value);
                            objEmployeeDal.Delete(code);

                            ClearFields();

                            //MessageBox.Show("Employee deleted successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MessageBox.Show("You do not have appropriate permission for this action.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtNameSearch_TextChanged(object sender, EventArgs e)
        {
            DisplayData();
        }
    }
}
