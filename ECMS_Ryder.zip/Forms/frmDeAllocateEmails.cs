using System;
using ECMS_Ryder.HelperClasses;
using System.Windows.Forms;
using ECMS_Ryder.Repositories;
using System.Collections.Generic;
using ECMS_Ryder.Models;
using System.Linq;

namespace ECMS_Ryder.Forms
{
    public partial class frmDeAllocateEmails : Form
    {
        private readonly EmailDetailsRepository objEmailDetailsRepository;
        List<EmailDetails> allAssignedEmails = null;
        List<UserDetails> allUsers = null;

        public frmDeAllocateEmails()
        {
            InitializeComponent();

            objEmailDetailsRepository = new EmailDetailsRepository(clsDBConnection.strConnectionString);
        }

        private void frmAssignEmails_Load(object sender, EventArgs e)
        {
            RefreshGrid();        
            ClearAll();
        }

        private void ClearAll()
        {
            cmbSearchCriteria.SelectedIndex = 0;
            txtSearchText.Text = "";
            chkSelectAll.Checked = false;
        }

        private void RefreshGrid()
        {
            allAssignedEmails = new List<EmailDetails>();
            allAssignedEmails = objEmailDetailsRepository.GetAssignedEmailsAdmin();
            dgvEmails.DataSource = allAssignedEmails;
            lblEmailsCount.Text = allAssignedEmails.Count.ToString();
        }

        private void txtSearchText_TextChanged(object sender, EventArgs e)
        {
            if (cmbSearchCriteria.SelectedIndex == 0)
            {
                MessageBox.Show("Select search criteria first and then try.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                cmbSearchCriteria.Focus();
                return;
            }

            this.Cursor = Cursors.WaitCursor;

            List<EmailDetails> filteredEmails = new List<EmailDetails>();

            if (cmbSearchCriteria.Text == "SenderName")
            {                
                filteredEmails = (from emails in allAssignedEmails where emails.SenderName.ToLower().Contains(txtSearchText.Text.Trim()) select emails).ToList();
            }
            else if (cmbSearchCriteria.Text == "To")
            {
                filteredEmails = (from emails in allAssignedEmails where emails.To.ToLower().Contains(txtSearchText.Text.Trim()) select emails).ToList();
            }
            else if (cmbSearchCriteria.Text == "Cc")
            {
                filteredEmails = (from emails in allAssignedEmails where emails.Cc.ToLower().Contains(txtSearchText.Text.Trim()) select emails).ToList();
            }
            else if (cmbSearchCriteria.Text == "Bcc")
            {
                filteredEmails = (from emails in allAssignedEmails where emails.Bcc.ToLower().Contains(txtSearchText.Text.Trim()) select emails).ToList();
            }
            else if (cmbSearchCriteria.Text == "Subject")
            {
                filteredEmails = (from emails in allAssignedEmails where emails.Subject.ToLower().Contains(txtSearchText.Text.Trim()) select emails).ToList();
            }
            else
            {
                filteredEmails = allAssignedEmails;
            }

            dgvEmails.DataSource = filteredEmails;
            
            this.Cursor = Cursors.Default;
        }

        private void btnAssignEmails_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;

            List<EmailDetails> emails = new List<EmailDetails>();
            EmailDetails email = null;

            foreach (DataGridViewRow row in dgvEmails.Rows)
            {
                DataGridViewCheckBoxCell chk = (DataGridViewCheckBoxCell)row.Cells[0];
                if (Convert.ToBoolean(chk.Value) == true)
                {
                    email = new EmailDetails();
                    email.EmailDetailsId = Convert.ToInt32(row.Cells[1].Value);
                    emails.Add(email);
                }
            }

            if (emails.Count > 0)
            {
                objEmailDetailsRepository.DeAllocateEmails(emails);
                RefreshGrid();
                MessageBox.Show("Emails are De-Allocated successfully.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            Cursor = Cursors.Default;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearAll();
        }

        private void chkSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            if (!chkSelectAll.Checked)
            {
                if (dgvEmails.Rows.Count > 0)
                {
                    foreach (DataGridViewRow row in dgvEmails.Rows)
                    {
                        DataGridViewCheckBoxCell chk = (DataGridViewCheckBoxCell)row.Cells[0];
                        chk.Value = false;
                    }
                }
            }
            else
            {
                if (dgvEmails.Rows.Count > 0)
                {
                    foreach (DataGridViewRow row in dgvEmails.Rows)
                    {
                        DataGridViewCheckBoxCell chk = (DataGridViewCheckBoxCell)row.Cells[0];
                        chk.Value = true;
                    }
                }
            }
        }
    }
}
