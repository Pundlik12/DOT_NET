﻿
namespace InventoryManagement.BusinessLogic
{
    public class PaymentModel
    {
        public int Code { get; set; }
        public string ChallanNo { get; set; }
        public string TrnDate { get; set; }
        public string Mode { get; set; }
        public string Amount { get; set; }
        public string Remarks { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDateTime { get; set; }
    }
}
