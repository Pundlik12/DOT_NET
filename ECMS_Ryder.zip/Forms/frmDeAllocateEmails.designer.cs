﻿using System.Drawing;
using System.Windows.Forms;

namespace ECMS_Ryder.Forms
{
    partial class frmDeAllocateEmails
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblEmailsCount = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSearchText = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbSearchCriteria = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnAssignEmails = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chkSelectAll = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dgvEmails = new System.Windows.Forms.DataGridView();
            this.ChkSelect = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.EmailDetailsId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmailAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FolderName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Subject = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Priority = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HasAttachments = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReceivedTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SenderName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SenderEmailAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.To = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Bcc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Body = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EntryID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ConversationID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SyncBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SyncDateTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastUpdatedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastUpdatedDateTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssignTo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssignedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssignedDateTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmails)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1437, 53);
            this.label1.TabIndex = 0;
            this.label1.Text = "De-Allocate Outlook Emails";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblEmailsCount);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtSearchText);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.cmbSearchCriteria);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(0, 53);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(1437, 83);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Search Emails";
            // 
            // lblEmailsCount
            // 
            this.lblEmailsCount.AutoSize = true;
            this.lblEmailsCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailsCount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblEmailsCount.Location = new System.Drawing.Point(1355, 34);
            this.lblEmailsCount.Name = "lblEmailsCount";
            this.lblEmailsCount.Size = new System.Drawing.Size(26, 29);
            this.lblEmailsCount.TabIndex = 9;
            this.lblEmailsCount.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1176, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 29);
            this.label2.TabIndex = 8;
            this.label2.Text = "Emails Count:-";
            // 
            // txtSearchText
            // 
            this.txtSearchText.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchText.Location = new System.Drawing.Point(672, 30);
            this.txtSearchText.Name = "txtSearchText";
            this.txtSearchText.Size = new System.Drawing.Size(481, 38);
            this.txtSearchText.TabIndex = 3;
            this.txtSearchText.TextChanged += new System.EventHandler(this.txtSearchText_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(537, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 25);
            this.label5.TabIndex = 2;
            this.label5.Text = "Search Text:-";
            // 
            // cmbSearchCriteria
            // 
            this.cmbSearchCriteria.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSearchCriteria.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSearchCriteria.FormattingEnabled = true;
            this.cmbSearchCriteria.Items.AddRange(new object[] {
            "Select",
            "SenderName",
            "To",
            "Cc",
            "Bcc",
            "Subject"});
            this.cmbSearchCriteria.Location = new System.Drawing.Point(229, 30);
            this.cmbSearchCriteria.Name = "cmbSearchCriteria";
            this.cmbSearchCriteria.Size = new System.Drawing.Size(292, 33);
            this.cmbSearchCriteria.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(111, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 25);
            this.label4.TabIndex = 0;
            this.label4.Text = "Search on:-";
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(372, 26);
            this.btnClear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(144, 47);
            this.btnClear.TabIndex = 6;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnAssignEmails
            // 
            this.btnAssignEmails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnAssignEmails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAssignEmails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAssignEmails.Location = new System.Drawing.Point(150, 26);
            this.btnAssignEmails.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAssignEmails.Name = "btnAssignEmails";
            this.btnAssignEmails.Size = new System.Drawing.Size(216, 47);
            this.btnAssignEmails.TabIndex = 5;
            this.btnAssignEmails.Text = "De-Allocate Emails";
            this.btnAssignEmails.UseVisualStyleBackColor = false;
            this.btnAssignEmails.Click += new System.EventHandler(this.btnAssignEmails_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.chkSelectAll);
            this.groupBox2.Controls.Add(this.btnClear);
            this.groupBox2.Controls.Add(this.btnAssignEmails);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(0, 667);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(1437, 82);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Assign Emails";
            // 
            // chkSelectAll
            // 
            this.chkSelectAll.AutoSize = true;
            this.chkSelectAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkSelectAll.Location = new System.Drawing.Point(10, 36);
            this.chkSelectAll.Name = "chkSelectAll";
            this.chkSelectAll.Size = new System.Drawing.Size(116, 29);
            this.chkSelectAll.TabIndex = 0;
            this.chkSelectAll.Text = "Select All";
            this.chkSelectAll.UseVisualStyleBackColor = true;
            this.chkSelectAll.CheckedChanged += new System.EventHandler(this.chkSelectAll_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dgvEmails);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(0, 136);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Size = new System.Drawing.Size(1437, 527);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Emails";
            // 
            // dgvEmails
            // 
            this.dgvEmails.AllowUserToAddRows = false;
            this.dgvEmails.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEmails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvEmails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ChkSelect,
            this.EmailDetailsId,
            this.EmailAddress,
            this.FolderName,
            this.Subject,
            this.Priority,
            this.HasAttachments,
            this.ReceivedTime,
            this.SenderName,
            this.SenderEmailAddress,
            this.To,
            this.CC,
            this.Bcc,
            this.Body,
            this.EntryID,
            this.ConversationID,
            this.Status,
            this.SyncBy,
            this.SyncDateTime,
            this.LastUpdatedBy,
            this.LastUpdatedDateTime,
            this.AssignTo,
            this.AssignedBy,
            this.AssignedDateTime});
            this.dgvEmails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvEmails.Location = new System.Drawing.Point(3, 22);
            this.dgvEmails.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvEmails.MultiSelect = false;
            this.dgvEmails.Name = "dgvEmails";
            this.dgvEmails.RowHeadersVisible = false;
            this.dgvEmails.RowHeadersWidth = 51;
            this.dgvEmails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEmails.Size = new System.Drawing.Size(1431, 503);
            this.dgvEmails.TabIndex = 0;
            // 
            // ChkSelect
            // 
            this.ChkSelect.HeaderText = "Select";
            this.ChkSelect.MinimumWidth = 6;
            this.ChkSelect.Name = "ChkSelect";
            this.ChkSelect.Width = 62;
            // 
            // EmailDetailsId
            // 
            this.EmailDetailsId.DataPropertyName = "EmailDetailsId";
            this.EmailDetailsId.HeaderText = "EmailId";
            this.EmailDetailsId.MinimumWidth = 6;
            this.EmailDetailsId.Name = "EmailDetailsId";
            this.EmailDetailsId.ReadOnly = true;
            this.EmailDetailsId.Width = 93;
            // 
            // EmailAddress
            // 
            this.EmailAddress.DataPropertyName = "EmailAddress";
            this.EmailAddress.HeaderText = "Email Address";
            this.EmailAddress.MinimumWidth = 6;
            this.EmailAddress.Name = "EmailAddress";
            this.EmailAddress.ReadOnly = true;
            this.EmailAddress.Width = 135;
            // 
            // FolderName
            // 
            this.FolderName.DataPropertyName = "FolderName";
            this.FolderName.HeaderText = "Folder Name";
            this.FolderName.MinimumWidth = 6;
            this.FolderName.Name = "FolderName";
            this.FolderName.ReadOnly = true;
            this.FolderName.Width = 123;
            // 
            // Subject
            // 
            this.Subject.DataPropertyName = "Subject";
            this.Subject.HeaderText = "Subject";
            this.Subject.MinimumWidth = 6;
            this.Subject.Name = "Subject";
            this.Subject.ReadOnly = true;
            this.Subject.Width = 94;
            // 
            // Priority
            // 
            this.Priority.DataPropertyName = "Priority";
            this.Priority.HeaderText = "Priority";
            this.Priority.MinimumWidth = 6;
            this.Priority.Name = "Priority";
            this.Priority.ReadOnly = true;
            this.Priority.Width = 91;
            // 
            // HasAttachments
            // 
            this.HasAttachments.DataPropertyName = "HasAttachments";
            this.HasAttachments.HeaderText = "Has Attachments";
            this.HasAttachments.MinimumWidth = 6;
            this.HasAttachments.Name = "HasAttachments";
            this.HasAttachments.ReadOnly = true;
            this.HasAttachments.Width = 154;
            // 
            // ReceivedTime
            // 
            this.ReceivedTime.DataPropertyName = "ReceivedTime";
            this.ReceivedTime.HeaderText = "Received Time";
            this.ReceivedTime.MinimumWidth = 6;
            this.ReceivedTime.Name = "ReceivedTime";
            this.ReceivedTime.ReadOnly = true;
            this.ReceivedTime.Width = 137;
            // 
            // SenderName
            // 
            this.SenderName.DataPropertyName = "SenderName";
            this.SenderName.HeaderText = "Sender Name";
            this.SenderName.MinimumWidth = 6;
            this.SenderName.Name = "SenderName";
            this.SenderName.ReadOnly = true;
            this.SenderName.Width = 128;
            // 
            // SenderEmailAddress
            // 
            this.SenderEmailAddress.DataPropertyName = "SenderEmailAddress";
            this.SenderEmailAddress.HeaderText = "Sender Email Address";
            this.SenderEmailAddress.MinimumWidth = 6;
            this.SenderEmailAddress.Name = "SenderEmailAddress";
            this.SenderEmailAddress.ReadOnly = true;
            this.SenderEmailAddress.Width = 187;
            // 
            // To
            // 
            this.To.DataPropertyName = "To";
            this.To.HeaderText = "To";
            this.To.MinimumWidth = 6;
            this.To.Name = "To";
            this.To.ReadOnly = true;
            this.To.Width = 57;
            // 
            // CC
            // 
            this.CC.DataPropertyName = "CC";
            this.CC.HeaderText = "CC";
            this.CC.MinimumWidth = 6;
            this.CC.Name = "CC";
            this.CC.ReadOnly = true;
            this.CC.Width = 62;
            // 
            // Bcc
            // 
            this.Bcc.DataPropertyName = "Bcc";
            this.Bcc.HeaderText = "Bcc";
            this.Bcc.MinimumWidth = 6;
            this.Bcc.Name = "Bcc";
            this.Bcc.ReadOnly = true;
            this.Bcc.Width = 68;
            // 
            // Body
            // 
            this.Body.DataPropertyName = "Body";
            this.Body.HeaderText = "Body";
            this.Body.MinimumWidth = 6;
            this.Body.Name = "Body";
            this.Body.ReadOnly = true;
            this.Body.Width = 76;
            // 
            // EntryID
            // 
            this.EntryID.DataPropertyName = "EntryID";
            this.EntryID.HeaderText = "Entry ID";
            this.EntryID.MinimumWidth = 6;
            this.EntryID.Name = "EntryID";
            this.EntryID.ReadOnly = true;
            this.EntryID.Width = 92;
            // 
            // ConversationID
            // 
            this.ConversationID.DataPropertyName = "ConversationID";
            this.ConversationID.HeaderText = "Conversation ID";
            this.ConversationID.MinimumWidth = 6;
            this.ConversationID.Name = "ConversationID";
            this.ConversationID.ReadOnly = true;
            this.ConversationID.Width = 145;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.MinimumWidth = 6;
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.Width = 86;
            // 
            // SyncBy
            // 
            this.SyncBy.DataPropertyName = "SyncBy";
            this.SyncBy.HeaderText = "Sync By";
            this.SyncBy.MinimumWidth = 6;
            this.SyncBy.Name = "SyncBy";
            this.SyncBy.ReadOnly = true;
            this.SyncBy.Width = 92;
            // 
            // SyncDateTime
            // 
            this.SyncDateTime.DataPropertyName = "SyncDateTime";
            this.SyncDateTime.HeaderText = "Sync DateTime";
            this.SyncDateTime.MinimumWidth = 6;
            this.SyncDateTime.Name = "SyncDateTime";
            this.SyncDateTime.ReadOnly = true;
            this.SyncDateTime.Width = 140;
            // 
            // LastUpdatedBy
            // 
            this.LastUpdatedBy.DataPropertyName = "LastUpdatedBy";
            this.LastUpdatedBy.HeaderText = "Last Updated By";
            this.LastUpdatedBy.MinimumWidth = 6;
            this.LastUpdatedBy.Name = "LastUpdatedBy";
            this.LastUpdatedBy.ReadOnly = true;
            this.LastUpdatedBy.Width = 131;
            // 
            // LastUpdatedDateTime
            // 
            this.LastUpdatedDateTime.DataPropertyName = "LastUpdatedDateTime";
            this.LastUpdatedDateTime.HeaderText = "Last Updated DateTime";
            this.LastUpdatedDateTime.MinimumWidth = 6;
            this.LastUpdatedDateTime.Name = "LastUpdatedDateTime";
            this.LastUpdatedDateTime.ReadOnly = true;
            this.LastUpdatedDateTime.Width = 197;
            // 
            // AssignTo
            // 
            this.AssignTo.DataPropertyName = "AssignTo";
            this.AssignTo.HeaderText = "Assign To";
            this.AssignTo.MinimumWidth = 6;
            this.AssignTo.Name = "AssignTo";
            this.AssignTo.ReadOnly = true;
            this.AssignTo.Width = 104;
            // 
            // AssignedBy
            // 
            this.AssignedBy.DataPropertyName = "AssignedBy";
            this.AssignedBy.HeaderText = "Assigned By";
            this.AssignedBy.MinimumWidth = 6;
            this.AssignedBy.Name = "AssignedBy";
            this.AssignedBy.ReadOnly = true;
            this.AssignedBy.Width = 121;
            // 
            // AssignedDateTime
            // 
            this.AssignedDateTime.DataPropertyName = "AssignedDateTime";
            this.AssignedDateTime.HeaderText = "Assigned DateTime";
            this.AssignedDateTime.MinimumWidth = 6;
            this.AssignedDateTime.Name = "AssignedDateTime";
            this.AssignedDateTime.ReadOnly = true;
            this.AssignedDateTime.Width = 169;
            // 
            // frmDeAllocateEmails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1437, 753);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmDeAllocateEmails";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "De-Allocate Outlook Emails";
            this.Load += new System.EventHandler(this.frmAssignEmails_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmails)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Label label1;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private Button btnAssignEmails;
        private Button btnClear;
        private CheckBox chkSelectAll;
        private GroupBox groupBox3;
        private DataGridView dgvEmails;
        private ComboBox cmbSearchCriteria;
        private Label label4;
        private Label label5;
        private TextBox txtSearchText;
        private Label lblEmailsCount;
        private Label label2;
        private DataGridViewCheckBoxColumn ChkSelect;
        private DataGridViewTextBoxColumn EmailDetailsId;
        private DataGridViewTextBoxColumn EmailAddress;
        private DataGridViewTextBoxColumn FolderName;
        private DataGridViewTextBoxColumn Subject;
        private DataGridViewTextBoxColumn Priority;
        private DataGridViewTextBoxColumn HasAttachments;
        private DataGridViewTextBoxColumn ReceivedTime;
        private DataGridViewTextBoxColumn SenderName;
        private DataGridViewTextBoxColumn SenderEmailAddress;
        private DataGridViewTextBoxColumn To;
        private DataGridViewTextBoxColumn CC;
        private DataGridViewTextBoxColumn Bcc;
        private DataGridViewTextBoxColumn Body;
        private DataGridViewTextBoxColumn EntryID;
        private DataGridViewTextBoxColumn ConversationID;
        private DataGridViewTextBoxColumn Status;
        private DataGridViewTextBoxColumn SyncBy;
        private DataGridViewTextBoxColumn SyncDateTime;
        private DataGridViewTextBoxColumn LastUpdatedBy;
        private DataGridViewTextBoxColumn LastUpdatedDateTime;
        private DataGridViewTextBoxColumn AssignTo;
        private DataGridViewTextBoxColumn AssignedBy;
        private DataGridViewTextBoxColumn AssignedDateTime;
    }
}
