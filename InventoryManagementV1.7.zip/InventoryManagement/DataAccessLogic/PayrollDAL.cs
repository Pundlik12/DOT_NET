﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;

namespace InventoryManagement.DataAccessLogic
{
    public class PayrollDAL : IGenericRepository<PayrollModel>
    {
        public PayrollDAL()
        {
            DatabaseContext.CreateConnection();
        }

        public List<PayrollModel> GetAll()
        {
            List<PayrollModel> lstData = new List<PayrollModel>();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT PayrollID,EmployeeID,MonthName,BasicSalary,Deductions,NetSalary,Status,CreatedBy,CreatedDateTime FROM Payroll";
                
                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    PayrollModel objPayroll = new PayrollModel();
                    objPayroll.PayrollID = Convert.ToString(DatabaseContext.dbdr["PayrollID"]);
                    objPayroll.EmployeeID = Convert.ToString(DatabaseContext.dbdr["EmployeeID"]);
                    objPayroll.MonthName = Convert.ToString(DatabaseContext.dbdr["MonthName"]);
                    objPayroll.BasicSalary = Convert.ToString(DatabaseContext.dbdr["BasicSalary"]);
                    objPayroll.Deductions = Convert.ToString(DatabaseContext.dbdr["Deductions"]);
                    objPayroll.NetSalary = Convert.ToString(DatabaseContext.dbdr["NetSalary"]);
                    objPayroll.Status = Convert.ToString(DatabaseContext.dbdr["Status"]);
                    objPayroll.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objPayroll.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objPayroll);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public List<PayrollModel> GetByDates(string strFromDate, string strToDate)
        {
            throw new NotImplementedException();
        }

        public PayrollModel GetByID(Int32 PayrollID)
        {
            PayrollModel objPayroll = new PayrollModel();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT PayrollID,EmployeeID,MonthName,BasicSalary,Deductions,NetSalary,Status,CreatedBy,CreatedDateTime FROM Payroll WHERE PayrollID = " + PayrollID;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    objPayroll.PayrollID = Convert.ToString(DatabaseContext.dbdr["PayrollID"]);
                    objPayroll.EmployeeID = Convert.ToString(DatabaseContext.dbdr["EmployeeID"]);
                    objPayroll.MonthName = Convert.ToString(DatabaseContext.dbdr["MonthName"]);
                    objPayroll.BasicSalary = Convert.ToString(DatabaseContext.dbdr["BasicSalary"]);
                    objPayroll.Deductions = Convert.ToString(DatabaseContext.dbdr["Deductions"]);
                    objPayroll.NetSalary = Convert.ToString(DatabaseContext.dbdr["NetSalary"]);
                    objPayroll.Status = Convert.ToString(DatabaseContext.dbdr["Status"]);
                    objPayroll.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objPayroll.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return objPayroll;
        }

        public void Add(PayrollModel objPayroll)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "INSERT INTO Payroll (EmployeeID,MonthName,BasicSalary,Deductions,NetSalary,Status,CreatedBy,CreatedDateTime) VALUES(@EmployeeID,@MonthName,@BasicSalary,@Deductions,@NetSalary,@Status,@CreatedBy,@CreatedDateTime)";
                
                DatabaseContext.dbcmd.Parameters.AddWithValue("EmployeeID", objPayroll.EmployeeID);
                DatabaseContext.dbcmd.Parameters.AddWithValue("MonthName", objPayroll.MonthName);
                DatabaseContext.dbcmd.Parameters.AddWithValue("BasicSalary", objPayroll.BasicSalary);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Deductions", objPayroll.Deductions);
                DatabaseContext.dbcmd.Parameters.AddWithValue("NetSalary", objPayroll.NetSalary);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Status", objPayroll.Status);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objPayroll.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Update(PayrollModel objPayroll)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "UPDATE Payroll SET EmployeeID = @EmployeeID,MonthName = @MonthName,BasicSalary = @BasicSalary,Deductions = @Deductions,NetSalary = @NetSalary,Status = @Status, CreatedBy = @CreatedBy, CreatedDateTime = @CreatedDateTime WHERE PayrollID = " + objPayroll.PayrollID;

                DatabaseContext.dbcmd.Parameters.AddWithValue("EmployeeID", objPayroll.EmployeeID);
                DatabaseContext.dbcmd.Parameters.AddWithValue("MonthName", objPayroll.MonthName);
                DatabaseContext.dbcmd.Parameters.AddWithValue("BasicSalary", objPayroll.BasicSalary);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Deductions", objPayroll.Deductions);
                DatabaseContext.dbcmd.Parameters.AddWithValue("NetSalary", objPayroll.NetSalary);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Status", objPayroll.Status);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objPayroll.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Delete(Int32 PayrollID)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "DELETE FROM Payroll WHERE PayrollID = " + PayrollID;
                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
