﻿using System;
using System.Data;
using System.Windows.Forms;
using InventoryManagement.DataAccessLogic;

namespace InventoryManagement
{
    public partial class frmChallanView : Form
    {
        iReports objReportDal = null;
        DataTable dt = null;

        public frmChallanView(string strChallaNo)
        {
            InitializeComponent();
            common.ChallanNo = strChallaNo;
        }

        private void frmChallanEntry_Load(object sender, EventArgs e)
        {
            objReportDal = new ChallanDAL();
            dt = new DataTable();
            txtGrandTotal.Text = "0";
            txtTotalGST.Text = "0";
            DisplayData();
        }

        private void DisplayData()
        {
            Cursor = Cursors.WaitCursor;
            dt = objReportDal.PrintChallan();
            Int64 counter = 0;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string strCustomerCode = "";
                string strCustomerName = dt.Rows[i]["CustomerName"].ToString();
                string strItemCode = "";
                string strItemName = dt.Rows[i]["ItemType"].ToString();
                string strDescription = dt.Rows[i]["Description"].ToString();
                string strRate = dt.Rows[i]["Rate"].ToString();
                string strQty = dt.Rows[i]["Qty"].ToString();
                string strGSTPercent = dt.Rows[i]["GSTPercent"].ToString();
                string strGSTAmount = dt.Rows[i]["GST"].ToString();
                string strLineTotal = dt.Rows[i]["AMount"].ToString();

                txtTotalGST.Text = dt.Rows[i]["TotalGST"].ToString();
                txtGrandTotal.Text = dt.Rows[i]["TotalAmount"].ToString();
                counter = counter + 1;
                
                dgvChallan.Rows.Add(strCustomerCode, strCustomerName, strItemCode, strItemName, strDescription, strRate, strQty, strGSTPercent, strGSTAmount, strLineTotal);
            }

            lblCount.Text = Convert.ToString(counter);
            Cursor = Cursors.Default;
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            common.PrintInvoice(dt);
            Cursor = Cursors.Default;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
