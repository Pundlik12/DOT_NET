﻿using InventoryManagement.BusinessLogic;
using System.Collections.Generic;
using System.Windows.Forms;
using System;

namespace InventoryManagement.DataAccessLogic
{
    public class BillingDAL : IGenericRepository<BillingModel>
    {
        string strQuery = "";
        public BillingDAL()
        {
            DatabaseContext.CreateConnection();
        }

        public void Add(BillingModel objAnyType)
        {
            throw new NotImplementedException();
        }

        public void Delete(int ID)
        {
            throw new NotImplementedException();
        }

        public List<BillingModel> GetAll()
        {
            List<BillingModel> lstData = new List<BillingModel>();
            try
            {
                strQuery = "";
                strQuery = "SELECT th.ChallanNo,th.ChallanDate,th.CustomerCode,cus.Name as CustomerName,th.TotalAmount as ChallanAmount,IIf(IsNull(Payment.PaidAmount), 0, Payment.PaidAmount) as PaidAmount,(th.TotalAmount-IIf(IsNull(Payment.PaidAmount), 0, Payment.PaidAmount)) as PendingAmount\n";
                strQuery = strQuery + "FROM ((tblChallanHeader as th INNER JOIN tblCustomer as cus ON th.CustomerCode = cus.Code)\n";
                strQuery = strQuery + "LEFT JOIN (SELECT ChallanNo,SUM(Amount)AS PaidAmount FROM tblPayment GROUP BY ChallanNo)AS Payment ON th.ChallanNo = Payment.ChallanNo)\n";

                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = strQuery;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();

                while (DatabaseContext.dbdr.Read())
                {
                    BillingModel objBilling = new BillingModel();

                    objBilling.ChallanNo = Convert.ToString(DatabaseContext.dbdr["ChallanNo"]);
                    objBilling.ChallanDate = Convert.ToDateTime(DatabaseContext.dbdr["ChallanDate"]);
                    objBilling.CustomerCode = Convert.ToInt32(DatabaseContext.dbdr["CustomerCode"]);
                    objBilling.CustomerName = Convert.ToString(DatabaseContext.dbdr["CustomerName"]);
                    objBilling.ChallanAmount = Convert.ToDouble(DatabaseContext.dbdr["ChallanAmount"]);
                    objBilling.PaidAmount = Convert.ToDouble(DatabaseContext.dbdr["PaidAmount"]);
                    objBilling.PendingAmount = Convert.ToDouble(DatabaseContext.dbdr["PendingAmount"]);

                    lstData.Add(objBilling);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public List<BillingModel> GetByDates(string strFromDate, string strToDate)
        {
            throw new NotImplementedException();
        }

        public BillingModel GetByID(int ID)
        {
            throw new NotImplementedException();
        }

        public void Update(BillingModel objAnyType)
        {
            throw new NotImplementedException();
        }
    }
}
