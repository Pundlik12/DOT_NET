﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;
using InventoryManagement.DataAccessLogic;

namespace InventoryManagement
{
    public partial class frmSupplier : Form
    {
        SupplierModel objSupplierModel = null;
        IGenericRepository<SupplierModel> objSupplierDal = null;

        public frmSupplier()
        {
            InitializeComponent();
        }

        private void frmCustomer_Load(object sender, EventArgs e)
        {
            objSupplierDal = new SupplierDAL();
            ClearFields();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (txtName.Text.Trim() == "")
            {
                txtName.Focus();
                MessageBox.Show("Please enter name.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtAddress.Text.Trim() == "")
            {
                txtAddress.Focus();
                MessageBox.Show("Please enter address.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtPINCode.Text.Trim() == "")
            {
                txtPINCode.Focus();
                MessageBox.Show("Please enter pin code.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtCity.Text.Trim() == "")
            {
                txtCity.Focus();
                MessageBox.Show("Please enter city.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtState.Text.Trim() == "")
            {
                txtState.Focus();
                MessageBox.Show("Please enter state.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtMobile.Text.Trim() == "")
            {
                txtMobile.Focus();
                MessageBox.Show("Please enter mobile.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtEmail.Text.Trim() == "")
            {
                txtEmail.Focus();
                MessageBox.Show("Please enter email.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtGST.Text.Trim() == "")
            {
                txtGST.Focus();
                MessageBox.Show("Please enter gst no.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                Cursor = Cursors.WaitCursor;
                objSupplierModel = new SupplierModel();
                objSupplierModel.Name = txtName.Text.Trim();
                objSupplierModel.Address = txtAddress.Text.Trim();
                objSupplierModel.PinCode = txtPINCode.Text.Trim();
                objSupplierModel.City = txtCity.Text.Trim();
                objSupplierModel.State = txtState.Text.Trim();
                objSupplierModel.Mobile = txtMobile.Text.Trim();
                objSupplierModel.Email = txtEmail.Text.Trim();
                objSupplierModel.Mobile = txtMobile.Text.Trim();
                objSupplierModel.GSTNo = txtGST.Text.Trim();
                objSupplierModel.CreatedBy = common.strUserEmail;

                if (btnSave.Text == "Save")
                {
                    objSupplierDal.Add(objSupplierModel);
                    ClearFields();
                    //MessageBox.Show("Supplier saved successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    objSupplierModel.Code = Convert.ToInt32(txtCode.Text);
                    objSupplierDal.Update(objSupplierModel);
                    ClearFields();
                    //MessageBox.Show("Supplier updated successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Cursor = Cursors.Default;
            }
        }

        private void ClearFields()
        {
            txtCode.Text = "";
            txtName.Text = "";
            txtAddress.Text = "";
            txtPINCode.Text = "";
            txtCity.Text = "";
            txtState.Text = "";
            txtMobile.Text = "";
            txtEmail.Text = "";
            txtGST.Text = "";
            btnSave.Text = "Save";
            dgvData.Enabled = true;
            txtName.Select();
            DisplayData();            
        }

        private void DisplayData()
        {
            List<SupplierModel> lstFilteredData = null;
            List<SupplierModel> lstFilteredData1 = null;
            List<SupplierModel> lstFilteredData2 = null;

            List<SupplierModel> lstData = objSupplierDal.GetAll();

            if (txtNameSearch.Text != "")
            {
                lstFilteredData = lstData.Where(x => x.Name.Contains(txtNameSearch.Text)).ToList();
            }
            else
            {
                lstFilteredData = lstData;
            }

            if (txtCitySearch.Text != "")
            {
                lstFilteredData1 = lstFilteredData.Where(x => x.City.Contains(txtCitySearch.Text)).ToList();
            }
            else
            {
                lstFilteredData1 = lstFilteredData;
            }

            if (txtStateSearch.Text != "")
            {
                lstFilteredData2 = lstFilteredData1.Where(x => x.State.Contains(txtStateSearch.Text)).ToList();
            }
            else
            {
                lstFilteredData2 = lstFilteredData1;
            }

            dgvData.DataSource = lstFilteredData2;
        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (e.ColumnIndex == 0)
                {
                    if (common.strUserRole == "Admin")
                    {
                        txtCode.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Code"].Value);
                        txtName.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["SupplierName"].Value);
                        txtAddress.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Address"].Value);
                        txtPINCode.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["PINCode"].Value);
                        txtCity.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["City"].Value);
                        txtState.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["State"].Value);
                        txtMobile.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Mobile"].Value);
                        txtEmail.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Email"].Value);
                        txtGST.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["GSTNo"].Value);
                        btnSave.Text = "Update";
                        dgvData.Enabled = false;
                        txtName.Select();
                    }
                    else
                    {
                        MessageBox.Show("You do not have appropriate permission for this action.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                if (e.ColumnIndex == 1)
                {
                    if (common.strUserRole == "Admin")
                    {
                        if (MessageBox.Show("Do you want to delete?", common.strProjectTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            Int32 code = Convert.ToInt32(dgvData.Rows[e.RowIndex].Cells["Code"].Value);
                            objSupplierDal.Delete(code);

                            ClearFields();

                            //MessageBox.Show("Customer deleted successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MessageBox.Show("You do not have appropriate permission for this action.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                if (e.ColumnIndex == 2)
                {
                    if (common.strUserRole == "Admin")
                    {
                        string SupplierCode = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Code"].Value);
                        string SupplierName = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["SupplierName"].Value);

                        Cursor.Current = Cursors.WaitCursor;
                        frmSupplierItems objfrmSupplierItems = new frmSupplierItems(SupplierCode, SupplierName);
                        objfrmSupplierItems.WindowState = FormWindowState.Normal;
                        objfrmSupplierItems.StartPosition = FormStartPosition.CenterScreen;
                        objfrmSupplierItems.Text = common.strProjectTitle + " : Supplier Items";
                        objfrmSupplierItems.ShowDialog();
                        Cursor.Current = Cursors.Default;
                    }
                    else
                    {
                        MessageBox.Show("You do not have appropriate permission for this action.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtNameSearch_TextChanged(object sender, EventArgs e)
        {
            DisplayData();
        }

        private void txtCitySearch_TextChanged(object sender, EventArgs e)
        {
            DisplayData();
        }

        private void txtStateSearch_TextChanged(object sender, EventArgs e)
        {
            DisplayData();
        }
    }
}
