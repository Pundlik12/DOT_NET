﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace HBAccessTool
{
    public class UserRepository : iUser,IDisposable
    {
        OleDbConnection dbcon = null;
        OleDbCommand dbcmd = null;
        OleDbDataReader dbdr = null;
        
        List<UserModel> lstUser = null;
        UserModel objUM = null;

        public bool CreateTables()
        {
            Boolean isSucess = false;
            try
            {
                string tblUser = "CREATE TABLE tblUser ";
                tblUser = tblUser + "(UserID AUTOINCREMENT PRIMARY KEY,";
                tblUser = tblUser + "UID Varchar(50) NOT NULL,";
                tblUser = tblUser + "FirstName Varchar(100) NULL,";
                tblUser = tblUser + "LastName Varchar(100) NULL,";
                tblUser = tblUser + "DisplayName Varchar(100) NULL,";
                tblUser = tblUser + "Role Varchar(50),";
                tblUser = tblUser + "IsActive INTEGER,";
                tblUser = tblUser + "EntryID INTEGER,";
                tblUser = tblUser + "EntryDatetime DATETIME);";

                string[] arrTables = { tblUser };

                foreach (string strTable in arrTables)
                {
                    try
                    {
                        using (OleDbConnection OleDbcon = new OleDbConnection(clsDBConnection.strConstr))
                        {
                            OleDbCommand cmd = new OleDbCommand();
                            cmd.Connection = OleDbcon;

                            cmd.CommandText = strTable;
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandTimeout = 0;

                            OleDbcon.Open();
                            cmd.ExecuteNonQuery();
                            OleDbcon.Close();
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                    }
                }

                isSucess = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                isSucess = false;
            }

            return isSucess;
        }

        public bool DROPTables()
        {
            Boolean isSucess = false;
            try
            {
                string tblUser = "DROP TABLE tblUser";
                string[] arrTables = { tblUser };

                foreach (string strTable in arrTables)
                {
                    try
                    {
                        using (OleDbConnection OleDbcon = new OleDbConnection(clsDBConnection.strConstr))
                        {
                            OleDbCommand cmd = new OleDbCommand();
                            cmd.Connection = OleDbcon;

                            cmd.CommandText = strTable;
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandTimeout = 0;

                            OleDbcon.Open();
                            cmd.ExecuteNonQuery();
                            OleDbcon.Close();
                        }
                    }
                    catch (Exception)
                    {
                    }
                }

                isSucess = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                isSucess = false;
            }

            return isSucess;
        }

        public List<UserModel> GetAllUsers()
        {
            try
            {
                using (dbcon = new OleDbConnection())
                {
                    dbcon.ConnectionString = clsDBConnection.strConstr;
                    using (dbcmd = new OleDbCommand())
                    {
                        dbcon.Open();
                        dbcmd.Connection = dbcon;
                        dbcmd.CommandType = System.Data.CommandType.Text;
                        dbcmd.CommandText = "SELECT * FROM tblUser";
                        dbcmd.CommandTimeout = 0;
                        dbdr = dbcmd.ExecuteReader();

                        lstUser = new List<UserModel>();
                        while (dbdr.Read())
                        {
                            objUM = new UserModel();
                            objUM.UserID = Convert.ToInt32(dbdr["UserID"]);
                            objUM.Uid = Convert.ToString(dbdr["UID"]);
                            objUM.FirstName = Convert.ToString(dbdr["FirstName"]);
                            objUM.LastName = Convert.ToString(dbdr["LastName"]);
                            objUM.DisplayName = Convert.ToString(dbdr["DisplayName"]);
                            objUM.Role = Convert.ToString(dbdr["Role"]);
                            objUM.IsActive = Convert.ToInt32(dbdr["IsActive"]);
                            objUM.EntryID = Convert.ToInt32(dbdr["EntryID"]);
                            objUM.EntryDateTime = Convert.ToDateTime(DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                            lstUser.Add(objUM);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                lstUser = null;
                MessageBox.Show(ex.ToString(),"GetAllUsers",MessageBoxButtons.OK,MessageBoxIcon.Stop);
            }
            
            return lstUser;
        }

        public UserModel GetUserByID(int UserId)
        {
            try
            {
                using (dbcon = new OleDbConnection())
                {
                    dbcon.ConnectionString = clsDBConnection.strConstr;
                    using (dbcmd = new OleDbCommand())
                    {
                        dbcon.Open();
                        dbcmd.Connection = dbcon;
                        dbcmd.CommandType = System.Data.CommandType.Text;
                        dbcmd.CommandText = "SELECT * FROM tblUser WHERE UserId = " + UserId;
                        dbcmd.CommandTimeout = 0;
                        dbdr = dbcmd.ExecuteReader();

                        lstUser = new List<UserModel>();
                        while (dbdr.Read())
                        {
                            objUM = new UserModel();
                            objUM.UserID = Convert.ToInt32(dbdr["UserID"]);
                            objUM.Uid = Convert.ToString(dbdr["UID"]);
                            objUM.FirstName = Convert.ToString(dbdr["FirstName"]);
                            objUM.LastName = Convert.ToString(dbdr["LastName"]);
                            objUM.DisplayName = Convert.ToString(dbdr["DisplayName"]);
                            objUM.Role = Convert.ToString(dbdr["Role"]);
                            objUM.IsActive = Convert.ToInt32(dbdr["IsActive"]);
                            objUM.EntryID = Convert.ToInt32(dbdr["EntryID"]);
                            objUM.EntryDateTime = Convert.ToDateTime(DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                            lstUser.Add(objUM);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                objUM = null;
                MessageBox.Show(ex.ToString(), "GetUserByID", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            
            return objUM;
        }

        public int AddUser(UserModel UM)
        {
            int NoOfRowsAffected = 0;
            try
            {
                using (dbcon = new OleDbConnection())
                {
                    dbcon.ConnectionString = clsDBConnection.strConstr;
                    using (dbcmd = new OleDbCommand())
                    {
                        dbcon.Open();
                        dbcmd.Connection = dbcon;
                        dbcmd.CommandType = System.Data.CommandType.Text;
                        dbcmd.CommandText = "INSERT INTO tblUser (UID,FirstName,LastName,DisplayName,Role,IsActive,EntryID,EntryDateTime) VALUES(@UID,@FirstName,@LastName,@DisplayName,@Role,@IsActive,@EntryID,Now())";
                        dbcmd.CommandTimeout = 0;

                        dbcmd.Parameters.AddWithValue("UID", UM.Uid);
                        dbcmd.Parameters.AddWithValue("FirstName", UM.FirstName);
                        dbcmd.Parameters.AddWithValue("LastName", UM.LastName);
                        dbcmd.Parameters.AddWithValue("DisplayName", UM.DisplayName);
                        dbcmd.Parameters.AddWithValue("Role", UM.Role);
                        dbcmd.Parameters.AddWithValue("IsActive", UM.IsActive);
                        dbcmd.Parameters.AddWithValue("EntryID", clsDBConnection.intLoginUserID);
                        
                        NoOfRowsAffected = dbcmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                NoOfRowsAffected = 0;
                MessageBox.Show(ex.ToString(), "AddUser", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            
            return NoOfRowsAffected;
        }

        public int DeleteUser(int UserId)
        {
            int NoOfRowsAffected = 0;
            try
            {
                using (dbcon = new OleDbConnection())
                {
                    dbcon.ConnectionString = clsDBConnection.strConstr;
                    using (dbcmd = new OleDbCommand())
                    {
                        dbcon.Open();
                        dbcmd.Connection = dbcon;
                        dbcmd.CommandType = System.Data.CommandType.Text;
                        dbcmd.CommandText = "DELETE FROM tblUser WHERE UserID = " + UserId;
                        dbcmd.CommandTimeout = 0;

                        NoOfRowsAffected = dbcmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                NoOfRowsAffected = 0;
                MessageBox.Show(ex.ToString(), "DeleteUser", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            
            return NoOfRowsAffected;
        }

        public int UpdateUser(UserModel UM)
        {
            int NoOfRowsAffected = 0;

            try
            {
                using (dbcon = new OleDbConnection())
                {
                    dbcon.ConnectionString = clsDBConnection.strConstr;
                    using (dbcmd = new OleDbCommand())
                    {
                        dbcon.Open();
                        dbcmd.Connection = dbcon;
                        dbcmd.CommandType = System.Data.CommandType.Text;
                        dbcmd.CommandText = "UPDATE tblUser SET FirstName = @FirstName, LastName = @LastName, DisplayName = @DisplayName, Role = @Role, IsActive = @IsActive, EntryID = @EntryID, EntryDateTime = Now() WHERE UID = '" + UM.Uid + "'";
                        dbcmd.CommandTimeout = 0;

                        dbcmd.Parameters.AddWithValue("FirstName", UM.FirstName);
                        dbcmd.Parameters.AddWithValue("LastName", UM.LastName);
                        dbcmd.Parameters.AddWithValue("DisplayName", UM.FirstName + " " + UM.LastName);
                        dbcmd.Parameters.AddWithValue("Role", UM.Role);
                        dbcmd.Parameters.AddWithValue("IsActive", UM.IsActive);
                        dbcmd.Parameters.AddWithValue("EntryID", clsDBConnection.intLoginUserID);
                        
                        NoOfRowsAffected = dbcmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                NoOfRowsAffected = 0;
                MessageBox.Show(ex.ToString(), "UpdateUser", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            
            return NoOfRowsAffected;
        }

        public void Dispose()
        {
            Dispose(true);
            //GC.Collect();
            //GC.WaitForPendingFinalizers();
            //GC.SuppressFinalize();
        }

        ~UserRepository()
        {
            Dispose(false);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }
    }
}
