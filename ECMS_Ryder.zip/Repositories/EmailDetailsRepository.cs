﻿using System;
using System.Data.OleDb;
using ECMS_Ryder.Models;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using ECMS_Ryder.HelperClasses;

namespace ECMS_Ryder.Repositories
{
    interface iEmailDetailsRepository
    {
        List<EmailDetails> GetAllEmails();
        List<EmailDetails> GetUnAssignedEmails();
        List<EmailDetails> GetAssignedEmails();
        List<EmailDetails> GetAssignedEmailsAdmin();
        EmailDetails GetEmailsById(Int32 EmailDetailsId);
        void SyncEmails(List<EmailDetails> emails);
        void DeleteEmailById(Int32 EmailDetailsId);
        void AssignEmails(List<EmailDetails> emails);
        void DeAllocateEmails(List<EmailDetails> emails);
        void DisposeEmails(DispositionDetails dispositionDetails);
    }

    internal class EmailDetailsRepository : iEmailDetailsRepository
    {
        private readonly string strConnectionString = "";
        
        public EmailDetailsRepository(string _strConnectionString) 
        {
            strConnectionString = _strConnectionString;
        }

        public List<EmailDetails> GetAllEmails()
        {
            List <EmailDetails> emails = new List<EmailDetails>();
            try
            {
                using(OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "GetAllEmails";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@EmailAddress", clsDBConnection.strEmailAddress);

                    OleDbDataReader OleDbDataReader = cmd.ExecuteReader();

                    while (OleDbDataReader.Read())
                    {
                        EmailDetails emailDetails = new EmailDetails();
                        emailDetails.EmailDetailsId = Convert.ToInt32(OleDbDataReader["EmailDetailsId"]);
                        emailDetails.EmailAddress = Convert.ToString(OleDbDataReader["EmailAddress"]);
                        emailDetails.FolderName = Convert.ToString(OleDbDataReader["FolderName"]);
                        emailDetails.SenderName = Convert.ToString(OleDbDataReader["SenderName"]);
                        emailDetails.SenderEmailAddress = Convert.ToString(OleDbDataReader["SenderEmailAddress"]);
                        emailDetails.To = Convert.ToString(OleDbDataReader["To"]);
                        emailDetails.Cc = Convert.ToString(OleDbDataReader["Cc"]);
                        emailDetails.Bcc = Convert.ToString(OleDbDataReader["Bcc"]);
                        emailDetails.ReceivedTime = Convert.ToString(OleDbDataReader["ReceivedTime"]);
                        emailDetails.Subject = Convert.ToString(OleDbDataReader["Subject"]);
                        emailDetails.Body = Convert.ToString(OleDbDataReader["Body"]);
                        emailDetails.Priority = Convert.ToString(OleDbDataReader["Priority"]);
                        emailDetails.HasAttachments = Convert.ToString(OleDbDataReader["HasAttachments"]);
                        emailDetails.EntryID = Convert.ToString(OleDbDataReader["EntryID"]);
                        emailDetails.ConversationID = Convert.ToString(OleDbDataReader["ConversationID"]);
                        emailDetails.Status = Convert.ToString(OleDbDataReader["Status"]);
                        emailDetails.SyncBy = Convert.ToString(OleDbDataReader["SyncBy"]);
                        emailDetails.SyncDateTime = Convert.ToString(OleDbDataReader["SyncDateTime"]);
                        emailDetails.LastUpdatedBy = Convert.ToString(OleDbDataReader["LastUpdatedBy"]);
                        emailDetails.LastUpdatedDateTime = Convert.ToString(OleDbDataReader["LastUpdatedDateTime"]);
                        emailDetails.AssignedBy = Convert.ToString(OleDbDataReader["AssignedBy"]);
                        emailDetails.AssignTo = Convert.ToString(OleDbDataReader["AssignTo"]);
                        emailDetails.AssignedDateTime = Convert.ToString(OleDbDataReader["AssignedDateTime"]);
                        emailDetails.AccountNumber = Convert.ToString(OleDbDataReader["AccountNumber"]);

                        emails.Add(emailDetails);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetAllEmails:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return emails;
        }

        public List<EmailDetails> GetUnAssignedEmails()
        {
            List<EmailDetails> emails = new List<EmailDetails>();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "GetUnAssignedEmails";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@EmailAddress", clsDBConnection.strEmailAddress);

                    OleDbDataReader OleDbDataReader = cmd.ExecuteReader();

                    while (OleDbDataReader.Read())
                    {
                        EmailDetails emailDetails = new EmailDetails();
                        emailDetails.EmailDetailsId = Convert.ToInt32(OleDbDataReader["EmailDetailsId"]);
                        emailDetails.EmailAddress = Convert.ToString(OleDbDataReader["EmailAddress"]);
                        emailDetails.FolderName = Convert.ToString(OleDbDataReader["FolderName"]);
                        emailDetails.SenderName = Convert.ToString(OleDbDataReader["SenderName"]);
                        emailDetails.SenderEmailAddress = Convert.ToString(OleDbDataReader["SenderEmailAddress"]);
                        emailDetails.To = Convert.ToString(OleDbDataReader["To"]);
                        emailDetails.Cc = Convert.ToString(OleDbDataReader["Cc"]);
                        emailDetails.Bcc = Convert.ToString(OleDbDataReader["Bcc"]);
                        emailDetails.ReceivedTime = Convert.ToString(OleDbDataReader["ReceivedTime"]);
                        emailDetails.Subject = Convert.ToString(OleDbDataReader["Subject"]);
                        emailDetails.Body = Convert.ToString(OleDbDataReader["Body"]);
                        emailDetails.Priority = Convert.ToString(OleDbDataReader["Priority"]);
                        emailDetails.HasAttachments = Convert.ToString(OleDbDataReader["HasAttachments"]);
                        emailDetails.EntryID = Convert.ToString(OleDbDataReader["EntryID"]);
                        emailDetails.ConversationID = Convert.ToString(OleDbDataReader["ConversationID"]);
                        emailDetails.Status = Convert.ToString(OleDbDataReader["Status"]);
                        emailDetails.SyncBy = Convert.ToString(OleDbDataReader["SyncBy"]);
                        emailDetails.SyncDateTime = Convert.ToString(OleDbDataReader["SyncDateTime"]);
                        emailDetails.LastUpdatedBy = Convert.ToString(OleDbDataReader["LastUpdatedBy"]);
                        emailDetails.LastUpdatedDateTime = Convert.ToString(OleDbDataReader["LastUpdatedDateTime"]);
                        emailDetails.AssignedBy = Convert.ToString(OleDbDataReader["AssignedBy"]);
                        emailDetails.AssignTo = Convert.ToString(OleDbDataReader["AssignTo"]);
                        emailDetails.AssignedDateTime = Convert.ToString(OleDbDataReader["AssignedDateTime"]);
                        emailDetails.AccountNumber = Convert.ToString(OleDbDataReader["AccountNumber"]);

                        emails.Add(emailDetails);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetUnAssignedEmails:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return emails;
        }

        public List<EmailDetails> GetAssignedEmails()
        {
            List<EmailDetails> emails = new List<EmailDetails>();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "GetAssignedEmails";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@EmailAddress", clsDBConnection.strEmailAddress);
                    cmd.Parameters.AddWithValue("@AssignTo", clsDBConnection.strLoggedInUID);
                    
                    OleDbDataReader OleDbDataReader = cmd.ExecuteReader();

                    while (OleDbDataReader.Read())
                    {
                        EmailDetails emailDetails = new EmailDetails();
                        emailDetails.EmailDetailsId = Convert.ToInt32(OleDbDataReader["EmailDetailsId"]);
                        emailDetails.EmailAddress = Convert.ToString(OleDbDataReader["EmailAddress"]);
                        emailDetails.FolderName = Convert.ToString(OleDbDataReader["FolderName"]);
                        emailDetails.SenderName = Convert.ToString(OleDbDataReader["SenderName"]);
                        emailDetails.SenderEmailAddress = Convert.ToString(OleDbDataReader["SenderEmailAddress"]);
                        emailDetails.To = Convert.ToString(OleDbDataReader["To"]);
                        emailDetails.Cc = Convert.ToString(OleDbDataReader["Cc"]);
                        emailDetails.Bcc = Convert.ToString(OleDbDataReader["Bcc"]);
                        emailDetails.ReceivedTime = Convert.ToString(OleDbDataReader["ReceivedTime"]);
                        emailDetails.Subject = Convert.ToString(OleDbDataReader["Subject"]);
                        emailDetails.Body = Convert.ToString(OleDbDataReader["Body"]);
                        emailDetails.Priority = Convert.ToString(OleDbDataReader["Priority"]);
                        emailDetails.HasAttachments = Convert.ToString(OleDbDataReader["HasAttachments"]);
                        emailDetails.EntryID = Convert.ToString(OleDbDataReader["EntryID"]);
                        emailDetails.ConversationID = Convert.ToString(OleDbDataReader["ConversationID"]);
                        emailDetails.Status = Convert.ToString(OleDbDataReader["Status"]);
                        emailDetails.SyncBy = Convert.ToString(OleDbDataReader["SyncBy"]);
                        emailDetails.SyncDateTime = Convert.ToString(OleDbDataReader["SyncDateTime"]);
                        emailDetails.LastUpdatedBy = Convert.ToString(OleDbDataReader["LastUpdatedBy"]);
                        emailDetails.LastUpdatedDateTime = Convert.ToString(OleDbDataReader["LastUpdatedDateTime"]);
                        emailDetails.AssignedBy = Convert.ToString(OleDbDataReader["AssignedBy"]);
                        emailDetails.AssignTo = Convert.ToString(OleDbDataReader["AssignTo"]);
                        emailDetails.AssignedDateTime = Convert.ToString(OleDbDataReader["AssignedDateTime"]);
                        emailDetails.AccountNumber = Convert.ToString(OleDbDataReader["AccountNumber"]);

                        emails.Add(emailDetails);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetAssignedEmails:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return emails;
        }

        public List<EmailDetails> GetAssignedEmailsAdmin()
        {
            List<EmailDetails> emails = new List<EmailDetails>();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "GetAssignedEmailsAdmin";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@EmailAddress", clsDBConnection.strEmailAddress);
                   
                    OleDbDataReader OleDbDataReader = cmd.ExecuteReader();

                    while (OleDbDataReader.Read())
                    {
                        EmailDetails emailDetails = new EmailDetails();
                        emailDetails.EmailDetailsId = Convert.ToInt32(OleDbDataReader["EmailDetailsId"]);
                        emailDetails.EmailAddress = Convert.ToString(OleDbDataReader["EmailAddress"]);
                        emailDetails.FolderName = Convert.ToString(OleDbDataReader["FolderName"]);
                        emailDetails.SenderName = Convert.ToString(OleDbDataReader["SenderName"]);
                        emailDetails.SenderEmailAddress = Convert.ToString(OleDbDataReader["SenderEmailAddress"]);
                        emailDetails.To = Convert.ToString(OleDbDataReader["To"]);
                        emailDetails.Cc = Convert.ToString(OleDbDataReader["Cc"]);
                        emailDetails.Bcc = Convert.ToString(OleDbDataReader["Bcc"]);
                        emailDetails.ReceivedTime = Convert.ToString(OleDbDataReader["ReceivedTime"]);
                        emailDetails.Subject = Convert.ToString(OleDbDataReader["Subject"]);
                        emailDetails.Body = Convert.ToString(OleDbDataReader["Body"]);
                        emailDetails.Priority = Convert.ToString(OleDbDataReader["Priority"]);
                        emailDetails.HasAttachments = Convert.ToString(OleDbDataReader["HasAttachments"]);
                        emailDetails.EntryID = Convert.ToString(OleDbDataReader["EntryID"]);
                        emailDetails.ConversationID = Convert.ToString(OleDbDataReader["ConversationID"]);
                        emailDetails.Status = Convert.ToString(OleDbDataReader["Status"]);
                        emailDetails.SyncBy = Convert.ToString(OleDbDataReader["SyncBy"]);
                        emailDetails.SyncDateTime = Convert.ToString(OleDbDataReader["SyncDateTime"]);
                        emailDetails.LastUpdatedBy = Convert.ToString(OleDbDataReader["LastUpdatedBy"]);
                        emailDetails.LastUpdatedDateTime = Convert.ToString(OleDbDataReader["LastUpdatedDateTime"]);
                        emailDetails.AssignedBy = Convert.ToString(OleDbDataReader["AssignedBy"]);
                        emailDetails.AssignTo = Convert.ToString(OleDbDataReader["AssignTo"]);
                        emailDetails.AssignedDateTime = Convert.ToString(OleDbDataReader["AssignedDateTime"]);
                        emailDetails.AccountNumber = Convert.ToString(OleDbDataReader["AccountNumber"]);

                        emails.Add(emailDetails);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetAssignedEmailsAdmin:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return emails;
        }

        public EmailDetails GetEmailsById(int EmailDetailsId)
        {
            EmailDetails emailDetails = new EmailDetails();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "GetEmailsById";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@EmailDetailsId", EmailDetailsId);

                    OleDbDataReader OleDbDataReader = cmd.ExecuteReader();

                    while (OleDbDataReader.Read())
                    {
                        emailDetails.EmailDetailsId = Convert.ToInt32(OleDbDataReader["EmailDetailsId"]);
                        emailDetails.EmailAddress = Convert.ToString(OleDbDataReader["EmailAddress"]);
                        emailDetails.FolderName = Convert.ToString(OleDbDataReader["FolderName"]);
                        emailDetails.SenderName = Convert.ToString(OleDbDataReader["SenderName"]);
                        emailDetails.SenderEmailAddress = Convert.ToString(OleDbDataReader["SenderEmailAddress"]);
                        emailDetails.To = Convert.ToString(OleDbDataReader["To"]);
                        emailDetails.Cc = Convert.ToString(OleDbDataReader["Cc"]);
                        emailDetails.Bcc = Convert.ToString(OleDbDataReader["Bcc"]);
                        emailDetails.ReceivedTime = Convert.ToString(OleDbDataReader["ReceivedTime"]);
                        emailDetails.Subject = Convert.ToString(OleDbDataReader["Subject"]);
                        emailDetails.Body = Convert.ToString(OleDbDataReader["Body"]);
                        emailDetails.Priority = Convert.ToString(OleDbDataReader["Priority"]);
                        emailDetails.HasAttachments = Convert.ToString(OleDbDataReader["HasAttachments"]);
                        emailDetails.EntryID = Convert.ToString(OleDbDataReader["EntryID"]);
                        emailDetails.ConversationID = Convert.ToString(OleDbDataReader["ConversationID"]);
                        emailDetails.Status = Convert.ToString(OleDbDataReader["Status"]);
                        emailDetails.SyncBy = Convert.ToString(OleDbDataReader["SyncBy"]);
                        emailDetails.SyncDateTime = Convert.ToString(OleDbDataReader["SyncDateTime"]);
                        emailDetails.LastUpdatedBy = Convert.ToString(OleDbDataReader["LastUpdatedBy"]);
                        emailDetails.LastUpdatedDateTime = Convert.ToString(OleDbDataReader["LastUpdatedDateTime"]);
                        emailDetails.AssignedBy = Convert.ToString(OleDbDataReader["AssignedBy"]);
                        emailDetails.AssignTo = Convert.ToString(OleDbDataReader["AssignTo"]);
                        emailDetails.AssignedDateTime = Convert.ToString(OleDbDataReader["AssignedDateTime"]);
                        emailDetails.AccountNumber = Convert.ToString(OleDbDataReader["AccountNumber"]);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                emailDetails = null;
                MessageBox.Show("Error in GetEmailsById:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return emailDetails;
        }

        public void SyncEmails(List<EmailDetails> emails)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    foreach (EmailDetails email in emails)
                    {
                        OleDbCommand cmd = new OleDbCommand();
                        cmd.Connection = connection;
                        cmd.CommandText = "SyncEmails";
                        cmd.CommandTimeout = 0;
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@EmailAddress", email.EmailAddress);
                        cmd.Parameters.AddWithValue("@FolderName", email.FolderName);
                        cmd.Parameters.AddWithValue("@SenderName", email.SenderName);
                        cmd.Parameters.AddWithValue("@SenderEmailAddress", email.SenderEmailAddress);
                        cmd.Parameters.AddWithValue("@To", email.To);
                        cmd.Parameters.AddWithValue("@Cc", email.Cc);
                        cmd.Parameters.AddWithValue("@Bcc", email.Bcc);
                        cmd.Parameters.AddWithValue("@ReceivedTime", email.ReceivedTime);
                        cmd.Parameters.AddWithValue("@Subject", email.Subject);
                        //cmd.Parameters.AddWithValue("@Body", email.Body);
                        cmd.Parameters.AddWithValue("@Priority", email.Priority);
                        cmd.Parameters.AddWithValue("@HasAttachments", email.HasAttachments);
                        cmd.Parameters.AddWithValue("@EntryID", email.EntryID);
                        cmd.Parameters.AddWithValue("@ConversationID", email.ConversationID);
                        cmd.Parameters.AddWithValue("@Status", email.Status);
                        cmd.Parameters.AddWithValue("@SyncBy", clsDBConnection.strLoggedInUID);
                        cmd.Parameters.AddWithValue("@SyncDateTime", email.SyncDateTime);
                        cmd.Parameters.AddWithValue("@AccountNumber", email.AccountNumber);

                        cmd.ExecuteNonQuery();
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in SyncEmails:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void DeleteEmailById(Int32 EmailDetailsId)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "DeleteEmailById";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@EmailDetailsId", EmailDetailsId);

                    cmd.ExecuteNonQuery();
                    
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in DeleteEmailById:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void AssignEmails(List<EmailDetails> emails)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    foreach (EmailDetails email in emails)
                    {
                        OleDbCommand cmd = new OleDbCommand();
                        cmd.Connection = connection;
                        cmd.CommandText = "AssignEmails";
                        cmd.CommandTimeout = 0;
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@Priority", email.Priority);
                        cmd.Parameters.AddWithValue("@AssignTo", email.AssignTo);
                        cmd.Parameters.AddWithValue("@AssignedBy", clsDBConnection.strLoggedInUID);
                        cmd.Parameters.AddWithValue("@AssignedDateTime", email.AssignedDateTime);
                        cmd.Parameters.AddWithValue("@EmailDetailsId", email.EmailDetailsId);

                        cmd.ExecuteNonQuery();
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in AssignEmails:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void DeAllocateEmails(List<EmailDetails> emails)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    foreach (EmailDetails email in emails)
                    {
                        OleDbCommand cmd = new OleDbCommand();
                        cmd.Connection = connection;
                        cmd.CommandText = "DeAllocateEmails";
                        cmd.CommandTimeout = 0;
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@EmailDetailsId", email.EmailDetailsId);

                        cmd.ExecuteNonQuery();
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in DeAllocateEmails:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void DisposeEmails(DispositionDetails dispositionDetails)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "DisposeEmails";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@EmailDetailsId", dispositionDetails.EmailDetailsId);
                    cmd.Parameters.AddWithValue("@StartTime", dispositionDetails.StartTime);
                    cmd.Parameters.AddWithValue("@Category", dispositionDetails.Category);
                    cmd.Parameters.AddWithValue("@SubCategory", dispositionDetails.SubCategory);
                    cmd.Parameters.AddWithValue("@Inclusions", dispositionDetails.Inclusions);
                    cmd.Parameters.AddWithValue("@Dependency", dispositionDetails.Dependency);
                    cmd.Parameters.AddWithValue("@ManualFollowUp", dispositionDetails.ManualFollowUp);
                    cmd.Parameters.AddWithValue("@Comments", dispositionDetails.Comments);
                    cmd.Parameters.AddWithValue("@EntryUser", clsDBConnection.strLoggedInUID);
                    cmd.Parameters.AddWithValue("@EntryDateTime", dispositionDetails.EntryDateTime);
                   
                    cmd.ExecuteNonQuery();

                    OleDbCommand cmdUpdate = new OleDbCommand();
                    
                    cmdUpdate.Connection = connection;
                    cmdUpdate.CommandText = "UpdateEmailStatus";
                    cmdUpdate.CommandTimeout = 0;
                    cmdUpdate.CommandType = CommandType.StoredProcedure;

                    cmdUpdate.Parameters.AddWithValue("@LastUpdatedBy", clsDBConnection.strLoggedInUID);
                    cmdUpdate.Parameters.AddWithValue("@LastUpdatedDateTime", dispositionDetails.EntryDateTime);
                    cmdUpdate.Parameters.AddWithValue("@EmailDetailsId", dispositionDetails.EmailDetailsId);

                    cmdUpdate.ExecuteNonQuery();

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in DisposeEmails:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    
    }
}
