﻿using System;
using System.Windows.Forms;
using InventoryManagement.DataAccessLogic;

namespace InventoryManagement
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            DatabaseContext.CreateDatabase_Objects();

            //var strEncrypt = common.EncryptString(common.strKey, "01-Dec-2025");
            //var strDecrypt = common.DecryptString(common.strKey, strEncrypt);

            common.CheckApplicationIsRunning("InventoryManagement");
            common.CheckLicense();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmLogin());
        }
    }
}
