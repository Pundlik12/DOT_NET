using System;
using ECMS_Ryder.HelperClasses;
using System.Windows.Forms;
using ECMS_Ryder.Repositories;
using System.Linq;

namespace ECMS_Ryder.Forms
{
    public partial class frmSyncEmails : Form
    {
        private readonly clsOutlookLayer objClsOutlookLayer;
        private readonly EmailDetailsRepository objEmailDetailsRepository;

        public frmSyncEmails()
        {
            InitializeComponent();
            
            objClsOutlookLayer = new clsOutlookLayer();
            objEmailDetailsRepository = new EmailDetailsRepository(clsDBConnection.strConnectionString);
        }

        private void frmSyncEmails_Load(object sender, EventArgs e)
        {
            try
            {
                var subFolders = objClsOutlookLayer.GetSubFoldersOfInbox();

                cmbFolderName.Items.Clear();
                cmbFolderName.Items.Add("Select");
                cmbFolderName.Items.Add("Inbox");

                foreach (var item in subFolders)
                {
                    cmbFolderName.Items.Add(item.ToString());
                }

                txtEmailID.Text = clsDBConnection.strEmailAddress;
                dtpToDate.MaxDate = DateTime.Now;
                cmbFolderName.SelectedIndex = 0;
                cmbFolderName.Select();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in Load." + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSyncEmails_Click(object sender, EventArgs e)
        {
            if (txtEmailID.Text.Trim() == "")
            {
                MessageBox.Show("Please enter the EmailID configured in your desktop outlook application.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                txtEmailID.Focus();
                return;
            }

            if (cmbFolderName.Text == "Select")
            {
                MessageBox.Show("Please select folder name.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                cmbFolderName.Focus();
                return;
            }

            Cursor = Cursors.WaitCursor;
            
            lblEmailsSynced.Text = "-";

            objClsOutlookLayer.strEmailAddress = txtEmailID.Text.Trim();
            objClsOutlookLayer.FolderNameToSearch = cmbFolderName.Text;
            objClsOutlookLayer.strFromDate = dtpFromDate.Text.Trim();
            objClsOutlookLayer.strToDate = dtpToDate.Text.Trim();

            var lstOutlook = objClsOutlookLayer.GetOutlookEmails();

            if (lstOutlook != null)
            {
                var lstDatabase = objEmailDetailsRepository.GetAllEmails();

                var NewEmails = (from mails in lstOutlook where !lstDatabase.Any(x => x.EntryID == mails.EntryID) select mails).ToList();

                NewEmails.ForEach(x => x.SyncBy = "System");
                NewEmails.ForEach(x => x.SyncDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));

                objEmailDetailsRepository.SyncEmails(NewEmails);

                lblEmailsSynced.Text = "Synced Email(s):- " + NewEmails.Count.ToString();
                txtEmailID.Focus();
                MessageBox.Show("Emailed synced successfully.", "ECMS Tool - Ryder", MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            else
            {
                txtEmailID.Focus();
                lblEmailsSynced.Text = "-";
                MessageBox.Show("EmailID or folder not found in outlook.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            Cursor = Cursors.Default;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //txtEmailID.Text = "Pundlik.Pachupate@wns.com";
            cmbFolderName.Text = "Select";
            lblEmailsSynced.Text = "-";
        }
    }
}
