using System;

namespace InventoryManagement
{
	public class NumberToWordsConverter
	{
		private static string[] units = { "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine" };
		private static string[] teens = { "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen" };
		private static string[] tens = { "", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };
		private static string[] thousands = { "", "Thousand", "Million", "Billion" };

		public static string Convert(double number)
		{
			if (number == 0)
				return "Zero";

			int intPart = (int)number;
			int decimalPart = (int)((number - intPart) * 100);

			return $"{ConvertToWords(intPart)} and {ConvertToWords(decimalPart)} Paise";
		}

		private static string ConvertToWords(int number)
		{
			if (number == 0)
				return "";

			if (number < 10)
				return units[number];
			if (number < 20)
				return teens[number - 10];
			if (number < 100)
				return tens[number / 10] + (number % 10 > 0 ? " " + ConvertToWords(number % 10) : "");

			if (number < 1000)
				return units[number / 100] + " Hundred" + (number % 100 > 0 ? " and " + ConvertToWords(number % 100) : "");

			for (int i = 0; i < thousands.Length; i++)
			{
				int unitValue = (int)Math.Pow(1000, i + 1);
				if (number < unitValue)
					return ConvertToWords(number / (unitValue / 1000)) + " " + thousands[i] + (number % (unitValue / 1000) > 0 ? " " + ConvertToWords(number % (unitValue / 1000)) : "");
			}

			return number.ToString();
		}
	}
}
