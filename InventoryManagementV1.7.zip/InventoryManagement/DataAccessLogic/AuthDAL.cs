﻿using System;
using InventoryManagement.BusinessLogic;
using System.Windows.Forms;

namespace InventoryManagement.DataAccessLogic
{
    public class AuthDAL
    {
        public AuthDAL() 
        {
            DatabaseContext.CreateConnection();
        }

        public UserModel ValidateUser(string strEmail, string strPassword)
        {
            UserModel objUser = new UserModel();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT Code,FirstName,LastName,UserID,UserPassword,Mobile,Email,Role,IsActive,CompanyCode FROM tblUser WHERE Email = @Email and UserPassword = @Password and IsActive = 'Active'";

                DatabaseContext.dbcmd.Parameters.AddWithValue("Email", strEmail);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Password", strPassword);

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();

                while (DatabaseContext.dbdr.Read())
                {
                    objUser.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objUser.FirstName = Convert.ToString(DatabaseContext.dbdr["FirstName"]);
                    objUser.LastName = Convert.ToString(DatabaseContext.dbdr["LastName"]);
                    objUser.UserID = Convert.ToString(DatabaseContext.dbdr["UserID"]);
                    objUser.Password = Convert.ToString(DatabaseContext.dbdr["UserPassword"]);
                    objUser.Mobile = Convert.ToString(DatabaseContext.dbdr["Mobile"]);
                    objUser.Email = Convert.ToString(DatabaseContext.dbdr["Email"]);
                    objUser.Role = Convert.ToString(DatabaseContext.dbdr["Role"]);
                    objUser.IsActive = Convert.ToString(DatabaseContext.dbdr["IsActive"]);
                    objUser.CompanyCode = Convert.ToString(DatabaseContext.dbdr["CompanyCode"]);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return objUser;
        }

        public void ChangePassword(string strEmail, string strNewPassword)
        {
            UserModel objUser = new UserModel();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "UPDATE tblUser SET UserPassword = @Password WHERE Email = @Email and IsActive = 'Active'";

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.Parameters.AddWithValue("Password", strNewPassword);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Email", strEmail);
                
                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
