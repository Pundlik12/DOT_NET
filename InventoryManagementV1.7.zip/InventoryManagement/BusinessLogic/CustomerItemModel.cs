﻿
namespace InventoryManagement.BusinessLogic
{
    public class CustomerItemModel
    {
        public int Code { get; set; }
        public string CustomerCode { get; set; }
        public string CustomerName { get; set; }
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public string Rate { get; set; }
        public string GSTPercent { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDateTime { get; set; }
    }
}
