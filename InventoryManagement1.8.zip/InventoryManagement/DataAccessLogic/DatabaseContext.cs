﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.IO;
using System.Windows.Forms;

namespace InventoryManagement.DataAccessLogic
{
    public class DatabaseContext
    {
        public static OleDbConnection dbcon = null;
        public static OleDbCommand dbcmd = null;
        public static OleDbDataReader dbdr = null;
        public static OleDbDataAdapter dbAdapter = null;

        public static void CreateConnection()
        {
            if (dbcon == null)
            {
                dbcon = new OleDbConnection(common.strConnectionString);
            }
        }

        public static void OpenConnection()
        {
            if (dbcon != null)
            {
                if(dbcon.State == System.Data.ConnectionState.Closed)
                {
                    dbcon.Open();
                }                
            }            
        }

        public static void CloseConnection()
        {
            if (dbcon != null)
            {
                if (dbcon.State == System.Data.ConnectionState.Open)
                {
                    dbcon.Close();
                }
            }
        }

        public static void CreateCommand()
        {
            if (dbcmd == null)
            {
                dbcmd = new OleDbCommand();
                dbcmd.Connection = dbcon;
            }
        }

        public static void CreateAdapter(string cmdText)
        {
            dbAdapter = new OleDbDataAdapter(cmdText, dbcon);
        }

        public static void CreateDatabase_Objects()
        {
            string strScriptFilePath = String.Concat(System.AppDomain.CurrentDomain.BaseDirectory, @"scripts.txt");
            
            if (System.IO.File.Exists(strScriptFilePath))
            {
                bool isValid = false;
                Int32 iCommandCounter = 0;
                string strCommands = "";

                using (StreamReader sr = new StreamReader(strScriptFilePath))
                {
                    string strScriptText = sr.ReadToEnd();
                    string[] strQueries = strScriptText.Split('\n');
                    
                    if (strQueries.Length > 0)
                    {
                        isValid = true;
                        dbcon = new OleDbConnection(common.strConnectionString);
                        dbcmd = new OleDbCommand();
                        dbcmd.Connection = dbcon;
                        dbcmd.CommandType = System.Data.CommandType.Text;
                        
                        foreach (string strquery in strQueries)
                        {
                            dbcon.Open();
                            try
                            {
                                dbcmd.CommandText = strquery;
                                dbcmd.ExecuteNonQuery();
                            }
                            catch (System.Exception)
                            {
                                strCommands = strCommands + strquery + "\n";
                                iCommandCounter = iCommandCounter + 1;
                            }
                            dbcon.Close();
                        }
                    }
                }

                if (iCommandCounter > 0)
                {
                    MessageBox.Show($"{iCommandCounter} commands are not executed.\n\n" + strCommands, common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    if (isValid == true)
                    {
                        string newName = $"scripts{DateTime.Now.ToString("ddMMMyyyyhhmmss")}.txt";

                        string directory = Path.GetDirectoryName(strScriptFilePath);
                        string destinationPath = Path.Combine(directory, newName);

                        // Rename the file
                        File.Move(strScriptFilePath, destinationPath);
                    }
                }
            }
        }
    }
}
