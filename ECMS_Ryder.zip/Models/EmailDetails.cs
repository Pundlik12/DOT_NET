﻿using System;

namespace ECMS_Ryder.Models
{
    internal class EmailDetails
    {
        public Int32 EmailDetailsId { get; set; }
        public string EmailAddress { get; set; }
        public string FolderName { get; set; }
        public string SenderName { get; set; }
        public string SenderEmailAddress { get; set; }
        public string To { get; set; }
        public string Cc { get; set; }
        public string Bcc { get; set; }
        public string ReceivedTime { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public string Priority { get; set; }
        public string HasAttachments { get; set; }
        public string EntryID { get; set; }
        public string ConversationID { get; set; }
        public string Status { get; set; }
        public string SyncBy { get; set; }
        public string SyncDateTime { get; set; }
        public string LastUpdatedBy { get; set; }
        public string LastUpdatedDateTime { get; set; }
        public string AssignedBy { get; set; }
        public string AssignTo { get; set; }
        public string AssignedDateTime { get; set; }
        public string AccountNumber { get; set; }
    }
}
