﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace UnifeederAutomation
{
    public partial class frmMain : Form
    {
        clsAutomation Automation = null;

        public frmMain()
        {
            InitializeComponent();
            
            btnStart.Enabled = true;
            btnStop.Enabled = false;
            btnResume.Visible = false;
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            Screen scr = Screen.FromPoint(this.Location);
            this.Location = new Point(scr.WorkingArea.Right - this.Width, scr.WorkingArea.Top);
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if(clsDownloadChromeDriver.DownloadLatestVersion()== true)
            {
                timer1.Enabled = true;
                timer1.Start();
                btnStart.Enabled = false;
                btnStop.Enabled = true;

                Automation = new clsAutomation();
            }
            else
            {
                MessageBox.Show("Unable to run the automation, Please check the log.");
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            btnStart.Enabled = true;
            btnStop.Enabled = false;            
            Automation.thr.Abort();
            timer1.Enabled = false;
            timer1.Stop();
        }

        private void btnResume_Click(object sender, EventArgs e)
        {
         
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (Automation.isSucessful == true)
            {
                btnStart.Enabled = true;
                btnStop.Enabled = false;
                timer1.Enabled = false;
                timer1.Stop();
            }
        }
    }
}
