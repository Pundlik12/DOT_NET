﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;
using InventoryManagement.DataAccessLogic;

namespace InventoryManagement.UI
{
    public partial class frmPaymentList : Form
    {
        IGenericRepository<BillingModel> objBillingDal = null;

        public frmPaymentList()
        {
            InitializeComponent();
        }

        private void frmBillList_Load(object sender, EventArgs e)
        {
            objBillingDal = new BillingDAL();
            DisplayData();
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            DisplayData();
        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (e.ColumnIndex == 0)
                {
                    string ChallanNo = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["ChallanNo"].Value);
                    string CustomerNumber = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["CustomerCode"].Value);
                    string CustomerName = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["CustomerName"].Value);
                    string ChallanAmount = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["ChallanAmount"].Value);

                    Cursor.Current = Cursors.WaitCursor;
                    frmPaymentEntry objfrmPaymentEntry = new frmPaymentEntry(ChallanNo,ChallanAmount, CustomerNumber, CustomerName);
                    objfrmPaymentEntry.WindowState = FormWindowState.Normal;
                    objfrmPaymentEntry.StartPosition = FormStartPosition.CenterScreen;
                    objfrmPaymentEntry.Text = common.strProjectTitle + " : Payment Entry";
                    objfrmPaymentEntry.ShowDialog();
                    Cursor.Current = Cursors.Default;
                    DisplayData();
                }
            }
        }

        private void DisplayData()
        {
            List<BillingModel> lstFilteredData = null;
            List<BillingModel> lstData = objBillingDal.GetAll();
            
            if(txtName.Text != "")
            {
                lstFilteredData = lstData.Where(X=>X.CustomerName.Contains(txtName.Text)).ToList();
            }
            else
            {
                lstFilteredData = lstData;
            }

            dgvData.DataSource = lstFilteredData;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
