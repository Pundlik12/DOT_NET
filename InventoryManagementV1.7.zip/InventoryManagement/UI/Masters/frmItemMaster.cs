﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;
using InventoryManagement.DataAccessLogic;

namespace InventoryManagement
{
    public partial class frmItemMaster : Form
    {
        ItemModel objItemModel = null;
        IGenericRepository<ItemModel> objItemDal = null;

        public frmItemMaster()
        {
            InitializeComponent();
        }

        private void frmItemMaster_Load(object sender, EventArgs e)
        {
            objItemDal = new ItemDAL();
            ClearFields();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtName.Text.Trim() == "")
            {
                txtName.Focus();
                MessageBox.Show("Please enter name.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtGST.Text.Trim() == "")
            {
                txtGST.Focus();
                MessageBox.Show("Please enter GST %.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtHSN.Text.Trim() == "")
            {
                txtHSN.Focus();
                MessageBox.Show("Please enter HSN Number.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                Boolean isValid = false;
                try
                {
                    Convert.ToDouble(txtGST.Text.Trim());
                    isValid = true;
                }
                catch (Exception)
                {
                    isValid = false;
                }

                if (isValid == true)
                {
                    Cursor = Cursors.WaitCursor;
                    objItemModel = new ItemModel();
                    objItemModel.Name = txtName.Text.Trim();
                    objItemModel.GSTPercent = txtGST.Text.Trim();
                    objItemModel.HSNNumber = txtHSN.Text.Trim();
                    objItemModel.CreatedBy = common.strUserEmail;

                    if (btnSave.Text == "Save")
                    {
                        objItemDal.Add(objItemModel);
                        ClearFields();
                        //MessageBox.Show("Item details saved successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        objItemModel.Code = Convert.ToInt32(txtCode.Text);
                        objItemDal.Update(objItemModel);
                        ClearFields();
                        //MessageBox.Show("Item details updated successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    Cursor = Cursors.Default;
                }
                else
                {
                    MessageBox.Show("Please enter GST % in number.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
        }

        private void ClearFields()
        {
            txtCode.Text = "";
            txtName.Text = "";
            txtGST.Text = "";
            txtHSN.Text = "";
            btnSave.Text = "Save";
            dgvData.Enabled = true;
            txtName.Select();
            DisplayData();
        }

        private void DisplayData()
        {
            List<ItemModel> lstData = objItemDal.GetAll();
            List<ItemModel> lstFilteredData = null;

            if (txtNameSearch.Text != "")
            {
                lstFilteredData = lstData.Where(x=>x.Name.Contains(txtNameSearch.Text)).ToList();
            }            
            else
            {
                lstFilteredData = lstData;
            }

            dgvData.DataSource = lstFilteredData;
        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (e.ColumnIndex == 0)
                {
                    if (common.strUserRole == "Admin")
                    {
                        txtCode.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Code"].Value);
                        txtName.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["ItemName"].Value);
                        txtGST.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["GSTPercent"].Value);
                        txtHSN.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["HSNNumber"].Value);
                        btnSave.Text = "Update";
                        dgvData.Enabled = false;
                        txtName.Select();
                    }
                    else
                    {
                        MessageBox.Show("You do not have appropriate permission for this action.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                if (e.ColumnIndex == 1)
                {
                    if (common.strUserRole == "Admin")
                    {
                        if (MessageBox.Show("Do you want to delete?", common.strProjectTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            Int32 code = Convert.ToInt32(dgvData.Rows[e.RowIndex].Cells["Code"].Value);
                            objItemDal.Delete(code);

                            ClearFields();
                            //MessageBox.Show("Item details deleted successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MessageBox.Show("You do not have appropriate permission for this action.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtNameSearch_TextChanged(object sender, EventArgs e)
        {
            DisplayData();
        }
    }
}
