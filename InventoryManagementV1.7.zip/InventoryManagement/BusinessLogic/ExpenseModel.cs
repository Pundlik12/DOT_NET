﻿
namespace InventoryManagement.BusinessLogic
{
    public class ExpenseModel
    {
        public int Code { get; set; }
        public string TrnDate { get; set; }
        public string Mode { get; set; }
        public string Description { get; set; }
        public string Amount { get; set; }
        public string CompanyCode { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDateTime { get; set; }
    }
}
