﻿using System;
using System.Collections.Generic;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace UnifeederAutomation
{
    public class clsOutlook
    {
        public static Boolean SendOutlookEmail(string strToEmailAddress, string strSubject, string strBody,List<string> ltAttachments)
        {
            try
            {
                Outlook.Application app = new Outlook.Application();
                Outlook.MailItem mailItem = app.CreateItem(Outlook.OlItemType.olMailItem);

                mailItem.Subject = strSubject;
                mailItem.To = strToEmailAddress;
                mailItem.Body = strBody;

                foreach (string attachment in ltAttachments)
                {
                    mailItem.Attachments.Add(attachment);
                }

                mailItem.Importance = Outlook.OlImportance.olImportanceHigh;
                mailItem.Display(false);
                mailItem.Send();

                return true;
            }
            catch (Exception ex)
            {
                clsCommon.WriteLog("Error in SendOutlookEmail function " + ex.ToString());
                return false;
                //throw;
            }
        }
    }
}
