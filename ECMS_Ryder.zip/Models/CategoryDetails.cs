﻿
namespace ECMS_Ryder.Models
{
    internal class CategoryDetails
    {
        public int CategoryId { get; set; }
        public string Category { get; set; }
        //public string EntryUser { get; set; }
        //public string EntryDateTime { get; set; }
    }
}
