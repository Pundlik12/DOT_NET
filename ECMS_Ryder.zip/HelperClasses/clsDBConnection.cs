﻿using System;
using System.Configuration;
using System.IO;
using System.Windows.Forms;

namespace ECMS_Ryder.HelperClasses
{
    public static class clsDBConnection
    {
        public static string strLoggedInUID = "";
        public static string strLoggedInUserName = "";
        public static string strLoggedInUserRole = "";

        public static string strConnectionString = "";
        public static string strEmailAddress = "";
        public static string strErrorMsg = "";

        private static string strProvider = "";
        private static string strDataSource = "";
        private static string strDataBasePwd = "";

        public static void GetDBConnection()
        {
            strProvider = ConfigurationManager.AppSettings["Provider"].ToString();
            strDataSource = ConfigurationManager.AppSettings["DataSource"].ToString();
            strDataBasePwd = ConfigurationManager.AppSettings["PD"].ToString();

            //strDataSource = System.AppDomain.CurrentDomain.BaseDirectory + "Database\\DB.mdb";

            if (System.IO.File.Exists(strDataSource))
            {
                strConnectionString = "Provider={0}; Data Source= {1};JET OLEDB:Database Password={2}";
                strConnectionString = string.Format(strConnectionString, strProvider, strDataSource, strDataBasePwd);
            }
            else
            {
                MessageBox.Show("Database path is not configured or not accessible.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Environment.Exit(Environment.ExitCode);
            }
        }

        public static void CheckDatabaseSize()
        {
            try
            {
                //1.5 gigabyte = 1610612736 byte, 2 gigabyte = 2147483648 byte
                const long MARGIN_IN_BYTES = 1610612736;

                FileInfo mdb = new FileInfo(clsDBConnection.strDataSource);
                long len = mdb.Length;

                if (len > MARGIN_IN_BYTES)
                {
                    MessageBox.Show("Database size is exceeded 1.5 GB.Please contact WFM Automation team.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    Environment.Exit(Environment.ExitCode);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in CheckDatabaseSize:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }            
        }
    }
}
