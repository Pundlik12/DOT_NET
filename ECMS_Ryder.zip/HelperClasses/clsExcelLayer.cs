﻿using ECMS_Ryder.Models;
using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using MyExcelApp = Microsoft.Office.Interop.Excel;

namespace ECMS_Ryder.HelperClasses
{
    internal class clsExcelLayer
    {
        private MyExcelApp.Application excelApp;
        private MyExcelApp.Workbook xlwbk;
        private MyExcelApp.Worksheet xlsht;
        
        public List<CPIMDetails> ReadExcelWorkBook(string strFilePath)
        {
            Int32 iLastRow = 0;
            Int32 iCounter = 0;
            List<CPIMDetails> CPIMDetailsList = new List<CPIMDetails>();

            try
            {
                excelApp = new MyExcelApp.Application();
                excelApp.Visible = true;
                excelApp.DisplayAlerts = false;
                
                xlwbk = excelApp.Workbooks.Open(strFilePath);
                xlsht = (Worksheet)xlwbk.Worksheets[1];

                if(Convert.ToString(xlsht.Range["A1"].Value).ToUpper().Trim() == "HQNBR" && Convert.ToString(xlsht.Range["B1"].Value).ToUpper().Trim() == "CUSTNAME" && Convert.ToString(xlsht.Range["H1"].Value).ToUpper().Trim() == "NAME" && Convert.ToString(xlsht.Range["W1"].Value).ToUpper().Trim() == "UID")
                {
                    iLastRow = xlsht.Range["A" + xlsht.Rows.Count].End[MyExcelApp.XlDirection.xlUp].Row;

                    for (iCounter = 2; iCounter <= iLastRow; iCounter++)
                    {
                        xlsht.Range["A" + iCounter].Select();
                        string strHQNBR = Convert.ToString(xlsht.Range["A" + iCounter].Value);
                        string strCustomerName = Convert.ToString(xlsht.Range["B" + iCounter].Value);
                        string strAssignToUserName = Convert.ToString(xlsht.Range["H" + iCounter].Value);
                        string strAssignToUID = Convert.ToString(xlsht.Range["W" + iCounter].Value);

                        if (strHQNBR != "" && strCustomerName != "" & strAssignToUserName != "" && strAssignToUID != "")
                        {
                            CPIMDetails cPIMDetails = new CPIMDetails();
                            cPIMDetails.HQNBR = strHQNBR;
                            cPIMDetails.CustomerName = strCustomerName;
                            cPIMDetails.AssignToUserName = strAssignToUserName;
                            cPIMDetails.AssignToUID = strAssignToUID;
                            cPIMDetails.UploadUser = clsDBConnection.strLoggedInUID;
                            cPIMDetails.UploadDateTime = DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss");

                            CPIMDetailsList.Add(cPIMDetails);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Invalid file format.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error in ReadExcelWorkBook:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                xlwbk.Close(false);
                excelApp.Quit();
            }

            return CPIMDetailsList;
        }

        public void ExportToExcel(System.Data.DataTable DataTable, string strOutputFilePath)
        {
            try
            {
                int ColumnsCount;

                if (DataTable == null || (ColumnsCount = DataTable.Columns.Count) == 0)
                {
                    MessageBox.Show("ExportToExcel: Null or empty input table!\n", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                
                object misValue = System.Reflection.Missing.Value;

                MyExcelApp.Application xlApp = new MyExcelApp.Application();
                xlApp.Visible = true;
                xlApp.DisplayAlerts = false;

                MyExcelApp.Workbook xlWbk = xlApp.Workbooks.Add(misValue);
                MyExcelApp.Worksheet xlSht = (MyExcelApp.Worksheet)xlWbk.Worksheets[1];
                xlSht.Name = "DownloadReport";
                xlSht.Activate();

                object[] Header = new object[ColumnsCount];

                // column headings               
                for (int i = 0; i < ColumnsCount; i++)
                    Header[i] = DataTable.Columns[i].ColumnName;

                MyExcelApp.Range HeaderRange = xlSht.get_Range((MyExcelApp.Range)(xlSht.Cells[1, 1]), (MyExcelApp.Range)(xlSht.Cells[1, ColumnsCount]));
                HeaderRange.Value = Header;
                HeaderRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGray);
                HeaderRange.Font.Bold = true;

                // DataCells
                int RowsCount = DataTable.Rows.Count;
                object[,] Cells = new object[RowsCount, ColumnsCount];

                for (int j = 0; j < RowsCount; j++)
                    for (int i = 0; i < ColumnsCount; i++)
                        Cells[j, i] = DataTable.Rows[j][i];

                xlSht.get_Range((MyExcelApp.Range)(xlSht.Cells[2, 1]), (MyExcelApp.Range)(xlSht.Cells[RowsCount + 1, ColumnsCount])).Value = Cells;

                try
                {
                    xlSht.Columns.AutoFit();
                    xlSht.SaveAs(strOutputFilePath);
                    xlApp.Quit();

                    MessageBox.Show("File is downloaded sucessfully.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("ExportToExcel:\nExcel file could not be saved! Check file path.\n" + ex.Message, "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ExportToExcel: \n" + ex.Message, "ECMS Tool - Ryder", MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }
        
    }
}
