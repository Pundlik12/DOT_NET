﻿using System;

namespace HBAccessTool
{
    public class UserModel
    {
        public int UserID { get; set; }
        public string Uid { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string DisplayName { get; set; }
        public string Role { get; set; }
        public int IsActive { get; set; }
        public int EntryID { get; set; }
        public DateTime EntryDateTime { get; set; }
    }
}
