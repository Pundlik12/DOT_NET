﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;

namespace InventoryManagement.DataAccessLogic
{
    public class ExpenseDAL : IGenericRepository<ExpenseModel>
    {
        string strQuery = "";
        public ExpenseDAL()
        {
            DatabaseContext.CreateConnection();
        }

        public List<ExpenseModel> GetAll()
        {
            List<ExpenseModel> lstData = new List<ExpenseModel>();
            try
            {
                string strTrnDate = "31-DEC-" + DateTime.Now.AddYears(-1).ToString("yyyy");

                strQuery = "";
                strQuery = strQuery + "SELECT Code,TrnDate,Mode,Description,Amount,CompanyCode,CreatedBy,CreatedDateTime\n";
                strQuery = strQuery + "FROM tblExpense\n";
                strQuery = strQuery + "WHERE TrnDate >= cdate('" + strTrnDate + "') AND CompanyCode = " + common.strCompanyCode + "\n";
                strQuery = strQuery + "ORDER BY TrnDate DESC";

                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = strQuery;
                
                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    ExpenseModel objExpense = new ExpenseModel();

                    objExpense.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objExpense.TrnDate = Convert.ToString(DatabaseContext.dbdr["TrnDate"]);
                    objExpense.Mode = Convert.ToString(DatabaseContext.dbdr["Mode"]);
                    objExpense.Description = Convert.ToString(DatabaseContext.dbdr["Description"]);
                    objExpense.Amount = Convert.ToString(DatabaseContext.dbdr["Amount"]);
                    objExpense.CompanyCode = Convert.ToString(DatabaseContext.dbdr["CompanyCode"]);
                    objExpense.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objExpense.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objExpense);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public List<ExpenseModel> GetByDates(string strFromDate, string strToDate)
        {
            List<ExpenseModel> lstData = new List<ExpenseModel>();
            try
            {
                strQuery = "";
                strQuery = strQuery + "SELECT Code,TrnDate,Mode,Description,Amount,CompanyCode,CreatedBy,CreatedDateTime\n";
                strQuery = strQuery + "FROM tblExpense\n";
                strQuery = strQuery + "WHERE TrnDate >= cdate('" + strFromDate + "') and TrnDate <=cdate('" + strToDate + "') AND CompanyCode = " + common.strCompanyCode + "\n";
                strQuery = strQuery + "ORDER BY TrnDate DESC";

                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = strQuery;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();

                while (DatabaseContext.dbdr.Read())
                {
                    ExpenseModel objExpense = new ExpenseModel();

                    objExpense.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objExpense.TrnDate = Convert.ToString(DatabaseContext.dbdr["TrnDate"]);
                    objExpense.Mode = Convert.ToString(DatabaseContext.dbdr["Mode"]);
                    objExpense.Description = Convert.ToString(DatabaseContext.dbdr["Description"]);
                    objExpense.Amount = Convert.ToString(DatabaseContext.dbdr["Amount"]);
                    objExpense.CompanyCode = Convert.ToString(DatabaseContext.dbdr["CompanyCode"]);
                    objExpense.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objExpense.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objExpense);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public ExpenseModel GetByID(Int32 UserCode)
        {
            ExpenseModel objExpense = new ExpenseModel();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT Code,TrnDate,Mode,Description,Amount,CompanyCode,CreatedBy,CreatedDateTime FROM tblExpense WHERE Code = " + UserCode;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    objExpense.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objExpense.TrnDate = Convert.ToString(DatabaseContext.dbdr["TrnDate"]);
                    objExpense.Mode = Convert.ToString(DatabaseContext.dbdr["Mode"]);
                    objExpense.Description = Convert.ToString(DatabaseContext.dbdr["Description"]);
                    objExpense.Amount = Convert.ToString(DatabaseContext.dbdr["Amount"]);
                    objExpense.CompanyCode = Convert.ToString(DatabaseContext.dbdr["CompanyCode"]);
                    objExpense.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objExpense.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return objExpense;
        }

        public void Add(ExpenseModel objExpense)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "INSERT INTO tblExpense (TrnDate,Mode,Description,Amount,CompanyCode,CreatedBy,CreatedDateTime) VALUES(@TrnDate,@Mode,@Description,@Amount,@CompanyCode,@CreatedBy,@CreatedDateTime)";
                
                DatabaseContext.dbcmd.Parameters.AddWithValue("TrnDate", objExpense.TrnDate);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Mode", objExpense.Mode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Description", objExpense.Description);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Amount", objExpense.Amount);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CompanyCode", common.strCompanyCode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objExpense.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Update(ExpenseModel objExpense)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "UPDATE tblExpense SET TrnDate = @TrnDate,Mode = @Mode,Description = @Description,Amount = @Amount,CreatedBy = @CreatedBy,CreatedDateTime = @CreatedDateTime WHERE Code = " + objExpense.Code;

                DatabaseContext.dbcmd.Parameters.AddWithValue("TrnDate", objExpense.TrnDate);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Mode", objExpense.Mode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Description", objExpense.Description);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Amount", objExpense.Amount);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objExpense.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Delete(Int32 ExpenseCode)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "DELETE FROM tblExpense WHERE Code = " + ExpenseCode;
                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
