﻿using System;
using System.IO;
using System.Linq;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Collections.Generic;
using System.Configuration;

namespace UnifeederAutomation
{
    public class clsAutomation
    {
        public Thread thr;
        public Boolean isSucessful = false;
        IWebDriver driver = null;
        ChromeOptions options = null;
        IWebElement element = null;
        Boolean isElementFound = false;
        Boolean isDownloadCompleted = false;
        
        string UserID = "";
        string UserPWD = "";
        string strURL = "";
        string ShareDrivePath = "";
        string DownloadDrivePath = "";
        string ZipFilePath = "";
        string ZipFolderPath = "";

        public clsAutomation()
        {
            strURL = ConfigurationManager.AppSettings["WebsiteURL"].ToString();
            UserID = ConfigurationManager.AppSettings["UserID"].ToString();
            UserPWD = ConfigurationManager.AppSettings["UserPWD"].ToString();

            ShareDrivePath = ConfigurationManager.AppSettings["ShareDrivePath"].ToString();
            DownloadDrivePath = ConfigurationManager.AppSettings["DownloadDrivePath"].ToString();
            ZipFilePath = DownloadDrivePath + "\\Bescheide.zip";
            ZipFolderPath = ZipFilePath.Replace(".zip", "");

            thr = new Thread(Automate);
            thr.Name = "Automation Thread";
            thr.Start();

            //RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Internet Explorer\Main");
            //if (key != null)
            //{
            //    DownloadDrivePath = Convert.ToString(key.GetValue("Default Download Directory"));
            //}
            //else if (string.IsNullOrEmpty(DownloadDrivePath))
            //{
            //    DownloadDrivePath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\Downloads";
            //}
            //DownloadDrivePath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\Downloads\\Bescheide.zip";
        }

        public void Automate()
        {
            try
            {
                clsCommon.WriteLog("*****Automation process for download pdf Started*****");

                if (System.IO.Directory.Exists(DownloadDrivePath) == false)
                {
                    System.IO.Directory.CreateDirectory(DownloadDrivePath);
                    Thread.Sleep(500);
                    clsCommon.WriteLog("Downloads folder created.");
                }

                //Delete zip file
                if (System.IO.File.Exists(ZipFilePath))
                {
                    System.IO.File.Delete(ZipFilePath);
                    Thread.Sleep(500);
                    clsCommon.WriteLog("Previously downloaded file deleted.");
                }

                //Delete zip folder
                if (System.IO.Directory.Exists(ZipFolderPath))
                {
                    System.IO.Directory.Delete(ZipFolderPath);
                    Thread.Sleep(500);
                    clsCommon.WriteLog("Previously downloaded folder deleted.");
                }

                options = new ChromeOptions();
                options.PageLoadStrategy = PageLoadStrategy.Eager;
                options.AddUserProfilePreference("download.default_directory", DownloadDrivePath);
                options.AddExcludedArgument("enable-automation");
                options.AddAdditionalCapability("useAutomationExtension", false);

                TimeSpan CommandTimeOut = TimeSpan.FromSeconds(120);
                driver = new ChromeDriver(ChromeDriverService.CreateDefaultService(), options, CommandTimeOut);
                driver.Manage().Window.Maximize();

                driver.Navigate().GoToUrl(strURL);
                clsCommon.WriteLog("Website opened.");
                Thread.Sleep(500);

                element = driver.FindElement(By.Id("benutzername"));
                element.SendKeys(UserID);
                clsCommon.WriteLog("User Name entered.");
                Thread.Sleep(500);

                element = driver.FindElement(By.Id("passwort"));
                element.SendKeys(UserPWD);
                clsCommon.WriteLog("Password entered.");
                Thread.Sleep(500);

                element = driver.FindElement(By.Id("submit_0"));
                element.SendKeys(Keys.Enter);
                clsCommon.WriteLog("Login button clicked.");
                Thread.Sleep(500);

                while (isElementFound == false)
                {
                    try
                    {
                        Thread.Sleep(500);
                        element = driver.FindElement(By.CssSelector("#menueitemsubtitle > li:nth-child(5) > a"));
                        isElementFound = true;
                    }
                    catch (Exception)
                    {
                        isElementFound = false;
                    }
                }

                element.Click();
                clsCommon.WriteLog("Menu option selected.");
                Thread.Sleep(500);

                isElementFound = false;
                while (isElementFound == false)
                {
                    try
                    {
                        Thread.Sleep(500);
                        element = driver.FindElement(By.Id("allesAuswahl"));
                        isElementFound = true;
                    }
                    catch (Exception)
                    {
                        isElementFound = false;
                    }
                }

                element.Click();
                clsCommon.WriteLog("Select All button clicked.");
                Thread.Sleep(3000);

                element = driver.FindElement(By.Id("pdf"));
                element.Click();
                clsCommon.WriteLog("Download pdf button clicked.");
                Thread.Sleep(1000);

                element = driver.FindElement(By.Id("suchfeld"));//Textbox
                element.Click();

                bool fileExists = false;
                while (fileExists == false)
                {
                    Thread.Sleep(1000);
                    element.Click();//to keep window alive
                    fileExists = File.Exists(ZipFilePath);
                    if (fileExists == true)
                    {
                        break;
                    }
                }

                Thread.Sleep(500);
                driver.Quit();
                clsCommon.WriteLog("****Download pdf files process completed****");
                isDownloadCompleted = true;
            }
            catch (Exception ex)
            {
                isDownloadCompleted = false;
                clsCommon.WriteLog("Error In Automate Function:- " + ex.ToString());
                if (driver != null)
                {
                    driver.Quit();
                }
            }

            if (isDownloadCompleted == true)
            {
                GetUniqueFiles();
            }

            isSucessful = true;
        }

        private void GetUniqueFiles()
	    {
            try
            {
                clsCommon.ExtractZipFiles(ZipFilePath);
                clsCommon.WriteLog("PDF file extraction completed.");

                List<string> lstDownloadFiles = clsCommon.GetAllFiles(ZipFolderPath, "pdf");
                clsCommon.WriteLog("Extracted files retrieved.");

                List<string> lstBaseFiles = clsCommon.GetAllFiles(ShareDrivePath,"pdf");
                clsCommon.WriteLog("Shared drive files retrieved.");

                //Create query to get new files.
                var NewFiles = lstDownloadFiles.Except(lstBaseFiles);
                List<string> lstOutlookFiles = new List<string>();
                clsCommon.WriteLog("New files retrieved.");

                //Copy all new files to share drive path
                foreach (var BaseItem in NewFiles)
                {
                    string strSourceFileName = ZipFolderPath + @"\" + BaseItem;
                    string strDestinationFileName = ShareDrivePath + @"\" + BaseItem;

                    File.Copy(strSourceFileName, strDestinationFileName);
                    Thread.Sleep(1000);
                    lstOutlookFiles.Add(strDestinationFileName);
                }

                clsCommon.WriteLog("New files copied to share drive.");
                
                System.IO.File.Delete(ZipFilePath);//Delete zip file
                clsCommon.DeleteFolder(ZipFolderPath);//Delete zip folder
                System.IO.Directory.Delete(ZipFolderPath);
                clsCommon.WriteLog("Download files and folders deleted.");

                if (lstOutlookFiles.Count > 0)
                {
                    string strToEmailAddress = ConfigurationManager.AppSettings["ToEmailAddress"].ToString();
                    string strSubject = ConfigurationManager.AppSettings["Subject"].ToString() + DateTime.Now.ToString("dd-MMM-yyyy");
                    string strBody = ConfigurationManager.AppSettings["Body"].ToString();

                    clsOutlook.SendOutlookEmail(strToEmailAddress, strSubject, strBody, lstOutlookFiles);
                    clsCommon.WriteLog("Email sent.");
                }
            }
            catch (Exception ex)
            {
                clsCommon.WriteLog("Error In GetUniqueFiles Function:- " + ex.ToString());
            }
	    }
    }
}
