﻿using System;
using System.Data;
using System.Data.OleDb;
using ECMS_Ryder.Models;
using System.Collections.Generic;
using System.Windows.Forms;
using ECMS_Ryder.HelperClasses;

namespace ECMS_Ryder.Repositories
{
    interface iCPIMDetailsRepository
    {
        List<CPIMDetails> GetAllCPIMDetails();
        void UploadCPIMDetails(List<CPIMDetails> lstCPIMDetails);
    }

    internal class CPIMDetailsRepository : iCPIMDetailsRepository
    {
        private readonly string strConnectionString = "";

        public CPIMDetailsRepository(string _strConnectionString)
        {
            strConnectionString = _strConnectionString;
        }

        public List<CPIMDetails> GetAllCPIMDetails()
        {
            List<CPIMDetails> lstCPIMDetails = new List<CPIMDetails>();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "GetAllCPIMDetails";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;

                    OleDbDataReader OleDbDataReader = cmd.ExecuteReader();

                    while (OleDbDataReader.Read())
                    {
                        CPIMDetails cPIMDetails = new CPIMDetails();
                        cPIMDetails.CPIMDetailsID = Convert.ToInt32(OleDbDataReader["CPIMDetailsID"]);
                        cPIMDetails.HQNBR = Convert.ToString(OleDbDataReader["HQNBR"]);
                        cPIMDetails.CustomerName = Convert.ToString(OleDbDataReader["CustomerName"]);
                        cPIMDetails.AssignToUserName = Convert.ToString(OleDbDataReader["AssignToUserName"]);
                        cPIMDetails.AssignToUID = Convert.ToString(OleDbDataReader["AssignToUID"]);
                        cPIMDetails.UploadUser = Convert.ToString(OleDbDataReader["UploadUser"]);
                        cPIMDetails.UploadDateTime = Convert.ToString(OleDbDataReader["UploadDateTime"]);

                        lstCPIMDetails.Add(cPIMDetails);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetAllCPIMDetails:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lstCPIMDetails = null;
            }

            return lstCPIMDetails;
        }

        public void UploadCPIMDetails(List<CPIMDetails> lstCPIMDetails)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "DeleteAllCPIMDetails";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.ExecuteNonQuery();

                    foreach (var item in lstCPIMDetails) 
                    {
                        cmd = new OleDbCommand();
                        cmd.Connection = connection;
                        cmd.CommandText = "UploadCPIMDetails";
                        cmd.CommandTimeout = 0;
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@HQNBR", item.HQNBR);
                        cmd.Parameters.AddWithValue("@CustomerName", item.CustomerName);
                        cmd.Parameters.AddWithValue("@AssignToUserName", item.AssignToUserName);
                        cmd.Parameters.AddWithValue("@AssignToUID", item.AssignToUID);
                        cmd.Parameters.AddWithValue("@UploadUser", clsDBConnection.strLoggedInUID);
                        cmd.Parameters.AddWithValue("@UploadDateTime", item.UploadDateTime);

                        cmd.ExecuteNonQuery();
                    }

                    cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "AllocateEmailsFromCPIMDetails";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;
                    
                    cmd.ExecuteNonQuery();

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in UploadCPIMDetails:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
