﻿
namespace ECMS_Ryder.Models
{
    public enum UserStatus
    {
        Active,
        InActive
    }
}
