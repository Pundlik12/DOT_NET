﻿
using ECMS_Ryder.HelperClasses;
using ECMS_Ryder.Repositories;
using System;
using System.Data;
using System.Windows.Forms;

namespace ECMS_Ryder.Forms
{
    public partial class frmDownloadReport : Form
    {
        private readonly DownloadReportRepository objDownloadReportRepository;
        private readonly clsExcelLayer objClsExcelLayer;
        private DataTable data = new DataTable();

        public frmDownloadReport()
        {
            InitializeComponent();

            objDownloadReportRepository = new DownloadReportRepository(clsDBConnection.strConnectionString);
            objClsExcelLayer = new clsExcelLayer();

            if (clsDBConnection.strLoggedInUserRole != "Admin")
            {
                rbUnAssigned.Enabled = false;
                rbAll.Enabled = false;
            }
        }

        private void rbAll_CheckedChanged(object sender, EventArgs e)
        {
            dgvEmails.DataSource = null;
            data = null;
        }

        private void rbUnAssigned_CheckedChanged(object sender, EventArgs e)
        {
            dgvEmails.DataSource = null;
            data = null;
        }

        private void rbAssigned_CheckedChanged(object sender, EventArgs e)
        {
            dgvEmails.DataSource = null;
            data = null;
        }

        private void rbCompleted_CheckedChanged(object sender, EventArgs e)
        {
            dgvEmails.DataSource = null;
            data = null;
        }

        private void btnView_Click(object sender, System.EventArgs e)
        {
            DisplayData();
        }

        private void btnDownload_Click(object sender, System.EventArgs e)
        {
            if(dgvEmails.Rows.Count == 0) 
            {
                DisplayData();
            }

            string strOutputFilePath = System.AppDomain.CurrentDomain.BaseDirectory + "Download Reports";

            if (System.IO.Directory.Exists(strOutputFilePath) == false)
            {
                System.IO.Directory.CreateDirectory(strOutputFilePath);
            }

            if (rbAll.Checked == true)
            {
                strOutputFilePath = strOutputFilePath + "\\All_" + DateTime.Now.ToString("ddMMMyyyy HHmmss") + ".xlsx";
            }
            else if (rbUnAssigned.Checked == true)
            {
                strOutputFilePath = strOutputFilePath + "\\UnAssigned_" + DateTime.Now.ToString("ddMMMyyyy HHmmss") + ".xlsx";
            }
            else if (rbAssigned.Checked == true)
            {
                strOutputFilePath = strOutputFilePath + "\\Assigned_" + DateTime.Now.ToString("ddMMMyyyy HHmmss") + ".xlsx";
            }
            else if (rbCompleted.Checked == true)
            {
                strOutputFilePath = strOutputFilePath + "\\Completed_" + DateTime.Now.ToString("ddMMMyyyy HHmmss") + ".xlsx";
            }

            objClsExcelLayer.ExportToExcel(data, strOutputFilePath);
        }

        private void DisplayData()
        {
            Cursor = Cursors.WaitCursor;

            if (rbAll.Checked == true)
            {
                data = objDownloadReportRepository.DownloadAllEmails();
            }
            else if (rbUnAssigned.Checked == true)
            {
                data = objDownloadReportRepository.DownloadUnAssignedEmails();
            }
            else if (rbAssigned.Checked == true)
            {
                data = objDownloadReportRepository.DownloadAssignedEmails();
            }
            else if (rbCompleted.Checked == true) 
            {
                data = objDownloadReportRepository.DownloadCompletedEmails();
            }

            dgvEmails.DataSource = data;
            lblEmailsCount.Text = data.Rows.Count.ToString();

            Cursor = Cursors.Default;
        }
    }
}
