﻿namespace ChatApp
{
    partial class frmAddIPAddress
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            splitContainer1 = new SplitContainer();
            groupBox1 = new GroupBox();
            btnAdd = new Button();
            txtHostName = new TextBox();
            label3 = new Label();
            txtIPAddress = new TextBox();
            label2 = new Label();
            txtUserName = new TextBox();
            label1 = new Label();
            groupBox2 = new GroupBox();
            dgvHostInfo = new DataGridView();
            Edit = new DataGridViewLinkColumn();
            Delete = new DataGridViewLinkColumn();
            UserName = new DataGridViewTextBoxColumn();
            IPAddress = new DataGridViewTextBoxColumn();
            HostName = new DataGridViewTextBoxColumn();
            GUID = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvHostInfo).BeginInit();
            SuspendLayout();
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(0, 0);
            splitContainer1.Name = "splitContainer1";
            splitContainer1.Orientation = Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.Controls.Add(groupBox1);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(groupBox2);
            splitContainer1.Size = new Size(470, 478);
            splitContainer1.SplitterDistance = 188;
            splitContainer1.TabIndex = 0;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnAdd);
            groupBox1.Controls.Add(txtHostName);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(txtIPAddress);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(txtUserName);
            groupBox1.Controls.Add(label1);
            groupBox1.Dock = DockStyle.Fill;
            groupBox1.Location = new Point(0, 0);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(470, 188);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(102, 141);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(89, 39);
            btnAdd.TabIndex = 6;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // txtHostName
            // 
            txtHostName.CharacterCasing = CharacterCasing.Upper;
            txtHostName.Font = new Font("Segoe UI", 11.25F);
            txtHostName.Location = new Point(103, 104);
            txtHostName.MaxLength = 30;
            txtHostName.Name = "txtHostName";
            txtHostName.Size = new Size(348, 27);
            txtHostName.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.25F);
            label3.Location = new Point(11, 107);
            label3.Name = "label3";
            label3.Size = new Size(87, 20);
            label3.TabIndex = 4;
            label3.Text = "Host Name:";
            // 
            // txtIPAddress
            // 
            txtIPAddress.Font = new Font("Segoe UI", 11.25F);
            txtIPAddress.Location = new Point(103, 62);
            txtIPAddress.MaxLength = 20;
            txtIPAddress.Name = "txtIPAddress";
            txtIPAddress.Size = new Size(348, 27);
            txtIPAddress.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11.25F);
            label2.Location = new Point(16, 64);
            label2.Name = "label2";
            label2.Size = new Size(81, 20);
            label2.TabIndex = 2;
            label2.Text = "IP Address:";
            // 
            // txtUserName
            // 
            txtUserName.CharacterCasing = CharacterCasing.Upper;
            txtUserName.Font = new Font("Segoe UI", 11.25F);
            txtUserName.Location = new Point(103, 20);
            txtUserName.MaxLength = 30;
            txtUserName.Name = "txtUserName";
            txtUserName.Size = new Size(348, 27);
            txtUserName.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F);
            label1.Location = new Point(13, 24);
            label1.Name = "label1";
            label1.Size = new Size(85, 20);
            label1.TabIndex = 0;
            label1.Text = "User Name:";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(dgvHostInfo);
            groupBox2.Dock = DockStyle.Fill;
            groupBox2.Location = new Point(0, 0);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(470, 286);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            // 
            // dgvHostInfo
            // 
            dgvHostInfo.AllowUserToAddRows = false;
            dgvHostInfo.AllowUserToDeleteRows = false;
            dgvHostInfo.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dgvHostInfo.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvHostInfo.Columns.AddRange(new DataGridViewColumn[] { Edit, Delete, UserName, IPAddress, HostName, GUID });
            dgvHostInfo.Dock = DockStyle.Fill;
            dgvHostInfo.Location = new Point(3, 19);
            dgvHostInfo.Name = "dgvHostInfo";
            dgvHostInfo.ReadOnly = true;
            dgvHostInfo.RowHeadersVisible = false;
            dgvHostInfo.Size = new Size(464, 264);
            dgvHostInfo.TabIndex = 0;
            dgvHostInfo.CellContentClick += dgvHostInfo_CellContentClick;
            // 
            // Edit
            // 
            Edit.HeaderText = "Edit";
            Edit.Name = "Edit";
            Edit.ReadOnly = true;
            Edit.Text = "Edit";
            Edit.UseColumnTextForLinkValue = true;
            Edit.Width = 33;
            // 
            // Delete
            // 
            Delete.HeaderText = "Delete";
            Delete.Name = "Delete";
            Delete.ReadOnly = true;
            Delete.Text = "Delete";
            Delete.UseColumnTextForLinkValue = true;
            Delete.Width = 46;
            // 
            // UserName
            // 
            UserName.DataPropertyName = "UserName";
            UserName.HeaderText = "UserName";
            UserName.Name = "UserName";
            UserName.ReadOnly = true;
            UserName.Width = 87;
            // 
            // IPAddress
            // 
            IPAddress.DataPropertyName = "IPAddress";
            IPAddress.HeaderText = "IPAddress";
            IPAddress.Name = "IPAddress";
            IPAddress.ReadOnly = true;
            IPAddress.Width = 83;
            // 
            // HostName
            // 
            HostName.DataPropertyName = "HostName";
            HostName.HeaderText = "HostName";
            HostName.Name = "HostName";
            HostName.ReadOnly = true;
            HostName.Width = 89;
            // 
            // GUID
            // 
            GUID.DataPropertyName = "GUID";
            GUID.HeaderText = "GUID";
            GUID.Name = "GUID";
            GUID.ReadOnly = true;
            GUID.Width = 59;
            // 
            // frmAddIPAddress
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(470, 478);
            Controls.Add(splitContainer1);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            Name = "frmAddIPAddress";
            SizeGripStyle = SizeGripStyle.Hide;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "IP Address Master";
            Load += frmAddIPAddress_Load;
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvHostInfo).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private SplitContainer splitContainer1;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private Label label1;
        private TextBox txtUserName;
        private TextBox txtHostName;
        private Label label3;
        private TextBox txtIPAddress;
        private Label label2;
        private Button btnAdd;
        private DataGridView dgvHostInfo;
        private DataGridViewLinkColumn Edit;
        private DataGridViewLinkColumn Delete;
        private DataGridViewTextBoxColumn UserName;
        private DataGridViewTextBoxColumn IPAddress;
        private DataGridViewTextBoxColumn HostName;
        private DataGridViewTextBoxColumn GUID;
    }
}