﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace HBAccessTool
{
    public class AuxRepository : iAuxDetails
    {
        OleDbConnection dbcon = null;
        OleDbCommand dbcmd = null;
        OleDbDataReader dbdr = null;
        
        List<AuxModel> lstAux = null;
        AuxModel objAux = null;

        public bool CreateTables()
        {
            Boolean isSucess = false;
            try
            {
                string tblAuxDetails = "CREATE TABLE tblAuxDetails ";
                tblAuxDetails = tblAuxDetails + "(AuxDetailsID AUTOINCREMENT PRIMARY KEY,";
                tblAuxDetails = tblAuxDetails + "UserID INTEGER NOT NULL,";
                tblAuxDetails = tblAuxDetails + "AuxName Varchar(100) NOT NULL,";
                tblAuxDetails = tblAuxDetails + "StartTime DATETIME NOT NULL,";
                tblAuxDetails = tblAuxDetails + "EndTime DATETIME,";
                tblAuxDetails = tblAuxDetails + "ParentAuxDetailsID INTEGER NULL);";

                string[] arrTables = { tblAuxDetails };

                foreach (string strTable in arrTables)
                {
                    try
                    {
                        using (OleDbConnection OleDbcon = new OleDbConnection(clsDBConnection.strConstr))
                        {
                            OleDbCommand cmd = new OleDbCommand();
                            cmd.Connection = OleDbcon;

                            cmd.CommandText = strTable;
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandTimeout = 0;

                            OleDbcon.Open();
                            cmd.ExecuteNonQuery();
                            OleDbcon.Close();
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                    }
                }

                isSucess = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                isSucess = false;
            }

            return isSucess;
        }

        public bool DROPTables()
        {
            Boolean isSucess = false;
            try
            {
                string tblUser = "DROP TABLE tblAuxDetails";
                string[] arrTables = { tblUser };

                foreach (string strTable in arrTables)
                {
                    try
                    {
                        using (OleDbConnection OleDbcon = new OleDbConnection(clsDBConnection.strConstr))
                        {
                            OleDbCommand cmd = new OleDbCommand();
                            cmd.Connection = OleDbcon;

                            cmd.CommandText = strTable;
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandTimeout = 0;

                            OleDbcon.Open();
                            cmd.ExecuteNonQuery();
                            OleDbcon.Close();
                        }
                    }
                    catch (Exception)
                    {
                    }
                }

                isSucess = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                isSucess = false;
            }

            return isSucess;
        }

        public List<AuxModel> GetAllAuxDetails()
        {
            try
            {
                using (dbcon = new OleDbConnection())
                {
                    dbcon.ConnectionString = clsDBConnection.strConstr;
                    using (dbcmd = new OleDbCommand())
                    {
                        dbcon.Open();
                        dbcmd.Connection = dbcon;
                        dbcmd.CommandType = System.Data.CommandType.Text;
                        dbcmd.CommandText = "SELECT * FROM tblAuxDetails";
                        dbcmd.CommandTimeout = 0;
                        dbdr = dbcmd.ExecuteReader();

                        lstAux = new List<AuxModel>();
                        while (dbdr.Read())
                        {
                            objAux = new AuxModel();                            
                            objAux.AuxDetailsID = Convert.ToInt32(dbdr["AuxDetailsID"]);
                            objAux.UserID = Convert.ToInt32(dbdr["UserID"]);
                            objAux.AuxName = Convert.ToString(dbdr["AuxName"]);
                            objAux.StartTime = Convert.ToDateTime(dbdr["StartTime"]);
                            objAux.EndTime = Convert.ToDateTime(dbdr["EndTime"]);
                            objAux.ParentAuxDetailsID = Convert.ToInt32(dbdr["ParentAuxDetailsID"]);
                            lstAux.Add(objAux);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                lstAux = null;
                MessageBox.Show(ex.ToString(), "GetAllAuxDetails", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

            return lstAux;
        }

        public AuxModel GetAuxDetailsByAuxID(int AuxId)
        {
            try
            {
                using (dbcon = new OleDbConnection())
                {
                    dbcon.ConnectionString = clsDBConnection.strConstr;
                    using (dbcmd = new OleDbCommand())
                    {
                        dbcon.Open();
                        dbcmd.Connection = dbcon;
                        dbcmd.CommandType = System.Data.CommandType.Text;
                        dbcmd.CommandText = "SELECT * FROM tblAuxDetails WHERE AuxDetailsID = " + AuxId;
                        dbcmd.CommandTimeout = 0;
                        dbdr = dbcmd.ExecuteReader();

                        lstAux = new List<AuxModel>();
                        while (dbdr.Read())
                        {
                            objAux = new AuxModel();
                            objAux.AuxDetailsID = Convert.ToInt32(dbdr["AuxDetailsID"]);
                            objAux.UserID = Convert.ToInt32(dbdr["UserID"]);
                            objAux.AuxName = Convert.ToString(dbdr["AuxName"]);
                            objAux.StartTime = Convert.ToDateTime(dbdr["StartTime"]);
                            objAux.EndTime = Convert.ToDateTime(dbdr["EndTime"]);
                            objAux.ParentAuxDetailsID = Convert.ToInt32(dbdr["ParentAuxDetailsID"]);
                            lstAux.Add(objAux);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                objAux = null;
                MessageBox.Show(ex.ToString(), "GetAuxDetailsByAuxID", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

            return objAux;
        }

        public AuxModel GetAuxDetailsByUserID(int UserId)
        {
            try
            {
                using (dbcon = new OleDbConnection())
                {
                    dbcon.ConnectionString = clsDBConnection.strConstr;
                    using (dbcmd = new OleDbCommand())
                    {
                        dbcon.Open();
                        dbcmd.Connection = dbcon;
                        dbcmd.CommandType = System.Data.CommandType.Text;
                        dbcmd.CommandText = "SELECT * FROM tblAuxDetails WHERE UserID = " + UserId;
                        dbcmd.CommandTimeout = 0;
                        dbdr = dbcmd.ExecuteReader();

                        lstAux = new List<AuxModel>();
                        while (dbdr.Read())
                        {
                            objAux = new AuxModel();
                            objAux.AuxDetailsID = Convert.ToInt32(dbdr["AuxDetailsID"]);
                            objAux.UserID = Convert.ToInt32(dbdr["UserID"]);
                            objAux.AuxName = Convert.ToString(dbdr["AuxName"]);
                            objAux.StartTime = Convert.ToDateTime(dbdr["StartTime"]);
                            objAux.EndTime = Convert.ToDateTime(dbdr["EndTime"]);
                            objAux.ParentAuxDetailsID = Convert.ToInt32(dbdr["ParentAuxDetailsID"]);
                            lstAux.Add(objAux);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                objAux = null;
                MessageBox.Show(ex.ToString(), "GetAuxDetailsByUserID", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

            return objAux;
        }

        public int GetLastAuxDetailID(int UserId)
        {
            int iLastAuxDetailsID;
            
            try
            {
                using (dbcon = new OleDbConnection())
                {
                    dbcon.ConnectionString = clsDBConnection.strConstr;
                    using (dbcmd = new OleDbCommand())
                    {
                        dbcon.Open();
                        dbcmd.Connection = dbcon;
                        dbcmd.CommandType = System.Data.CommandType.Text;
                        dbcmd.CommandText = "SELECT MAX(AuxDetailsID) AS MaxAuxDetailsID tblAuxDetails WHERE UserID = " + UserId;
                        dbcmd.CommandTimeout = 0;

                        iLastAuxDetailsID = Convert.ToInt32(dbcmd.ExecuteScalar());
                    }
                }
            }
            catch (Exception ex)
            {
                iLastAuxDetailsID = 0;
                MessageBox.Show(ex.ToString(), "GetLastAuxDetailID", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

            return iLastAuxDetailsID;
        }

        public int AddAux(AuxModel Ax)
        {
            int NoOfRowsAffected = 0;
            try
            {
                using (dbcon = new OleDbConnection())
                {
                    dbcon.ConnectionString = clsDBConnection.strConstr;
                    using (dbcmd = new OleDbCommand())
                    {
                        dbcon.Open();
                        dbcmd.Connection = dbcon;
                        dbcmd.CommandType = System.Data.CommandType.Text;
                        dbcmd.CommandText = "INSERT INTO tblAuxDetails (UserID,AuxName,StartTime,ParentAuxDetailsID) VALUES(@UserID,@AuxName,#" + Ax.StartTime + "#,@ParentAuxDetailsID)";
                        dbcmd.CommandTimeout = 0;

                        dbcmd.Parameters.AddWithValue("UserID", Ax.UserID);
                        dbcmd.Parameters.AddWithValue("AuxName", Ax.AuxName);
                        //dbcmd.Parameters.AddWithValue("StartTime", Ax.StartTime);
                        dbcmd.Parameters.AddWithValue("ParentAuxDetailsID", Ax.ParentAuxDetailsID);

                        NoOfRowsAffected = dbcmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                NoOfRowsAffected = 0;
                MessageBox.Show(ex.ToString(), "AddAux", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

            return NoOfRowsAffected;
        }

        public int UpdateAux(AuxModel Ax)
        {
            int NoOfRowsAffected = 0;

            try
            {
                using (dbcon = new OleDbConnection())
                {
                    dbcon.ConnectionString = clsDBConnection.strConstr;
                    using (dbcmd = new OleDbCommand())
                    {
                        dbcon.Open();
                        dbcmd.Connection = dbcon;
                        dbcmd.CommandType = System.Data.CommandType.Text;
                        dbcmd.CommandText = "UPDATE tblAuxDetails SET AuxName = @AuxName, UserID = @UserID  WHERE AuxDetailsID = '" + Ax.AuxDetailsID + "'";
                        dbcmd.CommandTimeout = 0;

                        dbcmd.Parameters.AddWithValue("AuxName", Ax.AuxName);
                        dbcmd.Parameters.AddWithValue("UserID", Ax.UserID);
                        
                        NoOfRowsAffected = dbcmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                NoOfRowsAffected = 0;
                MessageBox.Show(ex.ToString(), "UpdateUser", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

            return NoOfRowsAffected;
        }

        public int DeleteAux(int AuxId)
        {
            int NoOfRowsAffected = 0;
            try
            {
                using (dbcon = new OleDbConnection())
                {
                    dbcon.ConnectionString = clsDBConnection.strConstr;
                    using (dbcmd = new OleDbCommand())
                    {
                        dbcon.Open();
                        dbcmd.Connection = dbcon;
                        dbcmd.CommandType = System.Data.CommandType.Text;
                        dbcmd.CommandText = "DELETE FROM tblAuxDetails WHERE AuxDetailsID = " + AuxId;
                        dbcmd.CommandTimeout = 0;

                        NoOfRowsAffected = dbcmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                NoOfRowsAffected = 0;
                MessageBox.Show(ex.ToString(), "DeleteAux", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

            return NoOfRowsAffected;
        }
    }
}
