﻿using System.Text.Json;
using ChatApp;

namespace IpMesseger
{
    internal class HostService
    {
        private readonly string? _jsonFilePath;

        public HostService(string? jsonFilePath)
        {
            _jsonFilePath = jsonFilePath;
        }

        public async Task<List<HostDetails>> GetHostAsync()
        {
            try
            {
                if (File.Exists(_jsonFilePath))
                {
                    var json = await File.ReadAllTextAsync(_jsonFilePath);
                    var hosts = JsonSerializer.Deserialize<List<HostDetails>>(json);
                    
                    return hosts;
                }
                else
                {
                    return new List<HostDetails>();
                }
            }
            catch (Exception Err)
            {
                MessageBox.Show("Error:- " + Err.Message, "IP Messeger", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return new List<HostDetails>();
            }
        }

        public async Task<bool> AddHostAsync(HostDetails host)
        {
            try
            {
                var hosts = await GetHostAsync();
                hosts.Add(host);
                var json = JsonSerializer.Serialize(hosts, new JsonSerializerOptions { WriteIndented=true});
                await File.WriteAllTextAsync(_jsonFilePath, json);
                return true;
            }
            catch (Exception Err)
            {
                MessageBox.Show("Error:- " + Err.Message, "IP Messeger", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
        }

        public async Task<bool> WriteLog(string LogText)
        {
            try
            {
                await File.AppendAllTextAsync("Log.txt", LogText);

                return true;
            }
            catch (Exception Err)
            {
                MessageBox.Show("Error:- " + Err.Message, "IP Messeger", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
        }
    }
}
