﻿
namespace InventoryManagement.BusinessLogic
{
    public class LeaveRequestModel
    {
        public string LeaveRequestID { get; set; }
        public string EmployeeID { get; set; }
        public string LeaveType { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string Reason { get; set; }
        public string Status { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDateTime { get; set; }
    }
}
