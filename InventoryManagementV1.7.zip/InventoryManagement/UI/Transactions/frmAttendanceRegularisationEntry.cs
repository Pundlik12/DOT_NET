﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;
using InventoryManagement.DataAccessLogic;

namespace InventoryManagement
{
    public partial class frmAttendanceRegularisationEntry : Form
    {
        AttendanceModel objAttendance = null;
        IGenericRepository<AttendanceModel> objAttendanceDal = null;
        IGenericRepository<EmployeeModel> objEmployeeDal = null;

        public frmAttendanceRegularisationEntry()
        {
            InitializeComponent();       
        }

        private void frmCustomer_Load(object sender, EventArgs e)
        {
            objAttendanceDal = new AttendanceDAL();
            objEmployeeDal = new EmployeeDAL();

            List<EmployeeModel> empList = objEmployeeDal.GetAll();
            cboEmployee.DataSource = empList;
            cboEmployee.DisplayMember = "EmployeeName";
            cboEmployee.ValueMember = "EmployeeID";

            ClearFields();
            dtpAttendanceDate.MinDate = Convert.ToDateTime("01-" + Convert.ToString(DateTime.Now.ToString("MMM-yyyy")));
            dtpAttendanceDate.MaxDate = DateTime.Now;
            txtInTime.Text = DateTime.Now.ToString("hh:mm:ss");
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (cboEmployee.Text == "")
            {
                cboEmployee.Focus();
                MessageBox.Show("Please select employee.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtInTime.Text.Trim() == "")
            {
                txtInTime.Focus();
                MessageBox.Show("Please enter in time.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtOutTime.Text.Trim() == "")
            {
                txtOutTime.Focus();
                MessageBox.Show("Please enter out time.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                Cursor = Cursors.WaitCursor;

                objAttendance = new AttendanceModel();
                objAttendance.AttendanceDate = dtpAttendanceDate.Text;
                objAttendance.EmployeeID = cboEmployee.Text;
                objAttendance.CheckIn = txtInTime.Text.Trim();
                objAttendance.CheckOut = txtOutTime.Text.Trim();                    
                objAttendance.CreatedBy = common.strUserEmail;

                if (btnSave.Text == "Save")
                {
                    objAttendanceDal.Add(objAttendance);
                    ClearFields();
                    //MessageBox.Show("Attendance entry saved successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    //objAttendance.Code = Convert.ToInt32(txtCode.Text);
                    objAttendanceDal.Update(objAttendance);
                    ClearFields();
                    //MessageBox.Show("Attendance entry updated successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                
                Cursor = Cursors.Default;
            }
        }

        private void ClearFields()
        {
            cboEmployee.SelectedIndex = -1;
            txtInTime.Text = "";
            txtOutTime.Text = "";
            dtpAttendanceDate.Value = Convert.ToDateTime(DateTime.Now.ToString("dd-MMM-yyyy"));
            btnSave.Text = "Save";
            dgvData.Enabled = true;
            cboEmployee.Select();
            DisplayData();            
        }

        private void DisplayData()
        {
            List<AttendanceModel> lstData = objAttendanceDal.GetAll();
            dgvData.DataSource = lstData;
        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
