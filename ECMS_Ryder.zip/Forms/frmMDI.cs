﻿using System;
using System.Windows.Forms;
using ECMS_Ryder.Repositories;
using ECMS_Ryder.HelperClasses;
using System.Collections.Generic;
using ECMS_Ryder.Models;
using System.Linq;

namespace ECMS_Ryder.Forms
{
    public partial class frmMDI : Form
    {
        private readonly EmailBoxRepository EmailBoxRepository;
        private readonly clsOutlookLayer OutlookLayer;
                
        public frmMDI()
        {
            InitializeComponent();
            
            OutlookLayer = new clsOutlookLayer();
            EmailBoxRepository = new EmailBoxRepository(clsDBConnection.strConnectionString);
        }

        private void frmMDI_Load(object sender, EventArgs e)
        {
            lblUserName.Text = clsDBConnection.strLoggedInUserName + " [" + clsDBConnection.strLoggedInUID + "]";
            lblUserRole.Text = clsDBConnection.strLoggedInUserRole;

            btnSwitchAccount.Enabled = false;
            btnSyncOutlookEmails.Enabled = false;
            btnAssignEmails.Enabled = false;
            btnDeAllocateEmails.Enabled = false;
            btnDisposeEmails.Enabled = false;
            btnDashboard.Enabled = false;
            btnDownloads.Enabled = false;
            btnUserForm.Enabled = false;

            List<EmailBox> EmailBoxList = EmailBoxRepository.GetAllEmailBoxes();
            var ActiveEmailBoxList = (from mailboxes in EmailBoxList where mailboxes.Status.ToString() == "Active" select mailboxes).ToList();

            cmbMailBoxes.Items.Clear();
            cmbMailBoxes.Items.Add("Select");

            foreach (var item in ActiveEmailBoxList)
            {
                cmbMailBoxes.Items.Add(item.EmailAddress);
            }

            if (lblUserRole.Text == "Admin")
            {
                btnDashboard.Enabled = true;
                btnUserForm.Enabled = true;
            }
            else
            {
                btnDashboard.Enabled = false;
                btnUserForm.Enabled = false;
            }

            cmbMailBoxes.SelectedIndex = 0;
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            if (cmbMailBoxes.Text == "Select")
            {
                MessageBox.Show("Please select the mailbox first.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                cmbMailBoxes.Select();
                return;
            }
            else
            {
               Cursor.Current = Cursors.WaitCursor;
               
               clsDBConnection.strEmailAddress = cmbMailBoxes.Text;
               OutlookLayer.strEmailAddress = cmbMailBoxes.Text;
               Boolean isAvailable = OutlookLayer.CheckEmailBoxAvailable();

                if (isAvailable == false && clsDBConnection.strLoggedInUserRole == "Admin")
                {
                    MessageBox.Show("Mailbox is not configured in the outlook or it may incorrectly configured in the Tool.Please contact to WFM team.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    cmbMailBoxes.Select();
                    Cursor.Current = Cursors.Default;
                    return;
                }
            }

            if (lblUserRole.Text == "Admin")
            {
                btnSyncOutlookEmails.Enabled = true;
                btnAssignEmails.Enabled = true;
                btnDeAllocateEmails.Enabled = true;
                btnDisposeEmails.Enabled = true;
                btnDashboard.Enabled = true;
                btnDownloads.Enabled = true;
                btnUserForm.Enabled = true;
            }
            else
            {
                btnSyncOutlookEmails.Enabled = false;
                btnAssignEmails.Enabled = false;
                btnDeAllocateEmails.Enabled = false;
                btnDisposeEmails.Enabled = true;
                btnDashboard.Enabled = true;
                btnDownloads.Enabled = true;
                btnUserForm.Enabled = false;
            }

            btnGo.Enabled = false;
            cmbMailBoxes.Enabled = false;
            btnSwitchAccount.Enabled = true;

            Cursor.Current = Cursors.Default;
        }

        private void btnSwitchAccount_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            RemoveForms();
            
            btnSyncOutlookEmails.Enabled = false;
            btnAssignEmails.Enabled = false;
            btnDeAllocateEmails.Enabled = false;
            btnDisposeEmails.Enabled = false;
            btnDashboard.Enabled = false;
            btnDownloads.Enabled = false;
            btnUserForm.Enabled = false;

            cmbMailBoxes.SelectedIndex = 0;
            btnGo.Enabled = true;
            cmbMailBoxes.Enabled = true;
            btnSwitchAccount.Enabled = false;

            if (lblUserRole.Text == "Admin")
            {
                btnDashboard.Enabled = true;
                btnUserForm.Enabled = true;
            }

            cmbMailBoxes.Select();

            Cursor.Current = Cursors.Default;
        }

        private void btnSyncOutlookEmails_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            RemoveForms();
            frmSyncEmails FrmSyncEmails = new frmSyncEmails();
            FrmSyncEmails.TopLevel = false;
            FrmSyncEmails.AutoScroll = true;
            panel1.Controls.Add(FrmSyncEmails);
            FrmSyncEmails.Show();

            Cursor.Current = Cursors.Default;
        }

        private void btnAssignEmails_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            RemoveForms();
            frmAssignEmails FrmAssignEmails = new frmAssignEmails();
            FrmAssignEmails.TopLevel = false;
            FrmAssignEmails.AutoScroll = true;
            panel1.Controls.Add(FrmAssignEmails);
            FrmAssignEmails.Show();

            Cursor.Current = Cursors.Default;
        }

        private void btnDeAllocateEmails_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            RemoveForms();
            frmDeAllocateEmails FrmDeAllocateEmails = new frmDeAllocateEmails();
            FrmDeAllocateEmails.TopLevel = false;
            FrmDeAllocateEmails.AutoScroll = true;
            panel1.Controls.Add(FrmDeAllocateEmails);
            FrmDeAllocateEmails.Show();

            Cursor.Current = Cursors.Default;
        }

        private void btnDisposeEmails_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            RemoveForms();
            frmDispositionForm FrmDispositionForm = new frmDispositionForm();
            FrmDispositionForm.TopLevel = false;
            FrmDispositionForm.AutoScroll = true;
            panel1.Controls.Add(FrmDispositionForm);
            FrmDispositionForm.Show();

            Cursor.Current = Cursors.Default;
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            RemoveForms();
            frmSummaryReport FrmSummaryReport = new frmSummaryReport();
            FrmSummaryReport.TopLevel = false;
            FrmSummaryReport.AutoScroll = true;
            panel1.Controls.Add(FrmSummaryReport);
            FrmSummaryReport.Show();

            Cursor.Current = Cursors.Default;
        }

        private void btnDownloads_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            RemoveForms();
            frmDownloadReport FrmDownloadReport = new frmDownloadReport();
            FrmDownloadReport.TopLevel = false;
            FrmDownloadReport.AutoScroll = true;
            panel1.Controls.Add(FrmDownloadReport);
            FrmDownloadReport.Show();

            Cursor.Current = Cursors.Default;
        }

        private void btnUserForm_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            RemoveForms();
            frmUserForm FrmUser = new frmUserForm();
            FrmUser.TopLevel = false;
            FrmUser.AutoScroll = true;
            panel1.Controls.Add(FrmUser);
            FrmUser.Show();

            Cursor.Current = Cursors.Default;
        }

        private void RemoveForms()
        {
            foreach (Control ctrl in panel1.Controls)
            {
                panel1.Controls.Remove(ctrl);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void frmMDI_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Do you want to close the Tool?.", "ECMS Tool - Ryder", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
    }
}
