﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;
using InventoryManagement.DataAccessLogic;

namespace InventoryManagement
{
    public partial class frmExpenseReport : Form
    {
        IGenericRepository<ExpenseModel> objExpenseDal = null;

        public frmExpenseReport()
        {
            InitializeComponent();       
        }

        private void frmExpenseReport_Load(object sender, EventArgs e)
        {
            objExpenseDal = new ExpenseDAL();
            dtpFromDate.MaxDate = DateTime.Now;
            dtpFromDate.Value = Convert.ToDateTime("01-" + DateTime.Now.ToString("MMM") + "-" + DateTime.Now.ToString("yyyy"));
            dtpToDate.MaxDate = DateTime.Now;
        }

        private void DisplayData()
        {
            List<ExpenseModel> lstData = objExpenseDal.GetByDates(dtpFromDate.Text, dtpToDate.Text);
            dgvData.DataSource = lstData;
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            DisplayData();
            Cursor = Cursors.Default;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            if (System.IO.Directory.Exists(System.AppDomain.CurrentDomain.BaseDirectory + "output") == false)
            {
                System.IO.Directory.CreateDirectory(System.AppDomain.CurrentDomain.BaseDirectory + "output");
            }

            string strFilePath = System.AppDomain.CurrentDomain.BaseDirectory + $"Output//ExpenseReport_{DateTime.Now.ToString("ddMMMyyyy hhmm")}.xltx";
            DataTable dt = new DataTable();
            dt = common.DataGridView_To_Datatable(dgvData);

            if (dt.Rows.Count > 0)
            {
                common.ExportToExcel(dt, strFilePath, "ExpenseReport");
            }
            else
            {
                MessageBox.Show("Data not found to export.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            Cursor = Cursors.Default;
        }
    }
}
