﻿
namespace ECMS_Ryder.Models
{
    internal class InclusionDetails
    {
        public int InclusionId { get; set; }
        public int SubCategoryId { get; set; }
        public string SubCategory { get; set; }
        public string Inclusion { get; set; }
    }
}
