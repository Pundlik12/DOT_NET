﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;

namespace InventoryManagement.DataAccessLogic
{
    public class SupplierItemDAL : IGenericRepository<SupplierItemModel>
    {
        public SupplierItemDAL()
        {
            DatabaseContext.CreateConnection();
        }

        public List<SupplierItemModel> GetAll()
        {
            List<SupplierItemModel> lstData = new List<SupplierItemModel>();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT Code,SupplierCode,ItemName,HSNNumber,Rate,CreatedBy,CreatedDateTime FROM tblSupplierItem";
                
                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    SupplierItemModel objItem = new SupplierItemModel();
                    objItem.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objItem.SupplierCode = Convert.ToInt32(DatabaseContext.dbdr["SupplierCode"]);
                    objItem.Name = Convert.ToString(DatabaseContext.dbdr["ItemName"]);
                    objItem.Rate = Convert.ToString(DatabaseContext.dbdr["Rate"]);
                    objItem.HSNNumber = Convert.ToString(DatabaseContext.dbdr["HSNNumber"]);
                    objItem.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objItem.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objItem);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }
        
        public List<SupplierItemModel> GetByDates(string strFromDate, string strToDate)
        {
            throw new NotImplementedException();
        }

        public SupplierItemModel GetByID(Int32 ItemCode)
        {
            SupplierItemModel objItem = new SupplierItemModel();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT Code,SupplierCode,ItemName,HSNNumber,Rate,CreatedBy,CreatedDateTime FROM tblSupplierItem WHERE Code = " + ItemCode;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    objItem.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objItem.SupplierCode = Convert.ToInt32(DatabaseContext.dbdr["SupplierCode"]);
                    objItem.Name = Convert.ToString(DatabaseContext.dbdr["ItemName"]);
                    objItem.Rate = Convert.ToString(DatabaseContext.dbdr["Rate"]);
                    objItem.HSNNumber = Convert.ToString(DatabaseContext.dbdr["HSNNumber"]);
                    objItem.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objItem.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return objItem;
        }

        public void Add(SupplierItemModel objItem)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "INSERT INTO tblSupplierItem (SupplierCode,ItemName,Rate,HSNNumber,CreatedBy,CreatedDateTime) VALUES(@SupplierCode,@ItemName,@Rate,@HSNNumber,@CreatedBy,@CreatedDateTime)";

                DatabaseContext.dbcmd.Parameters.AddWithValue("SupplierCode", objItem.SupplierCode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("ItemName", objItem.Name);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Rate", objItem.Rate);
                DatabaseContext.dbcmd.Parameters.AddWithValue("HSNNumber", objItem.HSNNumber);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objItem.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Update(SupplierItemModel objItem)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "UPDATE tblSupplierItem SET SupplierCode=@SupplierCode,ItemName = @ItemName,Rate = @Rate,HSNNumber = @HSNNumber,CreatedBy=@CreatedBy,CreatedDateTime=@CreatedDateTime WHERE Code = " + objItem.Code;

                DatabaseContext.dbcmd.Parameters.AddWithValue("SupplierCode", objItem.SupplierCode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("ItemName", objItem.Name);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Rate", objItem.Rate);
                DatabaseContext.dbcmd.Parameters.AddWithValue("HSNNumber", objItem.HSNNumber);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objItem.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Delete(Int32 ItemCode)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "DELETE FROM tblSupplierItem WHERE Code = " + ItemCode;
                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
