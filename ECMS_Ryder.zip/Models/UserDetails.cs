﻿using System;

namespace ECMS_Ryder.Models
{
    internal class UserDetails
    {
        public int UserId { get; set; }
        public string UID { get; set; }
        public string UserName { get; set; }
        public string Role { get; set; }
        public string IsActive { get; set; }
        public string EntryUser { get; set; }
        public string EntryDateTime { get; set; }
    }
}
