﻿using System;
using System.Data;
using System.Data.OleDb;
using ECMS_Ryder.Models;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ECMS_Ryder.Repositories
{
    interface iInclusionRepository
    {
        List<InclusionDetails> GetAllInclusions();
        InclusionDetails GetInclusionByID(string subCategoryDetailsID);
        void CreateInclusion(InclusionDetails subCategoryDetails);
        void UpdateInclusion(InclusionDetails subCategoryDetails);
        void DeleteInclusion(Int32 InclusionDetailsId);
    }

    internal class InclusionRepository : iInclusionRepository
    {
        private readonly string strConnectionString = "";

        public InclusionRepository(string _strConnectionString)
        {
            strConnectionString = _strConnectionString;
        }

        public List<InclusionDetails> GetAllInclusions()
        {
            List<InclusionDetails> inclusionDetailsList = new List<InclusionDetails>();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "SELECT InclusionDetails.InclusionId,InclusionDetails.SubCategoryId,SubCategoryDetails.SubCategory,InclusionDetails.Inclusion FROM InclusionDetails INNER JOIN SubCategoryDetails ON InclusionDetails.SubCategoryId = SubCategoryDetails.SubCategoryId";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    OleDbDataReader OleDbDataReader = cmd.ExecuteReader();

                    while (OleDbDataReader.Read())
                    {
                        InclusionDetails inclusionDetails = new InclusionDetails();

                        inclusionDetails.InclusionId = Convert.ToInt32(OleDbDataReader["InclusionId"]);
                        inclusionDetails.SubCategoryId = Convert.ToInt32(OleDbDataReader["SubCategoryId"]);
                        inclusionDetails.SubCategory = Convert.ToString(OleDbDataReader["SubCategory"]);
                        inclusionDetails.Inclusion = Convert.ToString(OleDbDataReader["Inclusion"]);

                        //inclusionDetails.EntryUser = Convert.ToString(OleDbDataReader["EntryUser"]);
                        //inclusionDetails.EntryDateTime = Convert.ToString(OleDbDataReader["EntryDateTime"]);

                        inclusionDetailsList.Add(inclusionDetails);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetAllSubCategories:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                inclusionDetailsList = null;
            }

            return inclusionDetailsList;
        }

        public InclusionDetails GetInclusionByID(string InclusionID)
        {
            InclusionDetails inclusionDetails = new InclusionDetails();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "SELECT InclusionDetails.InclusionId,InclusionDetails.SubCategoryId,SubCategoryDetails.SubCategory,InclusionDetails.Inclusion FROM InclusionDetails INNER JOIN SubCategoryDetails ON InclusionDetails.SubCategoryId = SubCategoryDetails.SubCategoryId WHERE InclusionDetails.InclusionID = @InclusionID";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.AddWithValue("@InclusionID", InclusionID);

                    OleDbDataReader OleDbDataReader = cmd.ExecuteReader();

                    while (OleDbDataReader.Read())
                    {
                        inclusionDetails.InclusionId = Convert.ToInt32(OleDbDataReader["InclusionId"]);
                        inclusionDetails.SubCategoryId = Convert.ToInt32(OleDbDataReader["SubCategoryId"]);
                        inclusionDetails.SubCategory = Convert.ToString(OleDbDataReader["SubCategory"]);
                        inclusionDetails.Inclusion = Convert.ToString(OleDbDataReader["Inclusion"]);

                        //inclusionDetails.EntryUser = Convert.ToString(OleDbDataReader["EntryUser"]);
                        //inclusionDetails.EntryDateTime = Convert.ToString(OleDbDataReader["EntryDateTime"]);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetInclusionByID:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                inclusionDetails = null;
            }

            return inclusionDetails;
        }

        public void CreateInclusion(InclusionDetails inclusionDetails)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "INSERT INTO InclusionDetails (SubCategoryId, Inclusion) VALUES(@SubCategoryId, @Inclusion)";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.AddWithValue("@SubCategoryId", inclusionDetails.SubCategoryId);
                    cmd.Parameters.AddWithValue("@Inclusion", inclusionDetails.Inclusion);

                    //cmd.Parameters.AddWithValue("@EntryUser", inclusionDetails.EntryUser);
                    //cmd.Parameters.AddWithValue("@EntryDateTime", inclusionDetails.EntryDateTime);

                    cmd.ExecuteNonQuery();

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in CreateInclusion:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void UpdateInclusion(InclusionDetails inclusionDetails)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "UPDATE InclusionDetails SET SubCategoryId = @SubCategoryId, Inclusion = @Inclusion WHERE InclusionId = @InclusionId";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.AddWithValue("@SubCategoryId", inclusionDetails.SubCategoryId);
                    cmd.Parameters.AddWithValue("@Inclusion", inclusionDetails.Inclusion);

                    //cmd.Parameters.AddWithValue("@EntryUser", inclusionDetails.EntryUser);
                    //cmd.Parameters.AddWithValue("@EntryDateTime", inclusionDetails.EntryDateTime);

                    cmd.Parameters.AddWithValue("@InclusionId", inclusionDetails.InclusionId);

                    cmd.ExecuteNonQuery();

                    connection.Close();
                }                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in UpdateInclusion:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void DeleteInclusion(int InclusionId)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "DELETE FROM InclusionDetails WHERE InclusionId = @InclusionId";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.AddWithValue("@InclusionId", InclusionId);

                    cmd.ExecuteNonQuery();

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in DeleteInclusion:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
