﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;

namespace InventoryManagement.DataAccessLogic
{
    public class ItemDAL : IGenericRepository<ItemModel>
    {
        public ItemDAL()
        {
            DatabaseContext.CreateConnection();
        }

        public List<ItemModel> GetAll()
        {
            List<ItemModel> lstData = new List<ItemModel>();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT Code,Name,GSTPercent,HSNNumber,CompanyCode,CreatedBy,CreatedDateTime FROM tblItem WHERE CompanyCode = " + common.strCompanyCode;
                
                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    ItemModel objItem = new ItemModel();
                    objItem.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objItem.Name = Convert.ToString(DatabaseContext.dbdr["Name"]);
                    objItem.GSTPercent = Convert.ToString(DatabaseContext.dbdr["GSTPercent"]);
                    objItem.HSNNumber = Convert.ToString(DatabaseContext.dbdr["HSNNumber"]);
                    objItem.CompanyCode = Convert.ToString(DatabaseContext.dbdr["CompanyCode"]);
                    objItem.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objItem.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objItem);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }
        
        public List<ItemModel> GetByDates(string strFromDate, string strToDate)
        {
            throw new NotImplementedException();
        }

        public ItemModel GetByID(Int32 ItemCode)
        {
            ItemModel objItem = new ItemModel();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT Code,Name,GSTPercent,HSNNumber,CompanyCode,CreatedBy,CreatedDateTime FROM tblItem WHERE Code = " + ItemCode;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    objItem.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objItem.Name = Convert.ToString(DatabaseContext.dbdr["Name"]);
                    objItem.GSTPercent = Convert.ToString(DatabaseContext.dbdr["GSTPercent"]);
                    objItem.HSNNumber = Convert.ToString(DatabaseContext.dbdr["HSNNumber"]);
                    objItem.CompanyCode = Convert.ToString(DatabaseContext.dbdr["CompanyCode"]);
                    objItem.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objItem.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return objItem;
        }

        public void Add(ItemModel objItem)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "INSERT INTO tblItem (Name,GSTPercent,HSNNumber,CompanyCode,CreatedBy,CreatedDateTime) VALUES(@Name,@GSTPercent,@HSNNumber,@CompanyCode,@CreatedBy,@CreatedDateTime)";
                
                DatabaseContext.dbcmd.Parameters.AddWithValue("Name", objItem.Name);
                DatabaseContext.dbcmd.Parameters.AddWithValue("GSTPercent", objItem.GSTPercent);
                DatabaseContext.dbcmd.Parameters.AddWithValue("HSNNumber", objItem.HSNNumber);
                DatabaseContext.dbcmd.Parameters.AddWithValue("HSNNumber", common.strCompanyCode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objItem.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Update(ItemModel objItem)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "UPDATE tblItem SET Name = @Name,GSTPercent = @GSTPercent,HSNNumber = @HSNNumber,CreatedBy=@CreatedBy,CreatedDateTime=@CreatedDateTime WHERE Code = " + objItem.Code;

                DatabaseContext.dbcmd.Parameters.AddWithValue("Name", objItem.Name);
                DatabaseContext.dbcmd.Parameters.AddWithValue("GSTPercent", objItem.GSTPercent);
                DatabaseContext.dbcmd.Parameters.AddWithValue("HSNNumber", objItem.HSNNumber);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objItem.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Delete(Int32 ItemCode)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "DELETE FROM tblItem WHERE Code = " + ItemCode;
                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
