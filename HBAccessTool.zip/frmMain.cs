﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace HBAccessTool
{
    public partial class frmMain : Form
    {
        TransactionRepository tr = null;
        TransactionModel tm = null;
        UserRepository ur = null;
        UserModel um = null;

        public frmMain()
        {
            InitializeComponent();

            lblLastStatus.Text = "Current AUX : {0}";
            lblLastStatus.Text = string.Format(lblLastStatus.Text, "Login");
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            //Screen scr = Screen.FromPoint(this.Location);
            //this.Location = new Point(scr.WorkingArea.Right - this.Width, scr.WorkingArea.Top);

            lblHeading.Text = clsCommon.strProjectTitle;
            this.Text = clsCommon.strProjectTitle;

            lblUserName.Text = string.Format(lblUserName.Text, clsDBConnection.strLoginUserName);
            lblUserRole.Text = string.Format(lblUserRole.Text, clsDBConnection.strLoginUserRole);

            tr = new TransactionRepository();
            dgvData.DataSource = null;
            dgvData.DataSource = tr.GetAllTransactions();

            ur = new UserRepository();
            dgvUserDetails.DataSource = null;
            dgvUserDetails.DataSource = ur.GetAllUsers();
        }

        /// <summary>
        /// User Management
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearchUser_Click(object sender, EventArgs e)
        {
            if (txtUID.Text.Trim() == "")
            {
                txtUID.Focus();
                MessageBox.Show("Enter UID.", "Data Entry", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                Cursor.Current = Cursors.WaitCursor;

                ur = new UserRepository();
                var users = (from table in ur.GetAllUsers() where table.Uid == txtUID.Text.Trim() select table).ToList();

                if (users.Count > 0)
                {
                    txtUID.Tag = users[0].UserID;
                    txtFirstName.Text = users[0].FirstName;
                    txtLastName.Text = users[0].LastName;

                    if (users[0].IsActive == 1)
                    {
                        cboUserStatus.SelectedIndex = 0;
                    }
                    else
                    {
                        cboUserStatus.SelectedIndex = 1;
                    }

                    if (users[0].Role == "Admin")
                    {
                        cboUserRole.SelectedIndex = 0;
                    }
                    else
                    {
                        cboUserRole.SelectedIndex = 1;
                    }

                    txtUID.Enabled = false;
                    txtFirstName.Enabled = true;
                    txtLastName.Enabled = true;
                    cboUserStatus.Enabled = true;
                    cboUserRole.Enabled = true;

                    btnSearchUser.Enabled = false;
                    btnCancel.Enabled = true;
                    btnDeleteUser.Enabled = true;
                    btnAddUpdateUser.Enabled = true;
                    btnAddUpdateUser.Text = "Update User";
                }
                else
                {
                    if (MessageBox.Show("Selected user does not exists." + Environment.NewLine + Environment.NewLine + "Do you want add user?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        txtUID.Enabled = false;
                        txtFirstName.Enabled = true;
                        txtLastName.Enabled = true;
                        cboUserStatus.Enabled = true;
                        cboUserRole.Enabled = true;

                        btnSearchUser.Enabled = false;
                        btnCancel.Enabled = true;
                        btnDeleteUser.Enabled = false;
                        btnAddUpdateUser.Enabled = true;
                        btnAddUpdateUser.Text = "Add User";
                    }
                }

                Cursor.Current = Cursors.Default;
            }
        }

        private void btnAddUpdateUser_Click(object sender, EventArgs e)
        {
            if (txtFirstName.Text.Trim() == "")
            {
                txtFirstName.Focus();
                MessageBox.Show("Enter First Name.", "Data Entry", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtLastName.Text.Trim() == "")
            {
                txtLastName.Focus();
                MessageBox.Show("Enter Last Name.", "Data Entry", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                Cursor.Current = Cursors.WaitCursor;
                bool isUserAdded = false;
                um = new UserModel();
                um.Uid = txtUID.Text.Trim();
                um.FirstName = txtFirstName.Text.Trim();
                um.LastName = txtLastName.Text.Trim();
                um.DisplayName = txtFirstName.Text.Trim() + " " + txtLastName.Text.Trim();
                um.IsActive = cboUserStatus.Text == "Active" ? 1 : 0;
                um.Role = cboUserRole.Text == "Admin" ? "Admin" : "Associate";

                if (btnAddUpdateUser.Text == "Add User")
                {
                    isUserAdded = true;
                    ur.AddUser(um);
                }
                else if (btnAddUpdateUser.Text == "Update User")
                {
                    ur.UpdateUser(um);
                }

                ResetUserDetails();

                dgvUserDetails.DataSource = null;
                dgvUserDetails.DataSource = ur.GetAllUsers();

                if (isUserAdded == true)
                {
                    MessageBox.Show("User Added successfully.", "Data Entry", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("User updated successfully.", "Data Entry", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Cursor.Current = Cursors.Default;
            }
        }

        private void btnDeleteUser_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want Delete user?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Cursor.Current = Cursors.WaitCursor;

                ur.DeleteUser(Convert.ToInt32(txtUID.Tag));
                ResetUserDetails();

                dgvUserDetails.DataSource = null;
                dgvUserDetails.DataSource = ur.GetAllUsers();

                MessageBox.Show("User deleted successfully.", "Data Entry", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Cursor.Current = Cursors.Default;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ResetUserDetails();
        }

        private void ResetUserDetails()
        {
            txtUID.Tag = "";
            txtUID.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";
            cboUserStatus.SelectedIndex = 0;
            cboUserRole.SelectedIndex = 0;

            txtUID.Enabled = true;
            txtFirstName.Enabled = false;
            txtLastName.Enabled = false;
            cboUserStatus.Enabled = false;
            cboUserRole.Enabled = false;
            btnSearchUser.Enabled = true;
            btnCancel.Enabled = false;
            btnAddUpdateUser.Enabled = false;
            btnDeleteUser.Enabled = false;
            btnAddUpdateUser.Text = "Add User";
            txtUID.Focus();
        }

        /// <summary>
        /// Work management
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGetData_Click(object sender, EventArgs e)
        {
            lblLastStatus.Text = "Current AUX : {0}";
            lblLastStatus.Text = string.Format(lblLastStatus.Text, "Production");

            AuxToolStripMenuItem.Enabled = false;

            clsDBConnection.strStartTime = DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss");

            txtFName.Enabled = true;
            txtLName.Enabled = true;
            txtEmailAddress.Enabled = true;
            txtMobileNumber.Enabled = true;
            btnGetData.Enabled = false;
            btnSubmit.Enabled = true;
            txtFName.Focus();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtFName.Text.Trim() == "")
            {
                txtFName.Focus();
                MessageBox.Show("Enter First Name.", "Data Entry", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtLName.Text.Trim() == "")
            {
                txtLName.Focus();
                MessageBox.Show("Enter Last Name.", "Data Entry", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtEmailAddress.Text.Trim() == "")
            {
                txtEmailAddress.Focus();
                MessageBox.Show("Enter Email Address.", "Data Entry", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtMobileNumber.Text.Trim() == "")
            {
                txtMobileNumber.Focus();
                MessageBox.Show("Enter Mobile Number.", "Data Entry", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                tm = new TransactionModel();
                tm.FirstName = txtFName.Text.Trim();
                tm.LastName = txtLName.Text.Trim();
                tm.EmailAddress = txtEmailAddress.Text.Trim();
                tm.MobileNumber = txtMobileNumber.Text.Trim();
                tm.StartDatetime = Convert.ToDateTime(clsDBConnection.strStartTime);

                tr.AddTransaction(tm);
                
                //Insert Production AUX
                AuxModel ax = new AuxModel();
                ax.AuxName = "Production";
                ax.UserID = clsDBConnection.intLoginUserID;
                ax.StartTime = Convert.ToDateTime(clsDBConnection.strStartTime);

                AuxRepository axr = new AuxRepository();
                axr.AddAux(ax);

                //Insert Idle AUX
                ax = new AuxModel();
                ax.AuxName = "Idle";
                ax.UserID = clsDBConnection.intLoginUserID;
                ax.StartTime = DateTime.Now;

                axr.AddAux(ax);

                lblLastStatus.Text = "Current AUX : {0}";
                lblLastStatus.Text = string.Format(lblLastStatus.Text, "Idle");

                AuxToolStripMenuItem.Enabled = true;

                txtFName.Text = "";
                txtFName.Enabled = false;

                txtLName.Text = "";
                txtLName.Enabled = false;

                txtEmailAddress.Text = "";
                txtEmailAddress.Enabled = false;

                txtMobileNumber.Text = "";
                txtMobileNumber.Enabled = false;

                btnGetData.Enabled = true;
                btnSubmit.Enabled = false;
                btnGetData.Focus();

                MessageBox.Show("Data submited successfully.", "Data Entry", MessageBoxButtons.OK, MessageBoxIcon.Information);

                dgvData.DataSource = null;
                dgvData.DataSource = tr.GetAllTransactions();
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog opd = new OpenFileDialog();
            opd.FileName = "Select";
            opd.Filter = "Excel Files(.xls) | *.xls*";

            if (opd.ShowDialog() == DialogResult.OK)
            {
                txtUploadFile.Text = opd.FileName;
            }
            else
            {
                txtUploadFile.Text = "";
            }
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                if (txtUploadFile.Text.Trim() == "")
                {
                    txtUploadFile.Focus();
                    MessageBox.Show("Select file.", "UploadFile", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    ExcelOps.ImportExcel(txtUploadFile.Text);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "UploadFile", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            Cursor.Current = Cursors.Default;
        }

        /// <summary>
        /// AUX Logic
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MeetingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InsertAuxData("Meeting");
        }

        private void DowntimeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InsertAuxData("Downtime");
        }

        private void breakToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InsertAuxData("Break");
        }

        private void NoWorkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InsertAuxData("No Work");
        }

        private void LogOffToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InsertAuxData("Logoff");

            Environment.Exit(Environment.ExitCode);
        }

        private void InsertAuxData(string strAUX)
        {
            string[] strLastStatus = lblLastStatus.Text.Split(':');
            
            if (strLastStatus[1].Trim() != strAUX)
            {
                lblLastStatus.Text = "Current AUX : {0}";
                lblLastStatus.Text = string.Format(lblLastStatus.Text, strAUX);

                AuxModel ax = new AuxModel();
                ax.AuxName = strAUX;
                ax.UserID = clsDBConnection.intLoginUserID;
                ax.StartTime = DateTime.Now;

                AuxRepository axr = new AuxRepository();
                axr.AddAux(ax);
            }
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Do you want to log off now?", "Log Off", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                //Insert LogOff AUX
                AuxModel ax = new AuxModel();
                ax.AuxName = "LogOff";
                ax.UserID = clsDBConnection.intLoginUserID;
                ax.StartTime = DateTime.Now;

                AuxRepository axr = new AuxRepository();
                axr.AddAux(ax);

                //e.Cancel = false;
            }
            //else
            //{
            //    e.Cancel = true;
            //}
        }
    }
}
