﻿
using System;

namespace InventoryManagement.BusinessLogic
{
    public class EmployeeModel
    {
        public string EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Department { get; set; }
        public string Designation { get; set; }
        public string JoinDate { get; set; }
        public string Salary { get; set; }
        public string Status { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDateTime { get; set; }
    }
}
