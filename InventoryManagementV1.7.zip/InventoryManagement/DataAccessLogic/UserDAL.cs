﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;

namespace InventoryManagement.DataAccessLogic
{
    public class UserDAL : IGenericRepository<UserModel>
    {
        public UserDAL()
        {
            DatabaseContext.CreateConnection();
        }

        public List<UserModel> GetAll()
        {
            List<UserModel> lstData = new List<UserModel>();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT Code,FirstName,LastName,UserID,UserPassword,Mobile,Email,Role,CompanyCode,IsActive,CreatedBy,CreatedDateTime FROM tblUser";
                
                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    UserModel objUser = new UserModel();
                    objUser.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objUser.FirstName = Convert.ToString(DatabaseContext.dbdr["FirstName"]);
                    objUser.LastName = Convert.ToString(DatabaseContext.dbdr["LastName"]);
                    objUser.UserID = Convert.ToString(DatabaseContext.dbdr["UserID"]);
                    objUser.Password = Convert.ToString(DatabaseContext.dbdr["UserPassword"]);
                    objUser.Mobile = Convert.ToString(DatabaseContext.dbdr["Mobile"]);
                    objUser.Email = Convert.ToString(DatabaseContext.dbdr["Email"]);
                    objUser.Role = Convert.ToString(DatabaseContext.dbdr["Role"]);
                    objUser.CompanyCode = Convert.ToString(DatabaseContext.dbdr["CompanyCode"]);
                    objUser.IsActive = Convert.ToString(DatabaseContext.dbdr["IsActive"]);
                    objUser.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objUser.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objUser);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public List<UserModel> GetByDates(string strFromDate, string strToDate)
        {
            throw new NotImplementedException();
        }

        public UserModel GetByID(Int32 UserCode)
        {
            UserModel objUser = new UserModel();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT Code,FirstName,LastName,UserID,UserPassword,Mobile,Email,Role,CompanyCode,IsActive,CreatedBy,CreatedDateTime FROM tblUser WHERE Code = " + UserCode;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    objUser.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objUser.FirstName = Convert.ToString(DatabaseContext.dbdr["FirstName"]);
                    objUser.LastName = Convert.ToString(DatabaseContext.dbdr["LastName"]);
                    objUser.UserID = Convert.ToString(DatabaseContext.dbdr["UserID"]);
                    objUser.Password = Convert.ToString(DatabaseContext.dbdr["UserPassword"]);
                    objUser.Mobile = Convert.ToString(DatabaseContext.dbdr["Mobile"]);
                    objUser.Email = Convert.ToString(DatabaseContext.dbdr["Email"]);
                    objUser.Role = Convert.ToString(DatabaseContext.dbdr["Role"]);
                    objUser.CompanyCode = Convert.ToString(DatabaseContext.dbdr["CompanyCode"]);
                    objUser.IsActive = Convert.ToString(DatabaseContext.dbdr["IsActive"]);
                    objUser.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objUser.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return objUser;
        }

        public void Add(UserModel objUser)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "INSERT INTO tblUser (FirstName,LastName,UserID,UserPassword,Mobile,Email,Role,CompanyCode,IsActive,CreatedBy,CreatedDateTime) VALUES(@FirstName,@LastName,@UserID,@Password,@Mobile,@Email,@Role,@CompanyCode,@IsActive,@CreatedBy,@CreatedDateTime)";
                
                DatabaseContext.dbcmd.Parameters.AddWithValue("FirstName", objUser.FirstName);
                DatabaseContext.dbcmd.Parameters.AddWithValue("LastName", objUser.LastName);
                DatabaseContext.dbcmd.Parameters.AddWithValue("UserID", objUser.UserID);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Password", objUser.Password);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Mobile", objUser.Mobile);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Email", objUser.Email);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Role", objUser.Role);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CompanyCode", objUser.CompanyCode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("IsActive", objUser.IsActive);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objUser.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Update(UserModel objUser)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "UPDATE tblUser SET FirstName = @FirstName,LastName = @LastName,UserID = @UserID,UserPassword = @Password,Mobile = @Mobile,Email = @Email,Role = @Role,CompanyCode = @CompanyCode,IsActive = @IsActive, CreatedBy = @CreatedBy, CreatedDateTime = @CreatedDateTime WHERE Code = " + objUser.Code;

                DatabaseContext.dbcmd.Parameters.AddWithValue("FirstName", objUser.FirstName);
                DatabaseContext.dbcmd.Parameters.AddWithValue("LastName", objUser.LastName);
                DatabaseContext.dbcmd.Parameters.AddWithValue("UserID", objUser.UserID);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Password", objUser.Password);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Mobile", objUser.Mobile);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Email", objUser.Email);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Role", objUser.Role);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CompanyCode", objUser.CompanyCode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("IsActive", objUser.IsActive);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objUser.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Delete(Int32 UserCode)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "DELETE FROM tblUser WHERE Code = " + UserCode;
                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
