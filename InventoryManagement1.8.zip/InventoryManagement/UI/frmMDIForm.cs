﻿using System;
using System.Windows.Forms;
using InventoryManagement.UI;

namespace InventoryManagement
{
    public partial class frmMDIForm : Form
    {
        frmHome objfrmHome = new frmHome();
        
        public frmMDIForm()
        {
            InitializeComponent();
        }

        private void frmMDIForm_Load(object sender, EventArgs e)
        {
            this.Text = common.strProjectTitle + " : MDI Form";
            ShowHomePage();
        }

        public void ShowHomePage()
        {
            objfrmHome = new frmHome();
            objfrmHome.MdiParent = this;
            objfrmHome.WindowState = FormWindowState.Maximized;
            objfrmHome.StartPosition = FormStartPosition.CenterScreen;
            objfrmHome.Text = ""; //"Home page";
            objfrmHome.Show();
        }

        private void ChangePasswordToolStripMenu_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            frmChangePassword objfrmChangePassword = new frmChangePassword();
            objfrmChangePassword.MdiParent = this;
            objfrmChangePassword.WindowState = FormWindowState.Normal;
            objfrmChangePassword.StartPosition = FormStartPosition.CenterScreen;
            objfrmChangePassword.Text = "Change Password"; 
            objfrmChangePassword.Show();
            Cursor.Current = Cursors.Default;
        }

        private void ExitToolStripMenu_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void CustomerToolStripMenu_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            frmCustomer objfrmCustomer = new frmCustomer();
            objfrmCustomer.MdiParent = this;
            objfrmCustomer.WindowState = FormWindowState.Normal;
            objfrmCustomer.StartPosition = FormStartPosition.CenterScreen;
            objfrmCustomer.Text = "Customer Master"; 
            objfrmCustomer.Show();
            Cursor.Current = Cursors.Default;
        }

        private void ItemsToolStripMenu_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            frmItemMaster objfrmItemMaster = new frmItemMaster();
            objfrmItemMaster.MdiParent = this;
            objfrmItemMaster.WindowState = FormWindowState.Normal;
            objfrmItemMaster.StartPosition = FormStartPosition.CenterScreen;
            objfrmItemMaster.Text = "Item Master";
            objfrmItemMaster.Show();
            Cursor.Current = Cursors.Default;
        }

        private void SupplierToolStripMenu_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            frmSupplier objfrmSupplier = new frmSupplier();
            objfrmSupplier.MdiParent = this;
            objfrmSupplier.WindowState = FormWindowState.Normal;
            objfrmSupplier.StartPosition = FormStartPosition.CenterScreen;
            objfrmSupplier.Text = "Supplier Master";
            objfrmSupplier.Show();
            Cursor.Current = Cursors.Default;
        }

        private void EmployeeToolStripMenu_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            frmEmployee objfrmEmployee = new frmEmployee();
            objfrmEmployee.MdiParent = this;
            objfrmEmployee.WindowState = FormWindowState.Normal;
            objfrmEmployee.StartPosition = FormStartPosition.CenterScreen;
            objfrmEmployee.Text = "Employee Master";
            objfrmEmployee.Show();
            Cursor.Current = Cursors.Default;
        }

        private void ChallanEntryToolStripMenu_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            frmChallanList objfrmChallanList = new frmChallanList();
            objfrmChallanList.MdiParent = this;
            objfrmChallanList.WindowState = FormWindowState.Normal;
            objfrmChallanList.StartPosition = FormStartPosition.CenterScreen;
            objfrmChallanList.Text = "Challan List"; 
            objfrmChallanList.Show();
            Cursor.Current = Cursors.Default;
        }

        private void PaymentEntryToolStripMenu_Click(object sender, EventArgs e)
        {
            if (common.strUserRole == "Admin")
            {
                Cursor.Current = Cursors.WaitCursor;
                frmPaymentList objfrmBillList = new frmPaymentList();
                objfrmBillList.MdiParent = this;
                objfrmBillList.WindowState = FormWindowState.Normal;
                objfrmBillList.StartPosition = FormStartPosition.CenterScreen;
                objfrmBillList.Text = "Payment List"; //common.strProjectTitle +
                objfrmBillList.Show();
                Cursor.Current = Cursors.Default;
            }
            else
            {
                MessageBox.Show("You do not have appropriate permission to open this menu.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        
        private void expensesEntryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (common.strUserRole == "Admin")
            {
                Cursor.Current = Cursors.WaitCursor;
                frmExpenseEntry objfrmExpenseEntry = new frmExpenseEntry();
                objfrmExpenseEntry.MdiParent = this;
                objfrmExpenseEntry.WindowState = FormWindowState.Normal;
                objfrmExpenseEntry.StartPosition = FormStartPosition.CenterScreen;
                objfrmExpenseEntry.Text = "Expense Entry"; 
                objfrmExpenseEntry.Show();
                Cursor.Current = Cursors.Default;
            }
            else
            {
                MessageBox.Show("You do not have appropriate permission to open this menu.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void AttendanceEntryToolStripMenu_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            frmAttendanceEntry objfrmAttendanceEntry = new frmAttendanceEntry();
            objfrmAttendanceEntry.MdiParent = this;
            objfrmAttendanceEntry.WindowState = FormWindowState.Normal;
            objfrmAttendanceEntry.StartPosition = FormStartPosition.CenterScreen;
            objfrmAttendanceEntry.Text = "Attenadnce Entry";
            objfrmAttendanceEntry.Show();
            Cursor.Current = Cursors.Default;
        }

        private void AttendanceRegularisationToolStripMenu_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            frmAttendanceRegularisationEntry objfrmAttendanceRegularisationEntry = new frmAttendanceRegularisationEntry();
            objfrmAttendanceRegularisationEntry.MdiParent = this;
            objfrmAttendanceRegularisationEntry.WindowState = FormWindowState.Normal;
            objfrmAttendanceRegularisationEntry.StartPosition = FormStartPosition.CenterScreen;
            objfrmAttendanceRegularisationEntry.Text = "Attenadnce Regularisation Entry";
            objfrmAttendanceRegularisationEntry.Show();
            Cursor.Current = Cursors.Default;
        }

        private void LeaveRequestToolStripMenu_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            frmLeaveRequest objfrmLeaveRequest = new frmLeaveRequest();
            objfrmLeaveRequest.MdiParent = this;
            objfrmLeaveRequest.WindowState = FormWindowState.Normal;
            objfrmLeaveRequest.StartPosition = FormStartPosition.CenterScreen;
            objfrmLeaveRequest.Text = "Leave Request";
            objfrmLeaveRequest.Show();
            Cursor.Current = Cursors.Default;
        }

        private void UserManagementToolStripMenu_Click(object sender, EventArgs e)
        {
            if (common.strUserRole == "Admin")
            {
                Cursor.Current = Cursors.WaitCursor;
                frmUser objfrmUser = new frmUser();
                objfrmUser.MdiParent = this;
                objfrmUser.WindowState = FormWindowState.Normal;
                objfrmUser.StartPosition = FormStartPosition.CenterScreen;
                objfrmUser.Text = "User Management"; 
                objfrmUser.Show();
                Cursor.Current = Cursors.Default;
            }
            else
            {
                MessageBox.Show("You do not have appropriate permission to open this menu.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void CompanyInfoToolStripMenu_Click(object sender, EventArgs e)
        {
            if (common.strUserRole == "Admin")
            {
                Cursor.Current = Cursors.WaitCursor;
                frmCompany objfrmCompany = new frmCompany();
                objfrmCompany.MdiParent = this;
                objfrmCompany.WindowState = FormWindowState.Normal;
                objfrmCompany.StartPosition = FormStartPosition.CenterScreen;
                objfrmCompany.Text = "Company Info"; 
                objfrmCompany.Show();
                Cursor.Current = Cursors.Default;
            }
            else
            {
                MessageBox.Show("You do not have appropriate permission to open this menu.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void challanReportToolStripMenu_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            frmChallanReport objfrmChallanReport = new frmChallanReport();
            objfrmChallanReport.MdiParent = this;
            objfrmChallanReport.WindowState = FormWindowState.Normal;
            objfrmChallanReport.StartPosition = FormStartPosition.CenterScreen;
            objfrmChallanReport.Text = "Challan Report"; 
            objfrmChallanReport.Show();
            Cursor.Current = Cursors.Default;
        }

        private void paymentReportToolStripMenu_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            frmPaymentReport objfrmPaymentReport = new frmPaymentReport();
            objfrmPaymentReport.MdiParent = this;
            objfrmPaymentReport.WindowState = FormWindowState.Normal;
            objfrmPaymentReport.StartPosition = FormStartPosition.CenterScreen;
            objfrmPaymentReport.Text = "Payment Report"; 
            objfrmPaymentReport.Show();
            Cursor.Current = Cursors.Default;
        }

        private void expenseReportToolStripMenu_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            frmExpenseReport objfrmExpenseReport = new frmExpenseReport();
            objfrmExpenseReport.MdiParent = this;
            objfrmExpenseReport.WindowState = FormWindowState.Normal;
            objfrmExpenseReport.StartPosition = FormStartPosition.CenterScreen;
            objfrmExpenseReport.Text = "Expense Report";
            objfrmExpenseReport.Show();
            Cursor.Current = Cursors.Default;
        }

        private void frmMDIForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
