﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;
using InventoryManagement.DataAccessLogic;

namespace InventoryManagement.UI
{
    public partial class frmChallanList : Form
    {
        iReports objReportDal = null;
        IGenericRepository<ChallanHeaderModel> objChallanDal = null;

        public frmChallanList()
        {
            InitializeComponent();
        }

        private void frmChallanList_Load(object sender, EventArgs e)
        {
            objReportDal = new ChallanDAL();
            objChallanDal = new ChallanDAL();
            DisplayData();
        }

        private void DisplayData()
        {
            List<ChallanHeaderModel> lstFilteredData = null;
            List<ChallanHeaderModel> lstData = null;

            lstData = objChallanDal.GetAll();

            if (txtName.Text != "")
            {
                lstFilteredData = lstData.Where(x => x.CustomerName.Contains(txtName.Text)).ToList();
            }
            else
            {
                lstFilteredData = lstData;
            }

            dgvData.DataSource = lstFilteredData;
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            frmChallanEntryForm ObjfrmChallanEntry = new frmChallanEntryForm();
            ObjfrmChallanEntry.WindowState = FormWindowState.Normal;
            ObjfrmChallanEntry.StartPosition = FormStartPosition.CenterScreen;
            ObjfrmChallanEntry.Text = common.strProjectTitle + " : Challan Entry";
            ObjfrmChallanEntry.ShowDialog(this);
            
            DisplayData();
        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (e.ColumnIndex == 0)
                {
                    if (common.strUserRole == "Admin")
                    {
                        if (MessageBox.Show("Do you want to delete?", common.strProjectTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            Int32 ChallanHeaderCode = Convert.ToInt32(dgvData.Rows[e.RowIndex].Cells["ChallanHeaderCode"].Value);
                            objChallanDal.Delete(ChallanHeaderCode);
                            DisplayData();
                            //MessageBox.Show("Challan deleted successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MessageBox.Show("You do not have appropriate permission for this action.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                if (e.ColumnIndex == 1)
                {
                    Cursor.Current = Cursors.WaitCursor;
                    string strChallanNo = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["ChallanNo"].Value);
                    frmChallanView objfrmChallanView = new frmChallanView(strChallanNo);
                    objfrmChallanView.WindowState = FormWindowState.Normal;
                    objfrmChallanView.StartPosition = FormStartPosition.CenterScreen;
                    objfrmChallanView.Text = common.strProjectTitle + " : View Challan";
                    objfrmChallanView.ShowDialog();
                    Cursor.Current = Cursors.Default;
                }
                if (e.ColumnIndex == 2)
                {
                    if (MessageBox.Show("Do you want to print this challan?", common.strProjectTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        string ChallanNo = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["ChallanNo"].Value);
                        common.ChallanNo = ChallanNo;

                        DataTable dt = objReportDal.PrintChallan();

                        if (dt != null && dt.Rows.Count > 0)
                        {
                            common.PrintInvoice(dt);
                        }
                    }
                }
            }
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            DisplayData();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
