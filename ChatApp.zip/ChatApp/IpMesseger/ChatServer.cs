﻿using System.Net.Sockets;
using System.Net;
using System.Text;

namespace ChatApp
{
    public class ChatServer
    {
        private Thread thread;

        public void Start()
        {
            thread = new Thread(() =>
            {
                TcpListener listener = new TcpListener(IPAddress.Any, 5000);
                listener.Start();

                while (true)
                {
                    var client = listener.AcceptTcpClient();
                    using var stream = client.GetStream();
                    using var ms = new MemoryStream();
                    stream.CopyTo(ms);
                    byte[] data = ms.ToArray();
                    string header = Encoding.UTF8.GetString(data).Split('|')[0];

                    if (header.StartsWith("MSG:"))
                    {
                        string message = header.Substring(4);
                        try
                        {
                            File.AppendAllTextAsync("Log.txt",  message);
                        }
                        catch (Exception Err)
                        {
                            MessageBox.Show("Error:- " + Err.Message, "IP Messeger", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        }
                        MessageBox.Show("Received: " + message);
                    }
                    else if (header.StartsWith("FILE:"))
                    {
                        string fileName = header.Substring(5).Replace("|", "");
                        File.WriteAllBytes(fileName, data[(header.Length + 1)..]);
                        MessageBox.Show("File saved: " + fileName);
                    }
                }
            });

            thread.IsBackground = true;
            thread.Start();

            //new Thread(() =>
            //{
            //    TcpListener listener = new TcpListener(IPAddress.Any, 5000);
            //    listener.Start();

            //    while (true)
            //    {
            //        var client = listener.AcceptTcpClient();
            //        using var stream = client.GetStream();
            //        using var ms = new MemoryStream();
            //        stream.CopyTo(ms);
            //        byte[] data = ms.ToArray();
            //        string header = Encoding.UTF8.GetString(data).Split('|')[0];

            //        if (header.StartsWith("MSG:"))
            //        {
            //            string message = header.Substring(4);
            //            MessageBox.Show("Received: " + message);
            //        }
            //        else if (header.StartsWith("FILE:"))
            //        {
            //            string fileName = header.Substring(5).Replace("|", "");
            //            File.WriteAllBytes(fileName, data[(header.Length + 1)..]);
            //            MessageBox.Show("File saved: " + fileName);
            //        }
            //    }
            
            //}).Start();
        }
    }
}
