﻿using System.Net;
using System.Text.Json;
using IpMesseger;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace ChatApp
{
    public partial class frmAddIPAddress : Form
    {
        private readonly HostService _hostService;

        public frmAddIPAddress()
        {
            InitializeComponent();
            _hostService = new HostService("hostinfo.json");
        }

        private void frmAddIPAddress_Load(object sender, EventArgs e)
        {
            LoadHosts();
        }

        private async void LoadHosts()
        {
            var hosts = await _hostService.GetHostAsync();
            //dgvHostInfo.DataSource = null;
            dgvHostInfo.DataSource = hosts;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtUserName.Text.Trim() == string.Empty)
            {
                txtUserName.Focus();
                MessageBox.Show("Enter the user name.", "IP Messeger", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtIPAddress.Text.Trim() == string.Empty)
            {
                txtIPAddress.Focus();
                MessageBox.Show("Enter the ip address.", "IP Messeger", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtHostName.Text.Trim() == string.Empty)
            {
                txtHostName.Focus();
                MessageBox.Show("Enter the host name.", "IP Messeger", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                if (btnAdd.Text == "Add")
                {
                    var hostData = new HostDetails
                    {
                        GUID = Convert.ToString(Guid.NewGuid()),
                        UserName = txtUserName.Text.Trim(),
                        IPAddress = txtIPAddress.Text.Trim(),
                        HostName = txtHostName.Text.Trim()
                    };

                    var result = _hostService.AddHostAsync(hostData);

                    if (result != null)
                    {
                        LoadHosts();
                    }
                }
                else
                {

                }

                txtUserName.Text = string.Empty;
                txtIPAddress.Text = string.Empty;
                txtHostName.Text = string.Empty;
                btnAdd.Text = "Add";

                MessageBox.Show("IP address details saved.", "IP Messeger", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void dgvHostInfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0 && e.RowIndex > -1)
            {
                txtUserName.Tag = Convert.ToString(dgvHostInfo.Rows[e.RowIndex].Cells["GUID"].Value);
                txtUserName.Text = Convert.ToString(dgvHostInfo.Rows[e.RowIndex].Cells["UserName"].Value);
                txtIPAddress.Text = Convert.ToString(dgvHostInfo.Rows[e.RowIndex].Cells["IPAddress"].Value);
                txtHostName.Text = Convert.ToString(dgvHostInfo.Rows[e.RowIndex].Cells["HostName"].Value);
                btnAdd.Text = "Update";
                txtUserName.Focus();
            }
            else if (e.ColumnIndex == 1 && e.RowIndex > -1)
            {
                txtUserName.Tag = Convert.ToString(dgvHostInfo.Rows[e.RowIndex].Cells["GUID"].Value);
                LoadHosts();
            }
        }
    }
}
