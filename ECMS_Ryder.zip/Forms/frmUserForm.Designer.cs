﻿namespace ECMS_Ryder.Forms
{
    partial class frmUserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnViewAllMailBoxes = new System.Windows.Forms.Button();
            this.btnClearMailBox = new System.Windows.Forms.Button();
            this.btnSaveMaiBox = new System.Windows.Forms.Button();
            this.cmbMailBoxStatus = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtEmailAddress = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvMailboxes = new System.Windows.Forms.DataGridView();
            this.Update = new System.Windows.Forms.DataGridViewLinkColumn();
            this.Delete = new System.Windows.Forms.DataGridViewLinkColumn();
            this.EmailBoxId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmailAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EntryUser = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EntryDateTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FolderName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.UserManagementTab = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dgvUsers = new System.Windows.Forms.DataGridView();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnViewAll = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.txtUID = new System.Windows.Forms.TextBox();
            this.cmbUserStatus = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.cmbRole = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.MailBoxTab = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.CPIMMasterTab = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.dgvCPIMDetails = new System.Windows.Forms.DataGridView();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.btnClearCPIMMaster = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnUpload = new System.Windows.Forms.Button();
            this.txtCPIMMaster = new System.Windows.Forms.TextBox();
            this.CategoryTab = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.dgvCategories = new System.Windows.Forms.DataGridView();
            this.UpdateCategory = new System.Windows.Forms.DataGridViewLinkColumn();
            this.DeleteCategory = new System.Windows.Forms.DataGridViewLinkColumn();
            this.CategoryIdCategory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Category = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.btnViewAllCategories = new System.Windows.Forms.Button();
            this.btnClearCategory = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.btnSaveCategory = new System.Windows.Forms.Button();
            this.txtCategory = new System.Windows.Forms.TextBox();
            this.SubCategoryTab = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.dgvSubCategories = new System.Windows.Forms.DataGridView();
            this.UpdateSubCategory = new System.Windows.Forms.DataGridViewLinkColumn();
            this.DeleteSubCategory = new System.Windows.Forms.DataGridViewLinkColumn();
            this.SubCategoryId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SubCategory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CategoryIdSubCategory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CategorySubCategory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.btnViewAllSubCategories = new System.Windows.Forms.Button();
            this.btnClearSubCategory = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.btnSaveSubCategory = new System.Windows.Forms.Button();
            this.txtSubCategory = new System.Windows.Forms.TextBox();
            this.cmbCategory = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.InclusionsTab = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.dgvInclusions = new System.Windows.Forms.DataGridView();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.btnViewAllInclusion = new System.Windows.Forms.Button();
            this.btnClearInclusion = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.btnSaveInclusion = new System.Windows.Forms.Button();
            this.txtInclusion = new System.Windows.Forms.TextBox();
            this.cmbSubCategory = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.dataGridViewLinkColumn1 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn2 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.InclusionID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SubCategoryIdInclusion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SubCategoryInclusion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Inclusion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMailboxes)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.UserManagementTab.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsers)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.MailBoxTab.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.CPIMMasterTab.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCPIMDetails)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.CategoryTab.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCategories)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.SubCategoryTab.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSubCategories)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.InclusionsTab.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInclusions)).BeginInit();
            this.groupBox12.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnViewAllMailBoxes
            // 
            this.btnViewAllMailBoxes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnViewAllMailBoxes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnViewAllMailBoxes.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewAllMailBoxes.Location = new System.Drawing.Point(584, 178);
            this.btnViewAllMailBoxes.Name = "btnViewAllMailBoxes";
            this.btnViewAllMailBoxes.Size = new System.Drawing.Size(131, 46);
            this.btnViewAllMailBoxes.TabIndex = 11;
            this.btnViewAllMailBoxes.Text = "View All";
            this.btnViewAllMailBoxes.UseVisualStyleBackColor = false;
            this.btnViewAllMailBoxes.Click += new System.EventHandler(this.btnViewAllMailBoxes_Click);
            // 
            // btnClearMailBox
            // 
            this.btnClearMailBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnClearMailBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClearMailBox.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearMailBox.Location = new System.Drawing.Point(437, 178);
            this.btnClearMailBox.Name = "btnClearMailBox";
            this.btnClearMailBox.Size = new System.Drawing.Size(131, 46);
            this.btnClearMailBox.TabIndex = 10;
            this.btnClearMailBox.Text = "Clear";
            this.btnClearMailBox.UseVisualStyleBackColor = false;
            this.btnClearMailBox.Click += new System.EventHandler(this.btnClearMailBox_Click);
            // 
            // btnSaveMaiBox
            // 
            this.btnSaveMaiBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnSaveMaiBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveMaiBox.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveMaiBox.Location = new System.Drawing.Point(290, 178);
            this.btnSaveMaiBox.Name = "btnSaveMaiBox";
            this.btnSaveMaiBox.Size = new System.Drawing.Size(131, 46);
            this.btnSaveMaiBox.TabIndex = 9;
            this.btnSaveMaiBox.Text = "Save";
            this.btnSaveMaiBox.UseVisualStyleBackColor = false;
            this.btnSaveMaiBox.Click += new System.EventHandler(this.btnSaveMaiBox_Click);
            // 
            // cmbMailBoxStatus
            // 
            this.cmbMailBoxStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMailBoxStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMailBoxStatus.FormattingEnabled = true;
            this.cmbMailBoxStatus.Items.AddRange(new object[] {
            "Select",
            "Active",
            "InActive"});
            this.cmbMailBoxStatus.Location = new System.Drawing.Point(292, 107);
            this.cmbMailBoxStatus.Name = "cmbMailBoxStatus";
            this.cmbMailBoxStatus.Size = new System.Drawing.Size(276, 33);
            this.cmbMailBoxStatus.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(197, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 22);
            this.label5.TabIndex = 7;
            this.label5.Text = "Status:-";
            // 
            // txtEmailAddress
            // 
            this.txtEmailAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailAddress.Location = new System.Drawing.Point(292, 53);
            this.txtEmailAddress.Name = "txtEmailAddress";
            this.txtEmailAddress.Size = new System.Drawing.Size(423, 30);
            this.txtEmailAddress.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(116, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(158, 22);
            this.label2.TabIndex = 0;
            this.label2.Text = "Email Address:-";
            // 
            // dgvMailboxes
            // 
            this.dgvMailboxes.AllowUserToAddRows = false;
            this.dgvMailboxes.AllowUserToDeleteRows = false;
            this.dgvMailboxes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMailboxes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Update,
            this.Delete,
            this.EmailBoxId,
            this.EmailAddress,
            this.Status,
            this.EntryUser,
            this.EntryDateTime,
            this.FolderName});
            this.dgvMailboxes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvMailboxes.Location = new System.Drawing.Point(3, 24);
            this.dgvMailboxes.Name = "dgvMailboxes";
            this.dgvMailboxes.ReadOnly = true;
            this.dgvMailboxes.RowHeadersWidth = 51;
            this.dgvMailboxes.RowTemplate.Height = 24;
            this.dgvMailboxes.Size = new System.Drawing.Size(1234, 375);
            this.dgvMailboxes.TabIndex = 0;
            this.dgvMailboxes.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMailboxes_CellContentClick);
            // 
            // Update
            // 
            this.Update.FillWeight = 35.13477F;
            this.Update.HeaderText = "Update";
            this.Update.MinimumWidth = 6;
            this.Update.Name = "Update";
            this.Update.ReadOnly = true;
            this.Update.Text = "Update";
            this.Update.UseColumnTextForLinkValue = true;
            this.Update.Width = 74;
            // 
            // Delete
            // 
            this.Delete.FillWeight = 46.87789F;
            this.Delete.HeaderText = "Delete";
            this.Delete.MinimumWidth = 6;
            this.Delete.Name = "Delete";
            this.Delete.ReadOnly = true;
            this.Delete.Text = "Delete";
            this.Delete.UseColumnTextForLinkValue = true;
            this.Delete.Width = 68;
            // 
            // EmailBoxId
            // 
            this.EmailBoxId.DataPropertyName = "EmailBoxId";
            this.EmailBoxId.FillWeight = 187.1658F;
            this.EmailBoxId.HeaderText = "EmailBoxId";
            this.EmailBoxId.MinimumWidth = 6;
            this.EmailBoxId.Name = "EmailBoxId";
            this.EmailBoxId.ReadOnly = true;
            this.EmailBoxId.Width = 128;
            // 
            // EmailAddress
            // 
            this.EmailAddress.DataPropertyName = "EmailAddress";
            this.EmailAddress.FillWeight = 198.1203F;
            this.EmailAddress.HeaderText = "EmailAddress";
            this.EmailAddress.MinimumWidth = 6;
            this.EmailAddress.Name = "EmailAddress";
            this.EmailAddress.ReadOnly = true;
            this.EmailAddress.Width = 149;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.FillWeight = 44.01512F;
            this.Status.HeaderText = "Status";
            this.Status.MinimumWidth = 6;
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.Width = 90;
            // 
            // EntryUser
            // 
            this.EntryUser.DataPropertyName = "EntryUser";
            this.EntryUser.FillWeight = 46.10896F;
            this.EntryUser.HeaderText = "EntryUser";
            this.EntryUser.MinimumWidth = 6;
            this.EntryUser.Name = "EntryUser";
            this.EntryUser.ReadOnly = true;
            this.EntryUser.Width = 119;
            // 
            // EntryDateTime
            // 
            this.EntryDateTime.DataPropertyName = "EntryDateTime";
            this.EntryDateTime.FillWeight = 142.5772F;
            this.EntryDateTime.HeaderText = "EntryDateTime";
            this.EntryDateTime.MinimumWidth = 6;
            this.EntryDateTime.Name = "EntryDateTime";
            this.EntryDateTime.ReadOnly = true;
            this.EntryDateTime.Width = 159;
            // 
            // FolderName
            // 
            this.FolderName.DataPropertyName = "FolderName";
            this.FolderName.HeaderText = "FolderName";
            this.FolderName.MinimumWidth = 6;
            this.FolderName.Name = "FolderName";
            this.FolderName.ReadOnly = true;
            this.FolderName.Visible = false;
            this.FolderName.Width = 137;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Rockwell", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1259, 52);
            this.label1.TabIndex = 0;
            this.label1.Text = "Admin Center";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.UserManagementTab);
            this.tabControl1.Controls.Add(this.MailBoxTab);
            this.tabControl1.Controls.Add(this.CPIMMasterTab);
            this.tabControl1.Controls.Add(this.CategoryTab);
            this.tabControl1.Controls.Add(this.SubCategoryTab);
            this.tabControl1.Controls.Add(this.InclusionsTab);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(3, 59);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1254, 708);
            this.tabControl1.TabIndex = 1;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // UserManagementTab
            // 
            this.UserManagementTab.Controls.Add(this.groupBox3);
            this.UserManagementTab.Controls.Add(this.groupBox4);
            this.UserManagementTab.Location = new System.Drawing.Point(4, 31);
            this.UserManagementTab.Name = "UserManagementTab";
            this.UserManagementTab.Padding = new System.Windows.Forms.Padding(3);
            this.UserManagementTab.Size = new System.Drawing.Size(1246, 673);
            this.UserManagementTab.TabIndex = 1;
            this.UserManagementTab.Text = "User Management";
            this.UserManagementTab.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dgvUsers);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(3, 340);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1240, 325);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            // 
            // dgvUsers
            // 
            this.dgvUsers.AllowUserToAddRows = false;
            this.dgvUsers.AllowUserToDeleteRows = false;
            this.dgvUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUsers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvUsers.Location = new System.Drawing.Point(3, 24);
            this.dgvUsers.Name = "dgvUsers";
            this.dgvUsers.ReadOnly = true;
            this.dgvUsers.RowHeadersWidth = 51;
            this.dgvUsers.RowTemplate.Height = 24;
            this.dgvUsers.Size = new System.Drawing.Size(1234, 298);
            this.dgvUsers.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnViewAll);
            this.groupBox4.Controls.Add(this.btnSearch);
            this.groupBox4.Controls.Add(this.btnClear);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.btnSubmit);
            this.groupBox4.Controls.Add(this.txtUID);
            this.groupBox4.Controls.Add(this.cmbUserStatus);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.txtUserName);
            this.groupBox4.Controls.Add(this.cmbRole);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox4.Location = new System.Drawing.Point(3, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1240, 337);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            // 
            // btnViewAll
            // 
            this.btnViewAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnViewAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnViewAll.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewAll.Location = new System.Drawing.Point(586, 265);
            this.btnViewAll.Name = "btnViewAll";
            this.btnViewAll.Size = new System.Drawing.Size(131, 46);
            this.btnViewAll.TabIndex = 11;
            this.btnViewAll.Text = "View All";
            this.btnViewAll.UseVisualStyleBackColor = false;
            this.btnViewAll.Click += new System.EventHandler(this.btnViewAll_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(598, 30);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(131, 46);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(439, 265);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(131, 46);
            this.btnClear.TabIndex = 10;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(219, 42);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 22);
            this.label6.TabIndex = 0;
            this.label6.Text = "UID:-";
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnSubmit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubmit.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(292, 265);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(131, 46);
            this.btnSubmit.TabIndex = 9;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // txtUID
            // 
            this.txtUID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtUID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUID.Location = new System.Drawing.Point(292, 38);
            this.txtUID.Name = "txtUID";
            this.txtUID.Size = new System.Drawing.Size(294, 30);
            this.txtUID.TabIndex = 1;
            // 
            // cmbUserStatus
            // 
            this.cmbUserStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUserStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbUserStatus.FormattingEnabled = true;
            this.cmbUserStatus.Items.AddRange(new object[] {
            "Select",
            "Active",
            "InActive"});
            this.cmbUserStatus.Location = new System.Drawing.Point(292, 197);
            this.cmbUserStatus.Name = "cmbUserStatus";
            this.cmbUserStatus.Size = new System.Drawing.Size(294, 33);
            this.cmbUserStatus.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(154, 93);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 22);
            this.label7.TabIndex = 3;
            this.label7.Text = "User Name:-";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(153, 202);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(124, 22);
            this.label8.TabIndex = 7;
            this.label8.Text = "User Status:-";
            // 
            // txtUserName
            // 
            this.txtUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUserName.Location = new System.Drawing.Point(292, 89);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(294, 30);
            this.txtUserName.TabIndex = 4;
            // 
            // cmbRole
            // 
            this.cmbRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRole.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbRole.FormattingEnabled = true;
            this.cmbRole.Items.AddRange(new object[] {
            "Select",
            "Admin",
            "Associate"});
            this.cmbRole.Location = new System.Drawing.Point(292, 140);
            this.cmbRole.Name = "cmbRole";
            this.cmbRole.Size = new System.Drawing.Size(294, 33);
            this.cmbRole.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(214, 145);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 22);
            this.label9.TabIndex = 5;
            this.label9.Text = "Role:-";
            // 
            // MailBoxTab
            // 
            this.MailBoxTab.Controls.Add(this.groupBox2);
            this.MailBoxTab.Controls.Add(this.groupBox1);
            this.MailBoxTab.Location = new System.Drawing.Point(4, 31);
            this.MailBoxTab.Name = "MailBoxTab";
            this.MailBoxTab.Padding = new System.Windows.Forms.Padding(3);
            this.MailBoxTab.Size = new System.Drawing.Size(1246, 673);
            this.MailBoxTab.TabIndex = 0;
            this.MailBoxTab.Text = "MailBox Management";
            this.MailBoxTab.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgvMailboxes);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Location = new System.Drawing.Point(3, 265);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1240, 402);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnViewAllMailBoxes);
            this.groupBox1.Controls.Add(this.btnClearMailBox);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.btnSaveMaiBox);
            this.groupBox1.Controls.Add(this.txtEmailAddress);
            this.groupBox1.Controls.Add(this.cmbMailBoxStatus);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1240, 262);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // CPIMMasterTab
            // 
            this.CPIMMasterTab.Controls.Add(this.groupBox6);
            this.CPIMMasterTab.Controls.Add(this.groupBox5);
            this.CPIMMasterTab.Location = new System.Drawing.Point(4, 31);
            this.CPIMMasterTab.Name = "CPIMMasterTab";
            this.CPIMMasterTab.Size = new System.Drawing.Size(1246, 673);
            this.CPIMMasterTab.TabIndex = 2;
            this.CPIMMasterTab.Text = "CPIM Master";
            this.CPIMMasterTab.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.dgvCPIMDetails);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox6.Location = new System.Drawing.Point(0, 178);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(1246, 493);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            // 
            // dgvCPIMDetails
            // 
            this.dgvCPIMDetails.AllowUserToAddRows = false;
            this.dgvCPIMDetails.AllowUserToDeleteRows = false;
            this.dgvCPIMDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCPIMDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCPIMDetails.Location = new System.Drawing.Point(3, 24);
            this.dgvCPIMDetails.Name = "dgvCPIMDetails";
            this.dgvCPIMDetails.ReadOnly = true;
            this.dgvCPIMDetails.RowHeadersWidth = 51;
            this.dgvCPIMDetails.RowTemplate.Height = 24;
            this.dgvCPIMDetails.Size = new System.Drawing.Size(1240, 466);
            this.dgvCPIMDetails.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnBrowse);
            this.groupBox5.Controls.Add(this.btnClearCPIMMaster);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.btnUpload);
            this.groupBox5.Controls.Add(this.txtCPIMMaster);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox5.Location = new System.Drawing.Point(0, 0);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1246, 178);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            // 
            // btnBrowse
            // 
            this.btnBrowse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnBrowse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBrowse.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowse.Location = new System.Drawing.Point(209, 97);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(131, 46);
            this.btnBrowse.TabIndex = 2;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = false;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // btnClearCPIMMaster
            // 
            this.btnClearCPIMMaster.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnClearCPIMMaster.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClearCPIMMaster.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearCPIMMaster.Location = new System.Drawing.Point(661, 97);
            this.btnClearCPIMMaster.Name = "btnClearCPIMMaster";
            this.btnClearCPIMMaster.Size = new System.Drawing.Size(131, 46);
            this.btnClearCPIMMaster.TabIndex = 4;
            this.btnClearCPIMMaster.Text = "Clear";
            this.btnClearCPIMMaster.UseVisualStyleBackColor = false;
            this.btnClearCPIMMaster.Click += new System.EventHandler(this.btnClearCPIMMaster_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(9, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 22);
            this.label3.TabIndex = 0;
            this.label3.Text = "CPIM Master File";
            // 
            // btnUpload
            // 
            this.btnUpload.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnUpload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpload.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpload.Location = new System.Drawing.Point(369, 97);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(263, 46);
            this.btnUpload.TabIndex = 3;
            this.btnUpload.Text = "Upload And Allocate";
            this.btnUpload.UseVisualStyleBackColor = false;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // txtCPIMMaster
            // 
            this.txtCPIMMaster.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCPIMMaster.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCPIMMaster.Location = new System.Drawing.Point(208, 38);
            this.txtCPIMMaster.Name = "txtCPIMMaster";
            this.txtCPIMMaster.ReadOnly = true;
            this.txtCPIMMaster.Size = new System.Drawing.Size(822, 30);
            this.txtCPIMMaster.TabIndex = 1;
            // 
            // CategoryTab
            // 
            this.CategoryTab.Controls.Add(this.groupBox7);
            this.CategoryTab.Controls.Add(this.groupBox8);
            this.CategoryTab.Location = new System.Drawing.Point(4, 31);
            this.CategoryTab.Name = "CategoryTab";
            this.CategoryTab.Padding = new System.Windows.Forms.Padding(3);
            this.CategoryTab.Size = new System.Drawing.Size(1246, 673);
            this.CategoryTab.TabIndex = 3;
            this.CategoryTab.Text = "Category Master";
            this.CategoryTab.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.dgvCategories);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox7.Location = new System.Drawing.Point(3, 196);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(1240, 472);
            this.groupBox7.TabIndex = 3;
            this.groupBox7.TabStop = false;
            // 
            // dgvCategories
            // 
            this.dgvCategories.AllowUserToAddRows = false;
            this.dgvCategories.AllowUserToDeleteRows = false;
            this.dgvCategories.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvCategories.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCategories.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.UpdateCategory,
            this.DeleteCategory,
            this.CategoryIdCategory,
            this.Category});
            this.dgvCategories.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCategories.Location = new System.Drawing.Point(3, 24);
            this.dgvCategories.Name = "dgvCategories";
            this.dgvCategories.ReadOnly = true;
            this.dgvCategories.RowHeadersWidth = 51;
            this.dgvCategories.RowTemplate.Height = 24;
            this.dgvCategories.Size = new System.Drawing.Size(1234, 445);
            this.dgvCategories.TabIndex = 0;
            this.dgvCategories.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCategories_CellContentClick);
            // 
            // UpdateCategory
            // 
            this.UpdateCategory.HeaderText = "Update";
            this.UpdateCategory.MinimumWidth = 6;
            this.UpdateCategory.Name = "UpdateCategory";
            this.UpdateCategory.ReadOnly = true;
            this.UpdateCategory.Text = "Update";
            this.UpdateCategory.UseColumnTextForLinkValue = true;
            this.UpdateCategory.Width = 74;
            // 
            // DeleteCategory
            // 
            this.DeleteCategory.HeaderText = "Delete";
            this.DeleteCategory.MinimumWidth = 6;
            this.DeleteCategory.Name = "DeleteCategory";
            this.DeleteCategory.ReadOnly = true;
            this.DeleteCategory.Text = "Delete";
            this.DeleteCategory.UseColumnTextForLinkValue = true;
            this.DeleteCategory.Width = 68;
            // 
            // CategoryIdCategory
            // 
            this.CategoryIdCategory.DataPropertyName = "CategoryId";
            this.CategoryIdCategory.HeaderText = "CategoryId";
            this.CategoryIdCategory.MinimumWidth = 6;
            this.CategoryIdCategory.Name = "CategoryIdCategory";
            this.CategoryIdCategory.ReadOnly = true;
            this.CategoryIdCategory.Width = 126;
            // 
            // Category
            // 
            this.Category.DataPropertyName = "Category";
            this.Category.HeaderText = "Category";
            this.Category.MinimumWidth = 6;
            this.Category.Name = "Category";
            this.Category.ReadOnly = true;
            this.Category.Width = 112;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.btnViewAllCategories);
            this.groupBox8.Controls.Add(this.btnClearCategory);
            this.groupBox8.Controls.Add(this.label4);
            this.groupBox8.Controls.Add(this.btnSaveCategory);
            this.groupBox8.Controls.Add(this.txtCategory);
            this.groupBox8.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox8.Location = new System.Drawing.Point(3, 3);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(1240, 193);
            this.groupBox8.TabIndex = 2;
            this.groupBox8.TabStop = false;
            // 
            // btnViewAllCategories
            // 
            this.btnViewAllCategories.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnViewAllCategories.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnViewAllCategories.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewAllCategories.Location = new System.Drawing.Point(584, 128);
            this.btnViewAllCategories.Name = "btnViewAllCategories";
            this.btnViewAllCategories.Size = new System.Drawing.Size(131, 46);
            this.btnViewAllCategories.TabIndex = 11;
            this.btnViewAllCategories.Text = "View All";
            this.btnViewAllCategories.UseVisualStyleBackColor = false;
            this.btnViewAllCategories.Click += new System.EventHandler(this.btnViewAllCategories_Click);
            // 
            // btnClearCategory
            // 
            this.btnClearCategory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnClearCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClearCategory.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearCategory.Location = new System.Drawing.Point(437, 128);
            this.btnClearCategory.Name = "btnClearCategory";
            this.btnClearCategory.Size = new System.Drawing.Size(131, 46);
            this.btnClearCategory.TabIndex = 10;
            this.btnClearCategory.Text = "Clear";
            this.btnClearCategory.UseVisualStyleBackColor = false;
            this.btnClearCategory.Click += new System.EventHandler(this.btnClearCategory_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(158, 55);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 22);
            this.label4.TabIndex = 0;
            this.label4.Text = "Category:-";
            // 
            // btnSaveCategory
            // 
            this.btnSaveCategory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnSaveCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveCategory.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveCategory.Location = new System.Drawing.Point(290, 128);
            this.btnSaveCategory.Name = "btnSaveCategory";
            this.btnSaveCategory.Size = new System.Drawing.Size(131, 46);
            this.btnSaveCategory.TabIndex = 9;
            this.btnSaveCategory.Text = "Save";
            this.btnSaveCategory.UseVisualStyleBackColor = false;
            this.btnSaveCategory.Click += new System.EventHandler(this.btnSaveCategory_Click);
            // 
            // txtCategory
            // 
            this.txtCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCategory.Location = new System.Drawing.Point(292, 53);
            this.txtCategory.Name = "txtCategory";
            this.txtCategory.Size = new System.Drawing.Size(423, 30);
            this.txtCategory.TabIndex = 1;
            // 
            // SubCategoryTab
            // 
            this.SubCategoryTab.Controls.Add(this.groupBox9);
            this.SubCategoryTab.Controls.Add(this.groupBox10);
            this.SubCategoryTab.Location = new System.Drawing.Point(4, 31);
            this.SubCategoryTab.Name = "SubCategoryTab";
            this.SubCategoryTab.Padding = new System.Windows.Forms.Padding(3);
            this.SubCategoryTab.Size = new System.Drawing.Size(1246, 673);
            this.SubCategoryTab.TabIndex = 4;
            this.SubCategoryTab.Text = "SubCategory Master";
            this.SubCategoryTab.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.dgvSubCategories);
            this.groupBox9.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox9.Location = new System.Drawing.Point(3, 265);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(1240, 402);
            this.groupBox9.TabIndex = 3;
            this.groupBox9.TabStop = false;
            // 
            // dgvSubCategories
            // 
            this.dgvSubCategories.AllowUserToAddRows = false;
            this.dgvSubCategories.AllowUserToDeleteRows = false;
            this.dgvSubCategories.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvSubCategories.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSubCategories.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.UpdateSubCategory,
            this.DeleteSubCategory,
            this.SubCategoryId,
            this.SubCategory,
            this.CategoryIdSubCategory,
            this.CategorySubCategory});
            this.dgvSubCategories.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSubCategories.Location = new System.Drawing.Point(3, 24);
            this.dgvSubCategories.Name = "dgvSubCategories";
            this.dgvSubCategories.ReadOnly = true;
            this.dgvSubCategories.RowHeadersWidth = 51;
            this.dgvSubCategories.RowTemplate.Height = 24;
            this.dgvSubCategories.Size = new System.Drawing.Size(1234, 375);
            this.dgvSubCategories.TabIndex = 0;
            this.dgvSubCategories.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSubCategories_CellContentClick);
            // 
            // UpdateSubCategory
            // 
            this.UpdateSubCategory.HeaderText = "Update";
            this.UpdateSubCategory.MinimumWidth = 6;
            this.UpdateSubCategory.Name = "UpdateSubCategory";
            this.UpdateSubCategory.ReadOnly = true;
            this.UpdateSubCategory.Text = "Update";
            this.UpdateSubCategory.UseColumnTextForLinkValue = true;
            this.UpdateSubCategory.Width = 74;
            // 
            // DeleteSubCategory
            // 
            this.DeleteSubCategory.HeaderText = "Delete";
            this.DeleteSubCategory.MinimumWidth = 6;
            this.DeleteSubCategory.Name = "DeleteSubCategory";
            this.DeleteSubCategory.ReadOnly = true;
            this.DeleteSubCategory.Text = "Delete";
            this.DeleteSubCategory.UseColumnTextForLinkValue = true;
            this.DeleteSubCategory.Width = 68;
            // 
            // SubCategoryId
            // 
            this.SubCategoryId.DataPropertyName = "SubCategoryId";
            this.SubCategoryId.HeaderText = "SubCategoryId";
            this.SubCategoryId.MinimumWidth = 6;
            this.SubCategoryId.Name = "SubCategoryId";
            this.SubCategoryId.ReadOnly = true;
            this.SubCategoryId.Width = 158;
            // 
            // SubCategory
            // 
            this.SubCategory.DataPropertyName = "SubCategory";
            this.SubCategory.HeaderText = "SubCategory";
            this.SubCategory.MinimumWidth = 6;
            this.SubCategory.Name = "SubCategory";
            this.SubCategory.ReadOnly = true;
            this.SubCategory.Width = 144;
            // 
            // CategoryIdSubCategory
            // 
            this.CategoryIdSubCategory.DataPropertyName = "CategoryId";
            this.CategoryIdSubCategory.HeaderText = "CategoryId";
            this.CategoryIdSubCategory.MinimumWidth = 6;
            this.CategoryIdSubCategory.Name = "CategoryIdSubCategory";
            this.CategoryIdSubCategory.ReadOnly = true;
            this.CategoryIdSubCategory.Width = 126;
            // 
            // CategorySubCategory
            // 
            this.CategorySubCategory.DataPropertyName = "Category";
            this.CategorySubCategory.HeaderText = "Category";
            this.CategorySubCategory.MinimumWidth = 6;
            this.CategorySubCategory.Name = "CategorySubCategory";
            this.CategorySubCategory.ReadOnly = true;
            this.CategorySubCategory.Width = 112;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.btnViewAllSubCategories);
            this.groupBox10.Controls.Add(this.btnClearSubCategory);
            this.groupBox10.Controls.Add(this.label11);
            this.groupBox10.Controls.Add(this.btnSaveSubCategory);
            this.groupBox10.Controls.Add(this.txtSubCategory);
            this.groupBox10.Controls.Add(this.cmbCategory);
            this.groupBox10.Controls.Add(this.label12);
            this.groupBox10.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox10.Location = new System.Drawing.Point(3, 3);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(1240, 262);
            this.groupBox10.TabIndex = 2;
            this.groupBox10.TabStop = false;
            // 
            // btnViewAllSubCategories
            // 
            this.btnViewAllSubCategories.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnViewAllSubCategories.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnViewAllSubCategories.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewAllSubCategories.Location = new System.Drawing.Point(584, 178);
            this.btnViewAllSubCategories.Name = "btnViewAllSubCategories";
            this.btnViewAllSubCategories.Size = new System.Drawing.Size(131, 46);
            this.btnViewAllSubCategories.TabIndex = 11;
            this.btnViewAllSubCategories.Text = "View All";
            this.btnViewAllSubCategories.UseVisualStyleBackColor = false;
            this.btnViewAllSubCategories.Click += new System.EventHandler(this.btnViewAllSubCategories_Click);
            // 
            // btnClearSubCategory
            // 
            this.btnClearSubCategory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnClearSubCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClearSubCategory.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearSubCategory.Location = new System.Drawing.Point(437, 178);
            this.btnClearSubCategory.Name = "btnClearSubCategory";
            this.btnClearSubCategory.Size = new System.Drawing.Size(131, 46);
            this.btnClearSubCategory.TabIndex = 10;
            this.btnClearSubCategory.Text = "Clear";
            this.btnClearSubCategory.UseVisualStyleBackColor = false;
            this.btnClearSubCategory.Click += new System.EventHandler(this.btnClearSubCategory_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(114, 117);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(149, 22);
            this.label11.TabIndex = 0;
            this.label11.Text = "Sub Category:-";
            // 
            // btnSaveSubCategory
            // 
            this.btnSaveSubCategory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnSaveSubCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveSubCategory.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveSubCategory.Location = new System.Drawing.Point(290, 178);
            this.btnSaveSubCategory.Name = "btnSaveSubCategory";
            this.btnSaveSubCategory.Size = new System.Drawing.Size(131, 46);
            this.btnSaveSubCategory.TabIndex = 9;
            this.btnSaveSubCategory.Text = "Save";
            this.btnSaveSubCategory.UseVisualStyleBackColor = false;
            this.btnSaveSubCategory.Click += new System.EventHandler(this.btnSaveSubCategory_Click);
            // 
            // txtSubCategory
            // 
            this.txtSubCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSubCategory.Location = new System.Drawing.Point(290, 113);
            this.txtSubCategory.Name = "txtSubCategory";
            this.txtSubCategory.Size = new System.Drawing.Size(423, 30);
            this.txtSubCategory.TabIndex = 1;
            // 
            // cmbCategory
            // 
            this.cmbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCategory.FormattingEnabled = true;
            this.cmbCategory.Items.AddRange(new object[] {
            "Select",
            "Active",
            "InActive"});
            this.cmbCategory.Location = new System.Drawing.Point(290, 39);
            this.cmbCategory.Name = "cmbCategory";
            this.cmbCategory.Size = new System.Drawing.Size(425, 33);
            this.cmbCategory.TabIndex = 8;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(154, 43);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(109, 22);
            this.label12.TabIndex = 7;
            this.label12.Text = "Category:-";
            // 
            // InclusionsTab
            // 
            this.InclusionsTab.Controls.Add(this.groupBox11);
            this.InclusionsTab.Controls.Add(this.groupBox12);
            this.InclusionsTab.Location = new System.Drawing.Point(4, 31);
            this.InclusionsTab.Name = "InclusionsTab";
            this.InclusionsTab.Padding = new System.Windows.Forms.Padding(3);
            this.InclusionsTab.Size = new System.Drawing.Size(1246, 673);
            this.InclusionsTab.TabIndex = 5;
            this.InclusionsTab.Text = "Inclusions Master";
            this.InclusionsTab.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.dgvInclusions);
            this.groupBox11.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox11.Location = new System.Drawing.Point(3, 265);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(1240, 402);
            this.groupBox11.TabIndex = 5;
            this.groupBox11.TabStop = false;
            // 
            // dgvInclusions
            // 
            this.dgvInclusions.AllowUserToAddRows = false;
            this.dgvInclusions.AllowUserToDeleteRows = false;
            this.dgvInclusions.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvInclusions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInclusions.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewLinkColumn1,
            this.dataGridViewLinkColumn2,
            this.InclusionID,
            this.SubCategoryIdInclusion,
            this.SubCategoryInclusion,
            this.Inclusion});
            this.dgvInclusions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvInclusions.Location = new System.Drawing.Point(3, 24);
            this.dgvInclusions.Name = "dgvInclusions";
            this.dgvInclusions.ReadOnly = true;
            this.dgvInclusions.RowHeadersWidth = 51;
            this.dgvInclusions.RowTemplate.Height = 24;
            this.dgvInclusions.Size = new System.Drawing.Size(1234, 375);
            this.dgvInclusions.TabIndex = 0;
            this.dgvInclusions.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvInclusions_CellContentClick);
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.btnViewAllInclusion);
            this.groupBox12.Controls.Add(this.btnClearInclusion);
            this.groupBox12.Controls.Add(this.label10);
            this.groupBox12.Controls.Add(this.btnSaveInclusion);
            this.groupBox12.Controls.Add(this.txtInclusion);
            this.groupBox12.Controls.Add(this.cmbSubCategory);
            this.groupBox12.Controls.Add(this.label13);
            this.groupBox12.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox12.Location = new System.Drawing.Point(3, 3);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(1240, 262);
            this.groupBox12.TabIndex = 4;
            this.groupBox12.TabStop = false;
            // 
            // btnViewAllInclusion
            // 
            this.btnViewAllInclusion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnViewAllInclusion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnViewAllInclusion.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewAllInclusion.Location = new System.Drawing.Point(584, 178);
            this.btnViewAllInclusion.Name = "btnViewAllInclusion";
            this.btnViewAllInclusion.Size = new System.Drawing.Size(131, 46);
            this.btnViewAllInclusion.TabIndex = 11;
            this.btnViewAllInclusion.Text = "View All";
            this.btnViewAllInclusion.UseVisualStyleBackColor = false;
            this.btnViewAllInclusion.Click += new System.EventHandler(this.btnViewAllInclusion_Click);
            // 
            // btnClearInclusion
            // 
            this.btnClearInclusion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnClearInclusion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClearInclusion.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearInclusion.Location = new System.Drawing.Point(437, 178);
            this.btnClearInclusion.Name = "btnClearInclusion";
            this.btnClearInclusion.Size = new System.Drawing.Size(131, 46);
            this.btnClearInclusion.TabIndex = 10;
            this.btnClearInclusion.Text = "Clear";
            this.btnClearInclusion.UseVisualStyleBackColor = false;
            this.btnClearInclusion.Click += new System.EventHandler(this.btnClearInclusion_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(141, 117);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(104, 22);
            this.label10.TabIndex = 0;
            this.label10.Text = "Inclusion:-";
            // 
            // btnSaveInclusion
            // 
            this.btnSaveInclusion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnSaveInclusion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveInclusion.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveInclusion.Location = new System.Drawing.Point(290, 178);
            this.btnSaveInclusion.Name = "btnSaveInclusion";
            this.btnSaveInclusion.Size = new System.Drawing.Size(131, 46);
            this.btnSaveInclusion.TabIndex = 9;
            this.btnSaveInclusion.Text = "Save";
            this.btnSaveInclusion.UseVisualStyleBackColor = false;
            this.btnSaveInclusion.Click += new System.EventHandler(this.btnSaveInclusion_Click);
            // 
            // txtInclusion
            // 
            this.txtInclusion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInclusion.Location = new System.Drawing.Point(290, 113);
            this.txtInclusion.Name = "txtInclusion";
            this.txtInclusion.Size = new System.Drawing.Size(423, 30);
            this.txtInclusion.TabIndex = 1;
            // 
            // cmbSubCategory
            // 
            this.cmbSubCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSubCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSubCategory.FormattingEnabled = true;
            this.cmbSubCategory.Items.AddRange(new object[] {
            "Select",
            "Active",
            "InActive"});
            this.cmbSubCategory.Location = new System.Drawing.Point(290, 39);
            this.cmbSubCategory.Name = "cmbSubCategory";
            this.cmbSubCategory.Size = new System.Drawing.Size(425, 33);
            this.cmbSubCategory.TabIndex = 8;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(101, 43);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(144, 22);
            this.label13.TabIndex = 7;
            this.label13.Text = "SubCategory:-";
            // 
            // dataGridViewLinkColumn1
            // 
            this.dataGridViewLinkColumn1.HeaderText = "Update";
            this.dataGridViewLinkColumn1.MinimumWidth = 6;
            this.dataGridViewLinkColumn1.Name = "dataGridViewLinkColumn1";
            this.dataGridViewLinkColumn1.ReadOnly = true;
            this.dataGridViewLinkColumn1.Text = "Update";
            this.dataGridViewLinkColumn1.UseColumnTextForLinkValue = true;
            this.dataGridViewLinkColumn1.Width = 74;
            // 
            // dataGridViewLinkColumn2
            // 
            this.dataGridViewLinkColumn2.HeaderText = "Delete";
            this.dataGridViewLinkColumn2.MinimumWidth = 6;
            this.dataGridViewLinkColumn2.Name = "dataGridViewLinkColumn2";
            this.dataGridViewLinkColumn2.ReadOnly = true;
            this.dataGridViewLinkColumn2.Text = "Delete";
            this.dataGridViewLinkColumn2.UseColumnTextForLinkValue = true;
            this.dataGridViewLinkColumn2.Width = 68;
            // 
            // InclusionID
            // 
            this.InclusionID.DataPropertyName = "InclusionID";
            this.InclusionID.HeaderText = "InclusionID";
            this.InclusionID.MinimumWidth = 6;
            this.InclusionID.Name = "InclusionID";
            this.InclusionID.ReadOnly = true;
            this.InclusionID.Width = 126;
            // 
            // SubCategoryIdInclusion
            // 
            this.SubCategoryIdInclusion.DataPropertyName = "SubCategoryId";
            this.SubCategoryIdInclusion.HeaderText = "SubCategoryId";
            this.SubCategoryIdInclusion.MinimumWidth = 6;
            this.SubCategoryIdInclusion.Name = "SubCategoryIdInclusion";
            this.SubCategoryIdInclusion.ReadOnly = true;
            this.SubCategoryIdInclusion.Width = 158;
            // 
            // SubCategoryInclusion
            // 
            this.SubCategoryInclusion.DataPropertyName = "SubCategory";
            this.SubCategoryInclusion.HeaderText = "SubCategory";
            this.SubCategoryInclusion.MinimumWidth = 6;
            this.SubCategoryInclusion.Name = "SubCategoryInclusion";
            this.SubCategoryInclusion.ReadOnly = true;
            this.SubCategoryInclusion.Width = 144;
            // 
            // Inclusion
            // 
            this.Inclusion.DataPropertyName = "Inclusion";
            this.Inclusion.HeaderText = "Inclusion";
            this.Inclusion.MinimumWidth = 6;
            this.Inclusion.Name = "Inclusion";
            this.Inclusion.ReadOnly = true;
            this.Inclusion.Width = 109;
            // 
            // frmUserForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1259, 772);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label1);
            this.Name = "frmUserForm";
            this.ShowIcon = false;
            this.Text = "Admin Center";
            this.Load += new System.EventHandler(this.frmUserForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMailboxes)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.UserManagementTab.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsers)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.MailBoxTab.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.CPIMMasterTab.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCPIMDetails)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.CategoryTab.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCategories)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.SubCategoryTab.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSubCategories)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.InclusionsTab.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvInclusions)).EndInit();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtEmailAddress;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbMailBoxStatus;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnClearMailBox;
        private System.Windows.Forms.Button btnSaveMaiBox;
        private System.Windows.Forms.Button btnViewAllMailBoxes;
        private System.Windows.Forms.DataGridView dgvMailboxes;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage MailBoxTab;
        private System.Windows.Forms.TabPage UserManagementTab;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dgvUsers;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnViewAll;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.TextBox txtUID;
        private System.Windows.Forms.ComboBox cmbUserStatus;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.ComboBox cmbRole;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridViewLinkColumn Update;
        private System.Windows.Forms.DataGridViewLinkColumn Delete;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmailBoxId;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmailAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn EntryUser;
        private System.Windows.Forms.DataGridViewTextBoxColumn EntryDateTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn FolderName;
        private System.Windows.Forms.TabPage CPIMMasterTab;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Button btnClearCPIMMaster;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.TextBox txtCPIMMaster;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.DataGridView dgvCPIMDetails;
        private System.Windows.Forms.TabPage CategoryTab;
        private System.Windows.Forms.TabPage SubCategoryTab;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.DataGridView dgvCategories;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button btnViewAllCategories;
        private System.Windows.Forms.Button btnClearCategory;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnSaveCategory;
        private System.Windows.Forms.TextBox txtCategory;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.DataGridView dgvSubCategories;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button btnViewAllSubCategories;
        private System.Windows.Forms.Button btnClearSubCategory;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnSaveSubCategory;
        private System.Windows.Forms.TextBox txtSubCategory;
        private System.Windows.Forms.ComboBox cmbCategory;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridViewLinkColumn UpdateCategory;
        private System.Windows.Forms.DataGridViewLinkColumn DeleteCategory;
        private System.Windows.Forms.DataGridViewTextBoxColumn CategoryIdCategory;
        private System.Windows.Forms.DataGridViewTextBoxColumn Category;
        private System.Windows.Forms.DataGridViewLinkColumn UpdateSubCategory;
        private System.Windows.Forms.DataGridViewLinkColumn DeleteSubCategory;
        private System.Windows.Forms.DataGridViewTextBoxColumn SubCategoryId;
        private System.Windows.Forms.DataGridViewTextBoxColumn SubCategory;
        private System.Windows.Forms.DataGridViewTextBoxColumn CategoryIdSubCategory;
        private System.Windows.Forms.DataGridViewTextBoxColumn CategorySubCategory;
        private System.Windows.Forms.TabPage InclusionsTab;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.DataGridView dgvInclusions;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button btnViewAllInclusion;
        private System.Windows.Forms.Button btnClearInclusion;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnSaveInclusion;
        private System.Windows.Forms.TextBox txtInclusion;
        private System.Windows.Forms.ComboBox cmbSubCategory;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DataGridViewLinkColumn dataGridViewLinkColumn1;
        private System.Windows.Forms.DataGridViewLinkColumn dataGridViewLinkColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn InclusionID;
        private System.Windows.Forms.DataGridViewTextBoxColumn SubCategoryIdInclusion;
        private System.Windows.Forms.DataGridViewTextBoxColumn SubCategoryInclusion;
        private System.Windows.Forms.DataGridViewTextBoxColumn Inclusion;
    }
}