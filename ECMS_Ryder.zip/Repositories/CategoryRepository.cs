﻿using System;
using System.Data;
using System.Data.OleDb;
using ECMS_Ryder.Models;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ECMS_Ryder.Repositories
{
    interface iCategoryRepository
    {
        List<CategoryDetails> GetAllCategories();
        CategoryDetails GetCategoryByID(string categoryDetailsID);
        void CreateCategory(CategoryDetails categoryDetails);
        void UpdateCategory(CategoryDetails categoryDetails);
        void DeleteCategory(Int32 CategoryDetailsId);
    }

    internal class CategoryRepository : iCategoryRepository
    {
        private readonly string strConnectionString = "";

        public CategoryRepository(string _strConnectionString)
        {
            strConnectionString = _strConnectionString;
        }

        public List<CategoryDetails> GetAllCategories()
        {
            List<CategoryDetails> categories = new List<CategoryDetails>();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "SELECT * FROM CategoryDetails";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    OleDbDataReader OleDbDataReader = cmd.ExecuteReader();

                    while (OleDbDataReader.Read())
                    {
                        CategoryDetails categoriesDetails = new CategoryDetails();
                        categoriesDetails.CategoryId = Convert.ToInt32(OleDbDataReader["CategoryId"]);
                        categoriesDetails.Category = Convert.ToString(OleDbDataReader["Category"]);
                        
                        //categoriesDetails.EntryUser = Convert.ToString(OleDbDataReader["EntryUser"]);
                        //categoriesDetails.EntryDateTime = Convert.ToString(OleDbDataReader["EntryDateTime"]);

                        categories.Add(categoriesDetails);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetAllCategories:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                categories = null;
            }

            return categories;
        }

        public CategoryDetails GetCategoryByID(string CategoryID)
        {
            CategoryDetails categoriesDetails = new CategoryDetails();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "SELECT * FROM CategoryDetails WHERE CategoryID = @CategoryID";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;
                    
                    cmd.Parameters.AddWithValue("@CategoryID", CategoryID);

                    OleDbDataReader OleDbDataReader = cmd.ExecuteReader();

                    while (OleDbDataReader.Read())
                    {
                        categoriesDetails.CategoryId = Convert.ToInt32(OleDbDataReader["CategoryId"]);
                        categoriesDetails.Category = Convert.ToString(OleDbDataReader["Category"]);
                        
                        //categoriesDetails.EntryUser = Convert.ToString(OleDbDataReader["EntryUser"]);
                        //categoriesDetails.EntryDateTime = Convert.ToString(OleDbDataReader["EntryDateTime"]);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetCategoryByID:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                categoriesDetails = null;
            }

            return categoriesDetails;
        }

        public void CreateCategory(CategoryDetails categoryDetails)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "INSERT INTO CategoryDetails (Category) VALUES(@Category)";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.AddWithValue("@Category", categoryDetails.Category);
                    
                    //cmd.Parameters.AddWithValue("@EntryUser", categoryDetails.EntryUser);
                    //cmd.Parameters.AddWithValue("@EntryDateTime", categoryDetails.EntryDateTime);

                    cmd.ExecuteNonQuery();

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in CreateCategory:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void UpdateCategory(CategoryDetails categoryDetails)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "UPDATE CategoryDetails SET Category = @Category WHERE CategoryId = @CategoryId";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.AddWithValue("@Category", categoryDetails.Category);
                    
                    //cmd.Parameters.AddWithValue("@EntryUser", categoryDetails.EntryUser);
                    //cmd.Parameters.AddWithValue("@EntryDateTime", categoryDetails.EntryDateTime);
                    
                    cmd.Parameters.AddWithValue("@CategoryId", categoryDetails.CategoryId);

                    cmd.ExecuteNonQuery();

                    connection.Close();
                }                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in UpdateCategory:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void DeleteCategory(int CategoryId)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "DELETE FROM CategoryDetails WHERE CategoryId = @CategoryId";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.AddWithValue("@CategoryId", CategoryId);

                    cmd.ExecuteNonQuery();

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in DeleteCategory:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
