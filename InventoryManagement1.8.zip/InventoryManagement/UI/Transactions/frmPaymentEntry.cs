﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;
using InventoryManagement.DataAccessLogic;

namespace InventoryManagement
{
    public partial class frmPaymentEntry : Form
    {
        PaymentModel objPaymentModel = null;
        IGenericRepository<PaymentModel> objPaymentDal = null;

        public frmPaymentEntry(string strChallanNumber, string strChallanAmount, string strCustomerNumber, string strCustomerName)
        {
            InitializeComponent();

            txtChallanNo.Text = strChallanNumber;
            txtChallanAmount.Text = strChallanAmount;
            txtCustomerName.Tag = strCustomerNumber;
            txtCustomerName.Text = strCustomerName;            
        }

        private void frmCustomer_Load(object sender, EventArgs e)
        {
            objPaymentDal = new PaymentDAL();
            ClearFields();
            dtpTrnDate.MaxDate = DateTime.Now;
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (txtChallanNo.Text.Trim() == "")
            {
                txtChallanNo.Focus();
                MessageBox.Show("Invoice no can not be blank.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtChallanAmount.Text.Trim() == "")
            {
                txtChallanAmount.Focus();
                MessageBox.Show("Invoice Amount can not be blank.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtCustomerName.Text.Trim() == "")
            {
                txtCustomerName.Focus();
                MessageBox.Show("Customer Name can not be blank.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (cboModeOfPayment.Text == "Select")
            {
                cboModeOfPayment.Focus();
                MessageBox.Show("Please select mode of payment.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtAmount.Text.Trim() == "")
            {
                txtAmount.Focus();
                MessageBox.Show("Please enter amount.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                Boolean isValid = false;
                try
                {
                    Convert.ToDouble(txtAmount.Text.Trim());
                    isValid = true;
                }
                catch (Exception)
                {
                    isValid = false;
                }

                if (isValid)
                {
                    Cursor = Cursors.WaitCursor;
                    objPaymentModel = new PaymentModel();
                    objPaymentModel.ChallanNo = txtChallanNo.Text.Trim();
                    objPaymentModel.TrnDate = dtpTrnDate.Text.Trim();
                    objPaymentModel.Mode = cboModeOfPayment.Text.Trim();
                    objPaymentModel.Amount = txtAmount.Text.Trim();
                    objPaymentModel.Remarks = txtRemarks.Text.Trim();
                    objPaymentModel.CreatedBy = common.strUserEmail;

                    if (btnSave.Text == "Save")
                    {
                        objPaymentDal.Add(objPaymentModel);
                        ClearFields();
                        //MessageBox.Show("Payment saved successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        objPaymentModel.Code = Convert.ToInt32(txtCode.Text);
                        objPaymentDal.Update(objPaymentModel);
                        ClearFields();
                        //MessageBox.Show("Payment updated successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    Cursor = Cursors.Default;
                }
                else
                {
                    MessageBox.Show("Amount should be numeric.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
        }

        private void ClearFields()
        {
            txtCode.Text = "";
            txtAmount.Text = "";
            txtRemarks.Text = "";
            cboModeOfPayment.SelectedIndex = 0;
            btnSave.Text = "Save";
            dgvData.Enabled = true;
            cboModeOfPayment.Select();
            DisplayData();            
        }

        private void DisplayData()
        {
            List<PaymentModel> lstData = objPaymentDal.GetAll();
            dgvData.DataSource = lstData;

            double dblTotalPaid = 0;

            foreach (PaymentModel item in lstData)
            {
                dblTotalPaid = dblTotalPaid + Convert.ToDouble(item.Amount);
            }

            txtTotalPaid.Text = dblTotalPaid.ToString();
            txtTotalPending.Text = Convert.ToString(Convert.ToDouble(txtChallanAmount.Text) - (dblTotalPaid));
        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (e.ColumnIndex == 0)
                {
                    txtCode.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Code"].Value);
                    dtpTrnDate.Value = Convert.ToDateTime(dgvData.Rows[e.RowIndex].Cells["TrnDate"].Value);
                    cboModeOfPayment.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Mode"].Value);
                    txtAmount.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Amount"].Value);
                    txtRemarks.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Remarks"].Value);
                    btnSave.Text = "Update";
                    dgvData.Enabled = false;
                    cboModeOfPayment.Select();
                }
                if (e.ColumnIndex == 1)
                {
                    if (MessageBox.Show("Do you want to delete?", common.strProjectTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        Int32 code = Convert.ToInt32(dgvData.Rows[e.RowIndex].Cells["Code"].Value);
                        objPaymentDal.Delete(code);

                        ClearFields();

                        //MessageBox.Show("Payment deleted successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
