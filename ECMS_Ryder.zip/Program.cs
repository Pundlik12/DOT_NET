﻿using System;
using ECMS_Ryder.Forms;
using System.Windows.Forms;
using ECMS_Ryder.HelperClasses;
using ECMS_Ryder.Repositories;
using ECMS_Ryder.Models;
using System.DirectoryServices.AccountManagement;
using System.Threading;
using System.Linq;

namespace ECMS_Ryder
{
    static class Program
    { 
        public static int TrailDays = 0;

        [STAThread]
        static void Main()
        {
            try
            {
                if (ApplicationIsRunning() == false)
                {
                    Check_Validation();
                    
                    clsDBConnection.GetDBConnection();
                    clsDBConnection.CheckDatabaseSize();

                    string strLoginName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
                    PrincipalContext context = new PrincipalContext(ContextType.Domain, Environment.UserDomainName);
                    UserPrincipal userPrincipal = UserPrincipal.FindByIdentity(context, strLoginName);
                    string strUserName = userPrincipal.Name;
                    strLoginName = Environment.UserName.ToUpper();
                    UserDetails user = null;

                    UserDetailsRepository userDetailsRepository = new UserDetailsRepository(clsDBConnection.strConnectionString);
                    Boolean isUserExists = userDetailsRepository.CheckUserExists(strLoginName);

                    if (clsDBConnection.strErrorMsg == "")
                    {
                        if (isUserExists == false)
                        {
                            user = new UserDetails();
                            user.UID = strLoginName;
                            user.UserName = strUserName;
                            user.Role = UserRole.Associate.ToString();
                            user.IsActive = UserStatus.Active.ToString();
                            user.EntryUser = "System";
                            user.EntryDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                            clsDBConnection.strLoggedInUID = "System";
                            userDetailsRepository.RegisterUser(user);
                        }

                        user = userDetailsRepository.GetUserByUID(strLoginName);
                        
                        if (user.IsActive == "InActive")
                        {
                            MessageBox.Show("User is deactivated in database.Contact to supervisor to activate it again.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            Environment.Exit(Environment.ExitCode);
                        }
                        else
                        {
                            clsDBConnection.strLoggedInUID = user.UID;
                            clsDBConnection.strLoggedInUserName = user.UserName;
                            clsDBConnection.strLoggedInUserRole = user.Role.ToString();

                            Application.EnableVisualStyles();
                            Application.SetCompatibleTextRenderingDefault(false);
                            Application.Run(new frmMDI());
                        }                        
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in main:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Check the license validation of this tool
        /// </summary>
        static void Check_Validation()
        {
            System.Globalization.DateTimeFormatInfo dtfi = System.Globalization.CultureInfo.CreateSpecificCulture("en-US").DateTimeFormat;

            string LicenseStartDate = "01-Aug-2024";
            DateTime dt = DateTime.Parse(LicenseStartDate);

            dtfi.ShortDatePattern = "dd-MMM-yyyy";
            string stringDate = dt.ToString(dtfi.ShortDatePattern, dtfi);

            DateTime expiryDate = DateTime.Parse(stringDate).AddDays(365);

            bool expired = false;
            if (DateTime.Today > expiryDate)
            {
                expired = true;
            }
            else
            {
                TrailDays = Convert.ToInt32((expiryDate - DateTime.Today).TotalDays);
            }

            if (expired)
            {
                MessageBox.Show("Your ECMS tool license is expired.\n\nPlease contact to WFM Automation Team for renewal.", "ECMS Tool - Ryder - License Expired", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Environment.Exit(Environment.ExitCode);
            }

            if (TrailDays <= 15)
            {
                MessageBox.Show("Your ECMS tool license will expire in " + TrailDays + " days. \n\nPlease inform WFM Automation Team for renewal.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    
        static Boolean ApplicationIsRunning()
        {
            if (System.Diagnostics.Process.GetProcessesByName(System.IO.Path.GetFileNameWithoutExtension(System.Reflection.Assembly.GetEntryAssembly().Location)).Count() > 1)
            {
                MessageBox.Show("An instance of ECMS Tool is already running.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return true;
            }
            else
            {
                return false;
            }

            //Mutex mutex = new System.Threading.Mutex(false, "MyUniqueMutexName");
            //try
            //{
            //    if (mutex.WaitOne(0, false))
            //    {
            //        return false;
            //    }
            //    else
            //    {
            //        MessageBox.Show("An instance of ECMS Tool is already running.");
            //        return true;
            //    }
            //}
            //finally
            //{
            //    if (mutex != null)
            //    {
            //        mutex.Close();
            //        mutex = null;
            //    }
            //}
        }
    }
}
