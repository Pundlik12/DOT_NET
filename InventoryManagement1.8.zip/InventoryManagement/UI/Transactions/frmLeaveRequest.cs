﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;
using InventoryManagement.DataAccessLogic;

namespace InventoryManagement.UI
{
    public partial class frmLeaveRequest : Form
    {
        IGenericRepository<LeaveRequestModel> objLeaveRequestDal = null;
        IGenericRepository<EmployeeModel> objEmployeeDal = null;
        
        public frmLeaveRequest()
        {
            InitializeComponent();
        }

        private void frmBillList_Load(object sender, EventArgs e)
        {
            objLeaveRequestDal = new LeaveRequestDAL();
            objEmployeeDal = new EmployeeDAL();

            List<EmployeeModel> empList = objEmployeeDal.GetAll();
            
            cboEmployee.DataSource = empList;
            cboEmployee.DisplayMember = "EmployeeName";
            cboEmployee.ValueMember = "EmployeeID";
            
            clearfields();
        }

        private void clearfields()
        {
            cboEmployee.SelectedIndex = -1;
            cboLeaveType.SelectedIndex = 0;
            dtpFromDate.Value = DateTime.Now;
            dtpTodate.Value = DateTime.Now;
            txtReason.Text = "";
            cboEmployee.Focus();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (cboEmployee.SelectedIndex == -1)
            {
                cboEmployee.Focus();
                MessageBox.Show("Please select employee.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if(cboLeaveType.SelectedIndex == 0)
            {
                cboLeaveType.Focus();
                MessageBox.Show("Please select leave type.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (dtpTodate.Value < dtpFromDate.Value)
            {
                dtpTodate.Focus();
                MessageBox.Show("To date can be less than from date.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if(txtReason.Text == "")
            {
                txtReason.Focus();
                MessageBox.Show("Please enter reason.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                LeaveRequestModel objLeaveRequest = new LeaveRequestModel();
                objLeaveRequest.EmployeeID = Convert.ToString(cboEmployee.SelectedValue);
                objLeaveRequest.LeaveType = cboLeaveType.Text;
                objLeaveRequest.StartDate = dtpFromDate.Text;
                objLeaveRequest.EndDate = dtpTodate.Text;
                objLeaveRequest.Reason = txtReason.Text.Trim();
                objLeaveRequest.Status = "Pending";
                objLeaveRequest.CreatedBy = common.strUserEmail;

                objLeaveRequestDal.Add(objLeaveRequest);
                clearfields();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            clearfields();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
