﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Security.Cryptography;

namespace HBAccessTool
{
    public class clsCommon
    {
        public static string strProjectTitle = ConfigurationManager.AppSettings["ProjectName"].ToString();

        public static void CheckApplicationIsRunning(string strApplicationName)
        {
            System.Threading.Mutex mutex = new System.Threading.Mutex(true, strApplicationName, out bool flag);

            if (!flag)
            {
                MessageBox.Show("Application is already running.", strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Environment.Exit(1);
            }
        }

        public static void CheckLicense()
        {
            string strLicenseDate = System.Configuration.ConfigurationManager.AppSettings["LDate"].ToString();
            var key = System.Configuration.ConfigurationManager.AppSettings["Key"].ToString();
            strLicenseDate = clsCommon.DecryptString(key, strLicenseDate);

            try
            {
                DateTime.Parse(strLicenseDate);
            }
            catch (Exception)
            {
                MessageBox.Show($"Invalid Expiry Date.", strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Environment.Exit(Environment.ExitCode);
            }

            Int32 strAlertDays = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["AlertDaysBefore"].ToString());

            DateTime enDate = DateTime.Parse(strLicenseDate);
            DateTime today = DateTime.Today;
            double daysremain = (enDate - today).TotalDays;

            if (daysremain <= strAlertDays && daysremain >= 0)
            {
                MessageBox.Show($"Your software license will expire in {daysremain} Days.", strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            if (enDate < DateTime.Today)
            {
                MessageBox.Show("Your software license is expired." + Environment.NewLine + Environment.NewLine + "Please Contact to Administrator/WFM Team.", strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Environment.Exit(Environment.ExitCode);
            }
        }

        public static void WriteLog(string textToWrite)
	    {
		    string strFilePath = System.AppDomain.CurrentDomain.BaseDirectory + @"Log\";
            if (System.IO.Directory.Exists(strFilePath) == false)
            {
                System.IO.Directory.CreateDirectory(strFilePath);
            }

            using (StreamWriter sw = new StreamWriter(strFilePath + @"\Log.txt", true))
            {
                sw.WriteLine(textToWrite);
                sw.WriteLine("==================================================== " + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));
            }
        }

        public static string EncryptString(string key, string plainText)
        {
            try
            {
                byte[] iv = new byte[16];
                byte[] array;

                using (Aes aes = Aes.Create())
                {
                    aes.Key = Encoding.UTF8.GetBytes(key);
                    aes.IV = iv;

                    ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                    using (MemoryStream memoryStream = new MemoryStream())
                    {
                        using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, encryptor, CryptoStreamMode.Write))
                        {
                            using (StreamWriter streamWriter = new StreamWriter((Stream)cryptoStream))
                            {
                                streamWriter.Write(plainText);
                            }

                            array = memoryStream.ToArray();
                        }
                    }
                }

                return Convert.ToBase64String(array);
            }
            catch (Exception)
            {
                return "";
            }
        }

        public static string DecryptString(string key, string cipherText)
        {
            try
            {
                byte[] iv = new byte[16];
                byte[] buffer = Convert.FromBase64String(cipherText);

                using (Aes aes = Aes.Create())
                {
                    aes.Key = Encoding.UTF8.GetBytes(key);
                    aes.IV = iv;
                    ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                    using (MemoryStream memoryStream = new MemoryStream(buffer))
                    {
                        using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, decryptor, CryptoStreamMode.Read))
                        {
                            using (StreamReader streamReader = new StreamReader((Stream)cryptoStream))
                            {
                                return streamReader.ReadToEnd();
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                return "";
            }
        }
    }

    public static class FileSizeFormatter
    {
        static readonly string[] suffixes = { "Bytes", "KB", "MB", "GB", "TB" };
        
        public static string GetFileSize(string strFilePath)
        {
            System.IO.FileInfo fi = new System.IO.FileInfo(strFilePath);
            return FormatSize(fi.Length);
        }

        private static string FormatSize(long bytes)
        {
            int counter = 0;
            decimal number = (decimal)bytes;

            while (System.Math.Round(number / 1024) >= 1)
            {
                number = number / 1024;
                counter++;
            }

            return string.Format("{0} {1}", System.Math.Round(number, 2), suffixes[counter]);
        }
    }
}
