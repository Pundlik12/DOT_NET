﻿
namespace InventoryManagement.BusinessLogic
{
    public class NotificationModel
    {
        public string NotificationID { get; set; }
        public string EmployeeID { get; set; }
        public string Meassage { get; set; }
        public string Status { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDateTime { get; set; }
    }
}
