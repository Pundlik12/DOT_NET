﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;

namespace InventoryManagement.DataAccessLogic
{
    public class CompanyDAL : IGenericRepository<CompanyModel>
    {
        public CompanyDAL()
        {
            DatabaseContext.CreateConnection();
        }

        public List<CompanyModel> GetAll()
        {
            List<CompanyModel> lstData = new List<CompanyModel>();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT Code,Name,Address,PinCode,City,State,Mobile,Email,GSTNo,CreatedBy,CreatedDateTime FROM tblCompany";
                
                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    CompanyModel objCompany = new CompanyModel();
                    objCompany.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objCompany.Name = Convert.ToString(DatabaseContext.dbdr["Name"]);
                    objCompany.Address = Convert.ToString(DatabaseContext.dbdr["Address"]);
                    objCompany.PinCode = Convert.ToString(DatabaseContext.dbdr["PinCode"]);
                    objCompany.City = Convert.ToString(DatabaseContext.dbdr["City"]);
                    objCompany.State = Convert.ToString(DatabaseContext.dbdr["State"]);
                    objCompany.Mobile = Convert.ToString(DatabaseContext.dbdr["Mobile"]);
                    objCompany.Email = Convert.ToString(DatabaseContext.dbdr["Email"]);
                    objCompany.GSTNo = Convert.ToString(DatabaseContext.dbdr["GSTNo"]);
                    objCompany.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objCompany.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objCompany);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public List<CompanyModel> GetByDates(string strFromDate, string strToDate)
        {
            List<CompanyModel> lstData = new List<CompanyModel>();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT Code,Name,Address,PinCode,City,State,Mobile,Email,GSTNo,CreatedBy,CreatedDateTime FROM tblCompany";

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();

                while (DatabaseContext.dbdr.Read())
                {
                    CompanyModel objCompany = new CompanyModel();
                    objCompany.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objCompany.Name = Convert.ToString(DatabaseContext.dbdr["Name"]);
                    objCompany.Address = Convert.ToString(DatabaseContext.dbdr["Address"]);
                    objCompany.PinCode = Convert.ToString(DatabaseContext.dbdr["PinCode"]);
                    objCompany.City = Convert.ToString(DatabaseContext.dbdr["City"]);
                    objCompany.State = Convert.ToString(DatabaseContext.dbdr["State"]);
                    objCompany.Mobile = Convert.ToString(DatabaseContext.dbdr["Mobile"]);
                    objCompany.Email = Convert.ToString(DatabaseContext.dbdr["Email"]);
                    objCompany.GSTNo = Convert.ToString(DatabaseContext.dbdr["GSTNo"]);
                    objCompany.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objCompany.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objCompany);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public CompanyModel GetByID(Int32 CompanyCode)
        {
            CompanyModel objCompany = new CompanyModel();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT Code,Name,Address,PinCode,City,State,Mobile,Email,GSTNo,CreatedBy,CreatedDateTime FROM tblCompany WHERE Code = " + CompanyCode;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    objCompany.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objCompany.Name = Convert.ToString(DatabaseContext.dbdr["Name"]);
                    objCompany.Address = Convert.ToString(DatabaseContext.dbdr["Address"]);
                    objCompany.PinCode = Convert.ToString(DatabaseContext.dbdr["PinCode"]);
                    objCompany.City = Convert.ToString(DatabaseContext.dbdr["City"]);
                    objCompany.State = Convert.ToString(DatabaseContext.dbdr["State"]);
                    objCompany.Mobile = Convert.ToString(DatabaseContext.dbdr["Mobile"]);
                    objCompany.Email = Convert.ToString(DatabaseContext.dbdr["Email"]);
                    objCompany.GSTNo = Convert.ToString(DatabaseContext.dbdr["GSTNo"]);
                    objCompany.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objCompany.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return objCompany;
        }

        public void Add(CompanyModel objCompany)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "INSERT INTO tblCompany (Name,Address,PinCode,City,State,Mobile,Email,GSTNo,CreatedBy,CreatedDateTime) VALUES(@Name,@Address,@PinCode,@City,@State,@Mobile,@Email,@GSTNo,@CreatedBy,@CreatedDateTime)";
                
                DatabaseContext.dbcmd.Parameters.AddWithValue("Name", objCompany.Name);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Address", objCompany.Address);
                DatabaseContext.dbcmd.Parameters.AddWithValue("PinCode", objCompany.PinCode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("City", objCompany.City);
                DatabaseContext.dbcmd.Parameters.AddWithValue("State", objCompany.State);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Mobile", objCompany.Mobile);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Email", objCompany.Email);
                DatabaseContext.dbcmd.Parameters.AddWithValue("GSTNo", objCompany.GSTNo);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objCompany.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Update(CompanyModel objCompany)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "UPDATE tblCompany SET Name = @Name,Address = @Address,PinCode = @PinCode,City = @City,State = @State,Mobile = @Mobile,Email = @Email,GSTNo = @GSTNo, CreatedBy = @CreatedBy,CreatedDateTime = @CreatedDateTime WHERE Code = " + objCompany.Code;

                DatabaseContext.dbcmd.Parameters.AddWithValue("Name", objCompany.Name);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Address", objCompany.Address);
                DatabaseContext.dbcmd.Parameters.AddWithValue("PinCode", objCompany.PinCode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("City", objCompany.City);
                DatabaseContext.dbcmd.Parameters.AddWithValue("State", objCompany.State);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Mobile", objCompany.Mobile);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Email", objCompany.Email);
                DatabaseContext.dbcmd.Parameters.AddWithValue("GSTNo", objCompany.GSTNo);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objCompany.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Delete(Int32 CompanyCode)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "DELETE FROM tblCompany WHERE Code = " + CompanyCode;
                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
