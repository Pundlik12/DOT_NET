﻿using System.Net.Sockets;
using System.Text;

namespace ChatApp
{
    public class ChatClient
    {
        public string serverIp;
        public string UserName;
        private int port;

        public ChatClient(string ip, int port)
        {
            serverIp = ip;
            this.port = port;
        }

        public bool SendMessage(string message)
        {
            try
            {
                using var client = new TcpClient(serverIp, port);
                using var stream = client.GetStream();
                byte[] data = Encoding.UTF8.GetBytes("MSG:" + UserName + ": " + message);
                stream.Write(data, 0, data.Length);
                return true;
            }
            catch (Exception Err)
            {
                MessageBox.Show("Error in send message:- " + Err.Message, "IP Messeger", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
        }

        public bool SendFile(string filePath)
        {
            try
            {
                using var client = new TcpClient(serverIp, port);
                using var stream = client.GetStream();
                byte[] header = Encoding.UTF8.GetBytes("FILE:" + UserName + ": " + Path.GetFileName(filePath) + "|");
                stream.Write(header, 0, header.Length);

                byte[] fileData = File.ReadAllBytes(filePath);
                stream.Write(fileData, 0, fileData.Length);

                return true;
            }
            catch (Exception Err)
            {
                MessageBox.Show("Error in send file:- " + Err.Message, "IP Messeger", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
        }
    }
}
