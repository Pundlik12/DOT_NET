﻿using System;

namespace HBAccessTool
{
    public class TransactionModel
    {
        public int TransactionID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public string MobileNumber { get; set; }
        public DateTime StartDatetime { get; set; }
        public int EntryID { get; set; }
        public DateTime EntryDateTime { get; set; }
    }
}
