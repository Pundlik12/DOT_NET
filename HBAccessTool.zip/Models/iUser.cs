﻿using System.Collections.Generic;

namespace HBAccessTool
{
    public interface iUser
    {
        List<UserModel> GetAllUsers();
        UserModel GetUserByID(int UserId);
        int AddUser(UserModel UM);
        int UpdateUser(UserModel UM);
        int DeleteUser(int UserId);
    }
}
