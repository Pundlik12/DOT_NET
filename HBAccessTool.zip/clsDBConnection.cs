﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HBAccessTool
{
    public class clsDBConnection
    {
        public static string strConstr = "";
        public static int intLoginUserID = 0;
        public static string strLoginUserUID = "";
        public static string strLoginUserName = "";
        public static string strLoginUserRole = "";
        public static string strStartTime = "";
        public static string strEndTime = "";

        public static void GetDBConnection()
        {
            if (System.IO.File.Exists(ConfigurationManager.AppSettings["DataSource"].ToString()))
            {
                strConstr = "Provider={0}; Data Source= {1};JET OLEDB:Database Password={2}";
                strConstr = string.Format(strConstr, ConfigurationManager.AppSettings["Provider"].ToString(), ConfigurationManager.AppSettings["DataSource"].ToString(), ConfigurationManager.AppSettings["PD"].ToString());
            }
            else
            {
                MessageBox.Show("Database path is not configured or not accessible.", "clsDBConnection", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Environment.Exit(Environment.ExitCode);
            }
        }
    }
}
