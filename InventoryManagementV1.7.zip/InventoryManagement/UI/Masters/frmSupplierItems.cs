﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;
using InventoryManagement.DataAccessLogic;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace InventoryManagement
{
    public partial class frmSupplierItems : Form
    {
        string strSupplierItemCode = "";
        SupplierItemModel objSupplierItem = null;
        IGenericRepository<SupplierItemModel> objSupplierItemDal = null;

        public frmSupplierItems(string strSupplierCode, string strSupplierName)
        {
            InitializeComponent();
            
            lblSupplierCode.Text = strSupplierCode;
            lblSupplierName.Text = strSupplierName;
        }

        private void frmCustomerItems_Load(object sender, EventArgs e)
        {
            objSupplierItemDal = new SupplierItemDAL();

            DisplayData();
            ClearFields();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtItemName.Text.Trim() == "")
            {
                txtItemName.Focus();
                MessageBox.Show("Please enter item name.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtHSNNumber.Text.Trim() == "")
            {
                txtHSNNumber.Focus();
                MessageBox.Show("Please enter HSN Number.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtRate.Text.Trim() == "")
            {
                txtRate.Focus();
                MessageBox.Show("Please enter rate.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                Boolean isValidRate = false;
                try
                {
                    Convert.ToDouble(txtRate.Text.Trim());
                    isValidRate = true;
                }
                catch (Exception)
                {
                    isValidRate = false;
                    txtRate.Select();
                    MessageBox.Show("Rate should be numeric.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }

                if (isValidRate == true)
                {
                    Cursor = Cursors.WaitCursor;
                    objSupplierItem = new SupplierItemModel();
                    objSupplierItem.SupplierCode = Convert.ToInt32(lblSupplierCode.Text);
                    objSupplierItem.Name = txtItemName.Text.Trim();
                    objSupplierItem.HSNNumber = txtHSNNumber.Text.Trim();
                    objSupplierItem.Rate = txtRate.Text.Trim();
                    objSupplierItem.CreatedBy = common.strUserEmail;

                    if (btnSave.Text == "Save")
                    {
                        objSupplierItemDal.Add(objSupplierItem);
                        ClearFields();
                        //MessageBox.Show("Customer Item saved successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        objSupplierItem.Code = Convert.ToInt32(strSupplierItemCode);
                        objSupplierItemDal.Update(objSupplierItem);
                        ClearFields();
                        //MessageBox.Show("Customer Item updated successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    Cursor = Cursors.Default;
                }
            }
        }

        private void ClearFields()
        {
            strSupplierItemCode = "";
            txtItemName.Text = "";
            txtHSNNumber.Text = "";
            txtRate.Text = "";
            btnSave.Text = "Save";
            dgvData.Enabled = true;
            DisplayData();
            txtItemName.Focus();
        }

        private void DisplayData()
        {
            List<SupplierItemModel> lstAllCustomerItems = objSupplierItemDal.GetAll();
            List<SupplierItemModel> lstCustomerItems = lstAllCustomerItems.Where(x=> x.SupplierCode.ToString() == lblSupplierCode.Text).ToList();
            
            dgvData.DataSource = lstCustomerItems;
        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (e.ColumnIndex == 0)
                {
                    strSupplierItemCode = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Code"].Value);
                    txtItemName.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["ItemName"].Value);
                    txtHSNNumber.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["HSNNumber"].Value);
                    txtRate.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Rate"].Value);
                    
                    btnSave.Text = "Update";
                    dgvData.Enabled = false;
                    txtItemName.Select();
                }
                if (e.ColumnIndex == 1)
                {
                    if (MessageBox.Show("Do you want to delete?", common.strProjectTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        Int32 code = Convert.ToInt32(dgvData.Rows[e.RowIndex].Cells["Code"].Value);
                        objSupplierItemDal.Delete(code);

                        ClearFields();
                        //MessageBox.Show("Supplier Item deleted successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
