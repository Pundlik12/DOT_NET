﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;

namespace InventoryManagement.DataAccessLogic
{
    public class AttendanceDAL : IGenericRepository<AttendanceModel>
    {
        public AttendanceDAL()
        {
            DatabaseContext.CreateConnection();
        }

        public List<AttendanceModel> GetAll()
        {
            List<AttendanceModel> lstData = new List<AttendanceModel>();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT AttendanceID,EmployeeID,AttendanceDate,CheckIn,CheckOut,Status,CreatedBy,CreatedDateTime FROM Attendance WHERE AttendanceDate >= CDATE('01-" + DateTime.Now.ToString("MMM-yyyy") + "')";
                
                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    AttendanceModel objAttendance = new AttendanceModel();
                    objAttendance.AttendanceID = Convert.ToString(DatabaseContext.dbdr["AttendanceID"]);
                    objAttendance.EmployeeID = Convert.ToString(DatabaseContext.dbdr["EmployeeID"]);
                    objAttendance.AttendanceDate = Convert.ToString(DatabaseContext.dbdr["AttendanceDate"]);
                    objAttendance.CheckIn = Convert.ToString(DatabaseContext.dbdr["CheckIn"]);
                    objAttendance.CheckOut = Convert.ToString(DatabaseContext.dbdr["CheckOut"]);
                    objAttendance.Status = Convert.ToString(DatabaseContext.dbdr["Status"]);
                    objAttendance.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objAttendance.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objAttendance);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public List<AttendanceModel> GetByDates(string strFromDate, string strToDate)
        {
            throw new NotImplementedException();
        }

        public AttendanceModel GetByID(Int32 AttendanceID)
        {
            AttendanceModel objAttendance = new AttendanceModel();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT AttendanceID,EmployeeID,AttendanceDate,CheckIn,CheckOut,Status,CreatedBy,CreatedDateTime FROM Attendance WHERE AttendanceID = " + AttendanceID;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    objAttendance.AttendanceID = Convert.ToString(DatabaseContext.dbdr["AttendanceID"]);
                    objAttendance.EmployeeID = Convert.ToString(DatabaseContext.dbdr["EmployeeID"]);
                    objAttendance.AttendanceDate = Convert.ToString(DatabaseContext.dbdr["AttendanceDate"]);
                    objAttendance.CheckIn = Convert.ToString(DatabaseContext.dbdr["CheckIn"]);
                    objAttendance.CheckOut = Convert.ToString(DatabaseContext.dbdr["CheckOut"]);
                    objAttendance.Status = Convert.ToString(DatabaseContext.dbdr["Status"]);
                    objAttendance.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objAttendance.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return objAttendance;
        }

        public void Add(AttendanceModel objAttendance)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "INSERT INTO Attendance (EmployeeID,AttendanceDate,CheckIn,CheckOut,Status,CreatedBy,CreatedDateTime) VALUES(@EmployeeID,@AttendanceDate,@CheckIn,@CheckOut,@Status,@CreatedBy,@CreatedDateTime)";
                
                DatabaseContext.dbcmd.Parameters.AddWithValue("EmployeeID", Convert.ToInt32(objAttendance.EmployeeID));
                DatabaseContext.dbcmd.Parameters.AddWithValue("AttendanceDate", objAttendance.AttendanceDate);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CheckIn", objAttendance.CheckIn);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CheckOut", "");
                DatabaseContext.dbcmd.Parameters.AddWithValue("Status", objAttendance.Status);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objAttendance.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Update(AttendanceModel objAttendance)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "UPDATE Attendance SET CheckOut = @CheckOut WHERE EmployeeID = @EmployeeID AND AttendanceDate = CDATE(@AttendanceDate)";

                DatabaseContext.dbcmd.Parameters.AddWithValue("CheckOut", objAttendance.CheckOut);
                DatabaseContext.dbcmd.Parameters.AddWithValue("EmployeeID", objAttendance.EmployeeID);
                DatabaseContext.dbcmd.Parameters.AddWithValue("AttendanceDate", objAttendance.AttendanceDate);
                
                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Delete(Int32 AttendanceID)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "DELETE FROM Attendance WHERE AttendanceID = " + AttendanceID;
                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
