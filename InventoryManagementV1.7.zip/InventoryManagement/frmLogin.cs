﻿using System;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;
using InventoryManagement.DataAccessLogic;

namespace InventoryManagement
{
    public partial class frmLogin : Form
    {
        UserModel objUserModel = null;
        AuthDAL objAuthDAL = null;

        public frmLogin()
        {
            InitializeComponent();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            objAuthDAL = new AuthDAL();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtEmailID.Text.Trim() == "")
            {
                txtEmailID.Focus();
                MessageBox.Show("Please enter email.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtPassword.Text.Trim() == "")
            {
                txtPassword.Focus();
                MessageBox.Show("Please enter password.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                Cursor = Cursors.WaitCursor;
                
                string strPasswordHash = common.EncryptString(common.strKey, txtPassword.Text.Trim());
                objUserModel = objAuthDAL.ValidateUser(txtEmailID.Text.Trim(), strPasswordHash);
                
                if (objUserModel.Email != null)
                {
                    common.strUserCode = Convert.ToString(objUserModel.Code);
                    common.strUserEmail = objUserModel.Email;
                    common.strUserRole = objUserModel.Role;
                    common.strCompanyCode = objUserModel.CompanyCode;
                    this.Hide();
                    frmMDIForm objfrm = new frmMDIForm();
                    objfrm.Show();
                }
                else
                {
                    txtPassword.Focus();
                    MessageBox.Show("Incorrect user name or password. Please try again.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                Cursor = Cursors.Default;
            }            
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
