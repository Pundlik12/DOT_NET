﻿using System.Net;


namespace ChatApp
{
    public class NetworkInfo
    {
        public static string GetHostDetails()
        {
            // Get local machine name
            string hostName = Dns.GetHostName();
            Console.WriteLine($"Hostname: {hostName}");

            // Get IP addresses associated with the hostname
            IPAddress[] addresses = Dns.GetHostAddresses(hostName);

            foreach (IPAddress ip in addresses)
            {
                // Filter out IPv6 and loopback addresses
                if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork && !IPAddress.IsLoopback(ip))
                {
                    Console.WriteLine($"IP Address: {ip}");
                    return hostName + " | " + ip.ToString();
                }
            }

            return string.Empty;
        }
    }

}
