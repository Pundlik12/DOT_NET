﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;

namespace InventoryManagement.DataAccessLogic
{
    public class EmployeeDAL : IGenericRepository<EmployeeModel>
    {
        public EmployeeDAL()
        {
            DatabaseContext.CreateConnection();
        }

        public List<EmployeeModel> GetAll()
        {
            List<EmployeeModel> lstData = new List<EmployeeModel>();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT EmployeeID,Name,Email,Phone,Department,Designation,JoinDate,Salary,Status,CreatedBy,CreatedDateTime FROM Employees";
                
                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    EmployeeModel objEmployee = new EmployeeModel();
                    objEmployee.EmployeeID = Convert.ToString(DatabaseContext.dbdr["EmployeeID"]);
                    objEmployee.EmployeeName = Convert.ToString(DatabaseContext.dbdr["Name"]);
                    objEmployee.Email = Convert.ToString(DatabaseContext.dbdr["Email"]);
                    objEmployee.Phone = Convert.ToString(DatabaseContext.dbdr["Phone"]);
                    objEmployee.Department = Convert.ToString(DatabaseContext.dbdr["Department"]);
                    objEmployee.Designation = Convert.ToString(DatabaseContext.dbdr["Designation"]);
                    objEmployee.JoinDate = Convert.ToString(DatabaseContext.dbdr["JoinDate"]);
                    objEmployee.Salary = Convert.ToString(DatabaseContext.dbdr["Salary"]);
                    objEmployee.Status = Convert.ToString(DatabaseContext.dbdr["Status"]);
                    objEmployee.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objEmployee.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objEmployee);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public List<EmployeeModel> GetByDates(string strFromDate, string strToDate)
        {
            throw new NotImplementedException();
        }

        public EmployeeModel GetByID(Int32 EmployeeID)
        {
            EmployeeModel objEmployee = new EmployeeModel();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT EmployeeID,Name,Email,Phone,Department,Designation,JoinDate,Salary,Status,CreatedBy,CreatedDateTime FROM Employees WHERE EmployeeID = " + EmployeeID;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    objEmployee.EmployeeID = Convert.ToString(DatabaseContext.dbdr["EmployeeID"]);
                    objEmployee.EmployeeName = Convert.ToString(DatabaseContext.dbdr["Name"]);
                    objEmployee.Email = Convert.ToString(DatabaseContext.dbdr["Email "]);
                    objEmployee.Phone = Convert.ToString(DatabaseContext.dbdr["Phone"]);
                    objEmployee.Department = Convert.ToString(DatabaseContext.dbdr["Department"]);
                    objEmployee.Designation = Convert.ToString(DatabaseContext.dbdr["Designation"]);
                    objEmployee.JoinDate = Convert.ToString(DatabaseContext.dbdr["JoinDate"]);
                    objEmployee.Salary = Convert.ToString(DatabaseContext.dbdr["Salary"]);
                    objEmployee.Status = Convert.ToString(DatabaseContext.dbdr["Status"]);
                    objEmployee.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objEmployee.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return objEmployee;
        }

        public void Add(EmployeeModel objEmployee)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "INSERT INTO Employees (Name,Email,Phone,Department,Designation,JoinDate,Salary,Status,CreatedBy,CreatedDateTime) VALUES(@Name,@Email,@Phone,@Department,@Designation,@JoinDate,@Salary,@Status,@CreatedBy,@CreatedDateTime)";
                
                DatabaseContext.dbcmd.Parameters.AddWithValue("Name", objEmployee.EmployeeName);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Email", objEmployee.Email);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Phone", objEmployee.Phone);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Department", objEmployee.Department);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Designation", objEmployee.Designation);
                DatabaseContext.dbcmd.Parameters.AddWithValue("JoinDate", objEmployee.JoinDate);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Salary", objEmployee.Salary);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Status", objEmployee.Status);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objEmployee.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Update(EmployeeModel objEmployee)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "UPDATE Employees SET Name = @Name,Email = @Email,Phone = @Phone,Department = @Department,Designation = @Designation,JoinDate = @JoinDate,Salary = @Salary,Status = @Status, CreatedBy = @CreatedBy, CreatedDateTime = @CreatedDateTime WHERE EmployeeID = " + objEmployee.EmployeeID;

                DatabaseContext.dbcmd.Parameters.AddWithValue("Name", objEmployee.EmployeeName);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Email", objEmployee.Email);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Phone", objEmployee.Phone);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Department", objEmployee.Department);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Designation", objEmployee.Designation);
                DatabaseContext.dbcmd.Parameters.AddWithValue("JoinDate", objEmployee.JoinDate);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Salary", objEmployee.Salary);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Status", objEmployee.Status);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objEmployee.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Delete(Int32 EmployeeID)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "DELETE FROM Employees WHERE EmployeeID = " + EmployeeID;
                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
