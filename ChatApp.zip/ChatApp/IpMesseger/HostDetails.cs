﻿
namespace ChatApp
{
    public class HostDetails
    {
        public string? GUID { get; set; }
        public string? UserName { get; set; }
        public string? IPAddress { get; set; }
        public string? HostName { get; set; }         
    }
}