﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace HBAccessTool
{
    public class TransactionRepository : iTransactions,IDisposable
    {
        OleDbConnection dbcon = null;
        OleDbCommand dbcmd = null;
        OleDbDataReader dbdr = null;
        
        List<TransactionModel> lstTransaction = null;
        TransactionModel objTM = null;

        public bool CreateTables()
        {
            Boolean isSucess = false;
            try
            {
                string tblTransaction = "CREATE TABLE tblTransaction ";
                tblTransaction = tblTransaction + "(TransactionID AUTOINCREMENT PRIMARY KEY,";
                tblTransaction = tblTransaction + "FirstName Varchar(100) NULL,";
                tblTransaction = tblTransaction + "LastName Varchar(100) NULL,";
                tblTransaction = tblTransaction + "EmailAddress Varchar(100) NULL,";
                tblTransaction = tblTransaction + "MobileNumber Varchar(50),";
                tblTransaction = tblTransaction + "StartDatetime DATETIME,";
                tblTransaction = tblTransaction + "EntryID INTEGER,";
                tblTransaction = tblTransaction + "EntryDatetime DATETIME);";

                string[] arrTables = { tblTransaction };

                foreach (string strTable in arrTables)
                {
                    try
                    {
                        using (OleDbConnection OleDbcon = new OleDbConnection(clsDBConnection.strConstr))
                        {
                            OleDbCommand cmd = new OleDbCommand();
                            cmd.Connection = OleDbcon;

                            cmd.CommandText = strTable;
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandTimeout = 0;

                            OleDbcon.Open();
                            cmd.ExecuteNonQuery();
                            OleDbcon.Close();
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                    }
                }

                isSucess = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                isSucess = false;
            }

            return isSucess;
        }

        public bool DROPTables()
        {
            Boolean isSucess = false;
            try
            {
                string tblTransaction = "DROP TABLE tblTransaction";
                string[] arrTables = { tblTransaction };

                foreach (string strTable in arrTables)
                {
                    try
                    {
                        using (OleDbConnection OleDbcon = new OleDbConnection(clsDBConnection.strConstr))
                        {
                            OleDbCommand cmd = new OleDbCommand();
                            cmd.Connection = OleDbcon;

                            cmd.CommandText = strTable;
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandTimeout = 0;

                            OleDbcon.Open();
                            cmd.ExecuteNonQuery();
                            OleDbcon.Close();
                        }
                    }
                    catch (Exception)
                    {
                    }
                }

                isSucess = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                isSucess = false;
            }

            return isSucess;
        }

        public List<TransactionModel> GetAllTransactions()
        {
            try
            {
                using (dbcon = new OleDbConnection())
                {
                    dbcon.ConnectionString = clsDBConnection.strConstr;
                    using (dbcmd = new OleDbCommand())
                    {
                        dbcon.Open();
                        dbcmd.Connection = dbcon;
                        dbcmd.CommandType = System.Data.CommandType.Text;
                        dbcmd.CommandText = "SELECT * FROM tblTransaction";
                        dbcmd.CommandTimeout = 0;
                        dbdr = dbcmd.ExecuteReader();

                        lstTransaction = new List<TransactionModel>();
                        while (dbdr.Read())
                        {
                            objTM = new TransactionModel();
                            objTM.TransactionID = Convert.ToInt32(dbdr["TransactionID"]);
                            objTM.FirstName = Convert.ToString(dbdr["FirstName"]);
                            objTM.LastName = Convert.ToString(dbdr["LastName"]);
                            objTM.EmailAddress = Convert.ToString(dbdr["EmailAddress"]);
                            objTM.MobileNumber = Convert.ToString(dbdr["MobileNumber"]);
                            objTM.StartDatetime = Convert.ToDateTime(dbdr["StartDatetime"]);
                            objTM.EntryID = Convert.ToInt32(dbdr["EntryID"]);
                            objTM.EntryDateTime = Convert.ToDateTime(DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                            lstTransaction.Add(objTM);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                lstTransaction = null;
                MessageBox.Show(ex.ToString(),"GetAllTransactions",MessageBoxButtons.OK,MessageBoxIcon.Stop);
            }
            
            return lstTransaction;
        }

        public TransactionModel GetTransactionByID(int TransactionId)
        {
            try
            {
                using (dbcon = new OleDbConnection())
                {
                    dbcon.ConnectionString = clsDBConnection.strConstr;
                    using (dbcmd = new OleDbCommand())
                    {
                        dbcon.Open();
                        dbcmd.Connection = dbcon;
                        dbcmd.CommandType = System.Data.CommandType.Text;
                        dbcmd.CommandText = "SELECT * FROM tblTransaction WHERE TransactionId = " + TransactionId;
                        dbcmd.CommandTimeout = 0;
                        dbdr = dbcmd.ExecuteReader();

                        lstTransaction = new List<TransactionModel>();
                        while (dbdr.Read())
                        {
                            objTM = new TransactionModel();
                            objTM.TransactionID = Convert.ToInt32(dbdr["TransactionID"]);
                            objTM.FirstName = Convert.ToString(dbdr["FirstName"]);
                            objTM.LastName = Convert.ToString(dbdr["LastName"]);
                            objTM.EmailAddress = Convert.ToString(dbdr["EmailAddress"]);
                            objTM.MobileNumber = Convert.ToString(dbdr["MobileNumber"]);
                            objTM.StartDatetime = Convert.ToDateTime(dbdr["StartDatetime"]);
                            objTM.EntryID = Convert.ToInt32(dbdr["EntryID"]);
                            objTM.EntryDateTime = Convert.ToDateTime(DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                            lstTransaction.Add(objTM);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                objTM = null;
                MessageBox.Show(ex.ToString(), "GetTransactionByID", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            
            return objTM;
        }

        public int AddTransaction(TransactionModel UM)
        {
            int NoOfRowsAffected = 0;
            try
            {
                using (dbcon = new OleDbConnection())
                {
                    dbcon.ConnectionString = clsDBConnection.strConstr;
                    using (dbcmd = new OleDbCommand())
                    {
                        dbcon.Open();
                        dbcmd.Connection = dbcon;
                        dbcmd.CommandType = System.Data.CommandType.Text;
                        dbcmd.CommandText = "INSERT INTO tblTransaction (FirstName,LastName,EmailAddress,MobileNumber,EntryID,StartDatetime,EntryDateTime) VALUES(@FirstName,@LastName,@EmailAddress,@MobileNumber,@EntryID,#" + UM.StartDatetime.ToString("dd-MMM-yyyy hh:mm:ss") + "#,Now())";//#" + UM.EntryDateTime.ToString("dd-MMM-yyyy hh:mm:ss") + "#
                        dbcmd.CommandTimeout = 0;

                        dbcmd.Parameters.AddWithValue("FirstName", UM.FirstName);
                        dbcmd.Parameters.AddWithValue("LastName", UM.LastName);
                        dbcmd.Parameters.AddWithValue("EmailAddress", UM.EmailAddress);
                        dbcmd.Parameters.AddWithValue("MobileNumber", UM.MobileNumber);
                        dbcmd.Parameters.AddWithValue("EntryID", clsDBConnection.intLoginUserID);
                        
                        NoOfRowsAffected = dbcmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                NoOfRowsAffected = 0;
                MessageBox.Show(ex.ToString(), "AddTransaction", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            
            return NoOfRowsAffected;
        }

        public int DeleteTransaction(int TransactionId)
        {
            int NoOfRowsAffected = 0;
            try
            {
                using (dbcon = new OleDbConnection())
                {
                    dbcon.ConnectionString = clsDBConnection.strConstr;
                    using (dbcmd = new OleDbCommand())
                    {
                        dbcon.Open();
                        dbcmd.Connection = dbcon;
                        dbcmd.CommandType = System.Data.CommandType.Text;
                        dbcmd.CommandText = "DELETE FROM tblTransaction WHERE TransactionID = " + TransactionId;
                        dbcmd.CommandTimeout = 0;

                        NoOfRowsAffected = dbcmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                NoOfRowsAffected = 0;
                MessageBox.Show(ex.ToString(), "DeleteTransaction", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            
            return NoOfRowsAffected;
        }

        public int UpdateTransaction(TransactionModel UM)
        {
            int NoOfRowsAffected = 0;

            try
            {
                using (dbcon = new OleDbConnection())
                {
                    dbcon.ConnectionString = clsDBConnection.strConstr;
                    using (dbcmd = new OleDbCommand())
                    {
                        dbcon.Open();
                        dbcmd.Connection = dbcon;
                        dbcmd.CommandType = System.Data.CommandType.Text;
                        dbcmd.CommandText = "UPDATE tblTransaction SET FirstName = @FirstName, LastName = @LastName,EmailAddress = @EmailAddress, MobileNumber = @MobileNumber, EntryID = @EntryID, EntryDateTime = Now() WHERE TransactionID = " + UM.TransactionID;
                        dbcmd.CommandTimeout = 0;
                        
                        dbcmd.Parameters.AddWithValue("FirstName", UM.FirstName);
                        dbcmd.Parameters.AddWithValue("LastName", UM.LastName);
                        dbcmd.Parameters.AddWithValue("EmailAddress", UM.EmailAddress);
                        dbcmd.Parameters.AddWithValue("MobileNumber", UM.MobileNumber);
                        dbcmd.Parameters.AddWithValue("EntryID", clsDBConnection.intLoginUserID);
                        
                        NoOfRowsAffected = dbcmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                NoOfRowsAffected = 0;
                MessageBox.Show(ex.ToString(), "UpdateTransaction", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            
            return NoOfRowsAffected;
        }

        public void Dispose()
        {
            Dispose(true);
        }

        ~ TransactionRepository()
        {
            Dispose(false);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {

            }
        }
    }
}
