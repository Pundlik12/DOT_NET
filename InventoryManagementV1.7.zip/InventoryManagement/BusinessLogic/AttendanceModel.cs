﻿
namespace InventoryManagement.BusinessLogic
{
    public class AttendanceModel
    {
        public string AttendanceID { get; set; }
        public string EmployeeID { get; set; }
        public string AttendanceDate { get; set; }
        public string CheckIn { get; set; }
        public string CheckOut { get; set; }
        public string Status { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDateTime { get; set; }
    }
}
