﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;

namespace InventoryManagement.DataAccessLogic
{
    public class LeaveRequestDAL : IGenericRepository<LeaveRequestModel>
    {
        public LeaveRequestDAL()
        {
            DatabaseContext.CreateConnection();
        }

        public List<LeaveRequestModel> GetAll()
        {
            List<LeaveRequestModel> lstData = new List<LeaveRequestModel>();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT LeaveRequestID,EmployeeID,LeaveType,StartDate,EndDate,Reason,Status,CreatedBy,CreatedDateTime FROM LeaveRequests";
                
                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    LeaveRequestModel objLeaveRequest = new LeaveRequestModel();
                    objLeaveRequest.LeaveRequestID = Convert.ToString(DatabaseContext.dbdr["LeaveRequestID"]);
                    objLeaveRequest.EmployeeID = Convert.ToString(DatabaseContext.dbdr["EmployeeID"]);
                    objLeaveRequest.LeaveType = Convert.ToString(DatabaseContext.dbdr["LeaveType"]);
                    objLeaveRequest.StartDate = Convert.ToString(DatabaseContext.dbdr["StartDate"]);
                    objLeaveRequest.EndDate = Convert.ToString(DatabaseContext.dbdr["EndDate"]);
                    objLeaveRequest.Reason = Convert.ToString(DatabaseContext.dbdr["Reason"]);
                    objLeaveRequest.Status = Convert.ToString(DatabaseContext.dbdr["Status"]);
                    objLeaveRequest.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objLeaveRequest.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objLeaveRequest);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public List<LeaveRequestModel> GetByDates(string strFromDate, string strToDate)
        {
            throw new NotImplementedException();
        }

        public LeaveRequestModel GetByID(Int32 LeaveRequestID)
        {
            LeaveRequestModel objLeaveRequest = new LeaveRequestModel();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT LeaveRequestID,EmployeeID,LeaveType,StartDate,EndDate,Reason,Status,CreatedBy,CreatedDateTime FROM LeaveRequests WHERE LeaveRequestID = " + LeaveRequestID;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    objLeaveRequest.LeaveRequestID = Convert.ToString(DatabaseContext.dbdr["LeaveRequestID"]);
                    objLeaveRequest.EmployeeID = Convert.ToString(DatabaseContext.dbdr["EmployeeID"]);
                    objLeaveRequest.LeaveType = Convert.ToString(DatabaseContext.dbdr["LeaveType"]);
                    objLeaveRequest.StartDate = Convert.ToString(DatabaseContext.dbdr["StartDate"]);
                    objLeaveRequest.EndDate = Convert.ToString(DatabaseContext.dbdr["EndDate"]);
                    objLeaveRequest.Reason = Convert.ToString(DatabaseContext.dbdr["Reason"]);
                    objLeaveRequest.Status = Convert.ToString(DatabaseContext.dbdr["Status"]);
                    objLeaveRequest.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objLeaveRequest.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return objLeaveRequest;
        }

        public void Add(LeaveRequestModel objLeaveRequest)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "INSERT INTO LeaveRequests (EmployeeID,LeaveType,StartDate,EndDate,Reason,Status,CreatedBy,CreatedDateTime) VALUES(@EmployeeID,@LeaveType,@StartDate,@EndDate,@Reason,@Status,@CreatedBy,@CreatedDateTime)";
                
                DatabaseContext.dbcmd.Parameters.AddWithValue("EmployeeID", objLeaveRequest.EmployeeID);
                DatabaseContext.dbcmd.Parameters.AddWithValue("LeaveType", objLeaveRequest.LeaveType);
                DatabaseContext.dbcmd.Parameters.AddWithValue("StartDate", objLeaveRequest.StartDate);
                DatabaseContext.dbcmd.Parameters.AddWithValue("EndDate", objLeaveRequest.EndDate);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Reason", objLeaveRequest.Reason);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Status", objLeaveRequest.Status);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objLeaveRequest.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Update(LeaveRequestModel objLeaveRequest)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "UPDATE LeaveRequests SET EmployeeID = @EmployeeID,LeaveType = @LeaveType,StartDate = @StartDate,EndDate = @EndDate,Reason = @Reason,Status = @Status, CreatedBy = @CreatedBy, CreatedDateTime = @CreatedDateTime WHERE LeaveRequestID = " + objLeaveRequest.LeaveRequestID;

                DatabaseContext.dbcmd.Parameters.AddWithValue("EmployeeID", objLeaveRequest.EmployeeID);
                DatabaseContext.dbcmd.Parameters.AddWithValue("LeaveType", objLeaveRequest.LeaveType);
                DatabaseContext.dbcmd.Parameters.AddWithValue("StartDate", objLeaveRequest.StartDate);
                DatabaseContext.dbcmd.Parameters.AddWithValue("EndDate", objLeaveRequest.EndDate);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Reason", objLeaveRequest.Reason);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Status", objLeaveRequest.Status);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objLeaveRequest.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Delete(Int32 LeaveRequestID)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "DELETE FROM LeaveRequests WHERE LeaveRequestID = " + LeaveRequestID;
                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
