﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;

namespace InventoryManagement.DataAccessLogic
{
    public class PaymentDAL : IGenericRepository<PaymentModel>
    {
        string strQuery = "";

        public PaymentDAL()
        {
            DatabaseContext.CreateConnection();
        }

        public List<PaymentModel> GetAll()
        {
            List<PaymentModel> lstData = new List<PaymentModel>();
            try
            {
                string strTrnDate = "31-DEC-" + DateTime.Now.AddYears(-2).ToString("yyyy");

                strQuery = "";
                strQuery = strQuery + "SELECT Code,ChallanNo,TrnDate,Mode,Amount,Remarks,CreatedBy,CreatedDateTime\n";
                strQuery = strQuery + "FROM tblPayment\n";
                strQuery = strQuery + "WHERE TrnDate >= cdate('" + strTrnDate + "')\n";
                strQuery = strQuery + "ORDER BY TrnDate DESC";

                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = strQuery;
                
                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    PaymentModel objPayment = new PaymentModel();

                    objPayment.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objPayment.ChallanNo = Convert.ToString(DatabaseContext.dbdr["ChallanNo"]);
                    objPayment.TrnDate = Convert.ToString(DatabaseContext.dbdr["TrnDate"]);
                    objPayment.Mode = Convert.ToString(DatabaseContext.dbdr["Mode"]);
                    objPayment.Amount = Convert.ToString(DatabaseContext.dbdr["Amount"]);
                    objPayment.Remarks = Convert.ToString(DatabaseContext.dbdr["Remarks"]);
                    objPayment.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objPayment.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objPayment);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public List<PaymentModel> GetByDates(string strFromDate, string strToDate)
        {
            List<PaymentModel> lstData = new List<PaymentModel>();
            try
            {
                strQuery = "";
                strQuery = strQuery + "SELECT Code,ChallanNo,TrnDate,Mode,Amount,Remarks,CreatedBy,CreatedDateTime\n";
                strQuery = strQuery + "FROM tblPayment\n";
                strQuery = strQuery + "WHERE TrnDate >= cdate('" + strFromDate + "') and TrnDate <= cdate('" + strToDate + "')\n";
                strQuery = strQuery + "ORDER BY TrnDate DESC";

                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = strQuery;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();

                while (DatabaseContext.dbdr.Read())
                {
                    PaymentModel objPayment = new PaymentModel();

                    objPayment.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objPayment.ChallanNo = Convert.ToString(DatabaseContext.dbdr["ChallanNo"]);
                    objPayment.TrnDate = Convert.ToString(DatabaseContext.dbdr["TrnDate"]);
                    objPayment.Mode = Convert.ToString(DatabaseContext.dbdr["Mode"]);
                    objPayment.Amount = Convert.ToString(DatabaseContext.dbdr["Amount"]);
                    objPayment.Remarks = Convert.ToString(DatabaseContext.dbdr["Remarks"]);
                    objPayment.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objPayment.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objPayment);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public PaymentModel GetByID(Int32 UserCode)
        {
            PaymentModel objPayment = new PaymentModel();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT Code,ChallanNo,TrnDate,Mode,Amount,Remarks,CreatedBy,CreatedDateTime FROM tblPayment WHERE Code = " + UserCode;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    objPayment.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objPayment.ChallanNo = Convert.ToString(DatabaseContext.dbdr["ChallanNo"]);
                    objPayment.TrnDate = Convert.ToString(DatabaseContext.dbdr["TrnDate"]);
                    objPayment.Mode = Convert.ToString(DatabaseContext.dbdr["Mode"]);
                    objPayment.Amount = Convert.ToString(DatabaseContext.dbdr["Amount"]);
                    objPayment.Remarks = Convert.ToString(DatabaseContext.dbdr["Remarks"]);
                    objPayment.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objPayment.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return objPayment;
        }

        public void Add(PaymentModel objPayment)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "INSERT INTO tblPayment (ChallanNo,TrnDate,Mode,Amount,Remarks,CreatedBy,CreatedDateTime) VALUES(@ChallanNo,@TrnDate,@Mode,@Amount,@Remarks,@CreatedBy,@CreatedDateTime)";
                
                DatabaseContext.dbcmd.Parameters.AddWithValue("ChallanNo", objPayment.ChallanNo);
                DatabaseContext.dbcmd.Parameters.AddWithValue("TrnDate", objPayment.TrnDate);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Mode", objPayment.Mode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Amount", objPayment.Amount);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Remarks", objPayment.Remarks);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objPayment.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Update(PaymentModel objPayment)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "UPDATE tblPayment SET TrnDate = @TrnDate,Mode = @Mode,Amount = @Amount,Remarks = @Remarks,CreatedBy = @CreatedBy,CreatedDateTime = @CreatedDateTime WHERE Code = " + objPayment.Code;

                //DatabaseContext.dbcmd.Parameters.AddWithValue("ChallanNo", objPayment.ChallanNo);
                DatabaseContext.dbcmd.Parameters.AddWithValue("TrnDate", objPayment.TrnDate);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Mode", objPayment.Mode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Amount", objPayment.Amount);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Remarks", objPayment.Remarks);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objPayment.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Delete(Int32 UserCode)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "DELETE FROM tblPayment WHERE Code = " + UserCode;
                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
