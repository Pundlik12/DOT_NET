﻿using ECMS_Ryder.HelperClasses;
using ECMS_Ryder.Models;
using ECMS_Ryder.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace ECMS_Ryder.Forms
{
    public partial class frmUserForm : Form
    {
        private readonly UserDetailsRepository userDetailsRepository;
        private readonly EmailBoxRepository emailBoxRepository;
        private readonly CPIMDetailsRepository cPIMDetailsRepository;
        private readonly clsExcelLayer objClsExcelLayer;

        private readonly CategoryRepository categoryRepository;
        private readonly SubCategoryRepository subCategoryRepository;
        private readonly InclusionRepository inclusionRepository;

        private Int32 UserId;
        private Int32 MailBoxId;
        private List<UserDetails> userDetailsList;

        public frmUserForm()
        {
            InitializeComponent();

            objClsExcelLayer = new clsExcelLayer();
            userDetailsRepository = new UserDetailsRepository(clsDBConnection.strConnectionString);
            emailBoxRepository = new EmailBoxRepository(clsDBConnection.strConnectionString);
            cPIMDetailsRepository = new CPIMDetailsRepository(clsDBConnection.strConnectionString);
            categoryRepository = new CategoryRepository(clsDBConnection.strConnectionString);
            subCategoryRepository = new SubCategoryRepository(clsDBConnection.strConnectionString);
            inclusionRepository = new InclusionRepository(clsDBConnection.strConnectionString);
        }

        private void frmUserForm_Load(object sender, EventArgs e)
        {
            ClearAllUsers();
            //ClearAllMailBoxes();
            //ClearAllCategories();
            //ClearAllSubCategories();
            //fillCategoriesCombo();

            //List<CPIMDetails> cPIMDetailsList = cPIMDetailsRepository.GetAllCPIMDetails();
            //dgvCPIMDetails.DataSource = cPIMDetailsList;
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            if (tabControl1.SelectedTab == tabControl1.TabPages["UserManagementTab"])
            {
                ClearAllUsers();
            }
            else if (tabControl1.SelectedTab == tabControl1.TabPages["MailBoxTab"])
            {
                ClearAllMailBoxes();
            }
            else if (tabControl1.SelectedTab == tabControl1.TabPages["CPIMMasterTab"])
            {
                List<CPIMDetails> cPIMDetailsList = cPIMDetailsRepository.GetAllCPIMDetails();
                dgvCPIMDetails.DataSource = cPIMDetailsList;
            }
            else if (tabControl1.SelectedTab == tabControl1.TabPages["CategoryTab"])
            {
                ClearAllCategories();
            }
            else if (tabControl1.SelectedTab == tabControl1.TabPages["SubCategoryTab"])
            {
                fillCategoriesCombo();
                ClearAllSubCategories();
            }
            else if (tabControl1.SelectedTab == tabControl1.TabPages["InclusionsTab"])
            {
                fillSubCategoriesCombo();
                ClearAllInclusions();
            }
            this.Cursor = Cursors.Default;
        }

        public void ClearAllUsers()
        {
            UserId = 0;
            txtUID.Text = string.Empty;
            txtUserName.Text = string.Empty;
            cmbRole.SelectedIndex = 0;
            cmbUserStatus.SelectedIndex = 0;

            txtUID.Enabled = true;
            txtUserName.Enabled = false;
            cmbRole.Enabled = false;
            cmbUserStatus.Enabled = false;

            btnSubmit.Text = "Submit";
            btnSearch.Enabled = true;
            btnSubmit.Enabled = false;
            btnClear.Enabled = false;

            userDetailsList = userDetailsRepository.GetAllUsers();
            dgvUsers.DataSource = userDetailsList;

            txtUID.Focus();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtUID.Text.Trim() == "")
            {
                txtUID.Focus();
                MessageBox.Show("Please enter UID.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            this.Cursor = Cursors.WaitCursor;

            UserDetails userDetails;
            userDetails = userDetailsRepository.GetUserByUID(txtUID.Text.Trim());
                
            if (userDetails.UserName == null)
            {
                if (MessageBox.Show("User doesn't exists with entered UID.Do you want to create?", "ECMS Tool - Ryder", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    btnSubmit.Text = "Create";
                }
            }
            else
            {
                btnSubmit.Text = "Update";
                UserId = userDetails.UserId;
                txtUserName.Text = userDetails.UserName;
                cmbRole.Text = userDetails.Role;
                cmbUserStatus.Text = userDetails.IsActive;    
            }

            txtUID.Enabled = false;
            txtUserName.Enabled = true;
            cmbRole.Enabled = true;
            cmbUserStatus.Enabled = true;

            btnSearch.Enabled = false;
            btnSubmit.Enabled = true;
            btnClear.Enabled = true;
            txtUserName.Focus();

            this.Cursor = Cursors.Default;
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtUID.Text.Trim() == "")
            {
                txtUID.Focus();
                MessageBox.Show("Please enter UID.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            if (txtUserName.Text.Trim() == "")
            {
                txtUserName.Focus();
                MessageBox.Show("Please enter user name.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            if (cmbRole.SelectedIndex == 0)
            {
                cmbRole.Focus();
                MessageBox.Show("Please select role.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            if (cmbUserStatus.SelectedIndex == 0)
            {
                cmbUserStatus.Focus();
                MessageBox.Show("Please select status.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            this.Cursor = Cursors.WaitCursor;

            UserDetails userDetails = new UserDetails();
            userDetails.UserId = UserId;
            userDetails.UID = txtUID.Text;
            userDetails.UserName = txtUserName.Text;

            if (cmbRole.Text == UserRole.Admin.ToString())
            {
                userDetails.Role = UserRole.Admin.ToString();
            }
            else
            {
                userDetails.Role = UserRole.Associate.ToString();
            }

            if (cmbUserStatus.Text == UserStatus.Active.ToString())
            {
                userDetails.IsActive = UserStatus.Active.ToString();
            }
            else
            {
                userDetails.IsActive = UserStatus.InActive.ToString();
            }

            userDetails.EntryUser = "";
            userDetails.EntryDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            txtUserName.Enabled = true;
            cmbRole.Enabled = true;
            cmbUserStatus.Enabled = true;

            if (btnSubmit.Text == "Create")
            {
                userDetailsRepository.RegisterUser(userDetails);
                MessageBox.Show("User created successfully.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                userDetailsRepository.UpdateUser(userDetails);
                MessageBox.Show("User updated successfully.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            ClearAllUsers();

            this.Cursor = Cursors.Default;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearAllUsers();
        }

        private void btnViewAll_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            ClearAllUsers();

            this.Cursor = Cursors.Default;
        }

        private void btnSaveMaiBox_Click(object sender, EventArgs e)
        {
            if (txtEmailAddress.Text.Trim() == "")
            {
                txtEmailAddress.Focus();
                MessageBox.Show("Please enter EmailAddress.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            if (cmbMailBoxStatus.SelectedIndex == 0)
            {
                cmbMailBoxStatus.Focus();
                MessageBox.Show("Please select status.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            this.Cursor = Cursors.WaitCursor;

            EmailBox emailBox = new EmailBox();
            
            emailBox.EmailBoxId = MailBoxId;
            emailBox.EmailAddress = txtEmailAddress.Text;
            
            if (cmbMailBoxStatus.Text == UserStatus.Active.ToString())
            {
                emailBox.Status = UserStatus.Active.ToString();
            }
            else
            {
                emailBox.Status = UserStatus.InActive.ToString();
            }

            emailBox.FolderName = "Inbox";
            emailBox.EntryUser = clsDBConnection.strLoggedInUID;
            emailBox.EntryDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            if (btnSaveMaiBox.Text == "Save")
            {
                emailBoxRepository.CreateEmailBox(emailBox);
                MessageBox.Show("MailBox created successfully.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                emailBoxRepository.UpdateEmailBox(emailBox);
                MessageBox.Show("MailBox updated successfully.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            ClearAllMailBoxes();

            this.Cursor = Cursors.Default;
        }

        private void btnClearMailBox_Click(object sender, EventArgs e)
        {
            ClearAllMailBoxes();
        }

        private void btnViewAllMailBoxes_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            ClearAllMailBoxes();

            this.Cursor = Cursors.Default;
        }

        private void dgvMailboxes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (e.ColumnIndex == 0)
                {
                    MailBoxId = Convert.ToInt32(dgvMailboxes.Rows[e.RowIndex].Cells["EmailBoxId"].Value);
                    txtEmailAddress.Text = Convert.ToString(dgvMailboxes.Rows[e.RowIndex].Cells["EmailAddress"].Value);
                    cmbMailBoxStatus.Text = Convert.ToString(dgvMailboxes.Rows[e.RowIndex].Cells["Status"].Value);
                    txtEmailAddress.Focus();

                    btnSaveMaiBox.Text = "Update";
                    dgvMailboxes.Enabled = false;
                }

                if (e.ColumnIndex == 1)
                {                    
                    if (MessageBox.Show("Are you sure to delete the mailbox?", "ECMS Tool - Ryder", MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        MailBoxId = Convert.ToInt32(dgvMailboxes.Rows[e.RowIndex].Cells["EmailBoxId"].Value);
                        emailBoxRepository.DeleteEmailBox(MailBoxId);
                        ClearAllMailBoxes();
                        MessageBox.Show("MailBox deleted successfully.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void ClearAllMailBoxes()
        {
            btnSaveMaiBox.Text = "Save";
            txtEmailAddress.Text = "";
            cmbMailBoxStatus.SelectedIndex = 0;
            dgvMailboxes.Enabled = true;
            MailBoxId = 0;
            
            List<EmailBox> emailBox = new List<EmailBox>();
            emailBox = emailBoxRepository.GetAllEmailBoxes();
            dgvMailboxes.DataSource = emailBox;
            
            txtEmailAddress.Focus();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            
            if(openFileDialog.ShowDialog() == DialogResult.OK)
            {
                txtCPIMMaster.Text = openFileDialog.FileName;
            }
            else
            {
                txtCPIMMaster.Text = "";
            }
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            if (txtCPIMMaster.Text == "")
            {
                txtCPIMMaster.Focus();
                MessageBox.Show("CPIM master file is not selected.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            Cursor = Cursors.WaitCursor;

            List<CPIMDetails> lstExcelData = objClsExcelLayer.ReadExcelWorkBook(txtCPIMMaster.Text.Trim());
            List<CPIMDetails> nonBlankData = null;
            List<CPIMDetails> InvalidUID = null;
            Boolean isValid = true;

            nonBlankData = (from data in lstExcelData where data.AssignToUID != "" select data).ToList();
            if (nonBlankData.Count > 0)
            {
                InvalidUID = nonBlankData.Where(l1 => !userDetailsList.Any(l2 => l1.AssignToUID == l2.UID)).ToList();
                if (InvalidUID.Count > 0)
                {
                    isValid = false;
                    MessageBox.Show("Data not uploaded in system as invalid UID(s) found in Input file.\n\nplease correct input file and try again.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    isValid = true;
                }
            }            
            else
            {
                isValid = false;
                MessageBox.Show("Data not found to upload.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

            if (isValid == true)
            {
                cPIMDetailsRepository.UploadCPIMDetails(nonBlankData);
                
                dgvCPIMDetails.DataSource = nonBlankData;

                MessageBox.Show("CPIM details are uploaded successfully.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            Cursor = Cursors.Default;
        }

        private void btnClearCPIMMaster_Click(object sender, EventArgs e)
        {
            txtCPIMMaster.Text = "";
        }

        private void btnSaveCategory_Click(object sender, EventArgs e)
        {
            if (txtCategory.Text.Trim() == "")
            {
                txtCategory.Focus();
                MessageBox.Show("Please enter Category.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            this.Cursor = Cursors.WaitCursor;

            CategoryDetails categoryDetails = new CategoryDetails();

            categoryDetails.CategoryId = MailBoxId;
            categoryDetails.Category = txtCategory.Text;

            //categoryDetails.EntryUser = clsDBConnection.strLoggedInUID;
            //categoryDetails.EntryDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            if (btnSaveCategory.Text == "Save")
            {
                categoryRepository.CreateCategory(categoryDetails);
                MessageBox.Show("Category created successfully.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                categoryRepository.UpdateCategory(categoryDetails);
                MessageBox.Show("Category updated successfully.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            ClearAllCategories();

            this.Cursor = Cursors.Default;
        }

        private void dgvCategories_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (e.ColumnIndex == 0)
                {
                    MailBoxId = Convert.ToInt32(dgvCategories.Rows[e.RowIndex].Cells["CategoryIdCategory"].Value);
                    txtCategory.Text = Convert.ToString(dgvCategories.Rows[e.RowIndex].Cells["Category"].Value);
                    txtCategory.Focus();

                    btnSaveCategory.Text = "Update";
                    dgvCategories.Enabled = false;
                }

                if (e.ColumnIndex == 1)
                {
                    if (MessageBox.Show("Are you sure to delete the category?", "ECMS Tool - Ryder", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        MailBoxId = Convert.ToInt32(dgvCategories.Rows[e.RowIndex].Cells["CategoryIdCategory"].Value);
                        categoryRepository.DeleteCategory(MailBoxId);
                        ClearAllCategories();
                        MessageBox.Show("Category deleted successfully.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void btnClearCategory_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            ClearAllCategories();

            Cursor.Current = Cursors.Default;
        }

        private void btnViewAllCategories_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            ClearAllCategories();

            Cursor.Current = Cursors.Default;
        }

        private void ClearAllCategories()
        {
            btnSaveCategory.Text = "Save";
            txtCategory.Text = "";
            dgvCategories.Enabled = true;
            MailBoxId = 0;

            List<CategoryDetails> categorylist = new List<CategoryDetails>();
            categorylist = categoryRepository.GetAllCategories();
            dgvCategories.DataSource = categorylist;

            txtCategory.Focus();
        }

        private void fillCategoriesCombo()
        {
            List<CategoryDetails> categorylist = new List<CategoryDetails>();
            categorylist = categoryRepository.GetAllCategories();
            
            cmbCategory.DataSource = null;
            cmbCategory.DataSource = categorylist;
            cmbCategory.DisplayMember = "Category";
            cmbCategory.ValueMember = "CategoryId";
            cmbCategory.SelectedIndex = -1;
        }

        private void btnSaveSubCategory_Click(object sender, EventArgs e)
        {
            if (cmbCategory.SelectedIndex == -1)
            {
                cmbCategory.Focus();
                MessageBox.Show("Please select Category.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            if (txtSubCategory.Text.Trim() == "")
            {
                txtSubCategory.Focus();
                MessageBox.Show("Please enter SubCategory.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            this.Cursor = Cursors.WaitCursor;

            SubCategoryDetails subCategoryDetails = new SubCategoryDetails();

            subCategoryDetails.SubCategoryId = MailBoxId;
            subCategoryDetails.CategoryId = Convert.ToInt32(cmbCategory.SelectedValue);
            subCategoryDetails.SubCategory = txtSubCategory.Text;

            //subCategoryDetails.EntryUser = clsDBConnection.strLoggedInUID;
            //subCategoryDetails.EntryDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            if (btnSaveSubCategory.Text == "Save")
            {
                subCategoryRepository.CreateSubCategory(subCategoryDetails);
                MessageBox.Show("SubCategory created successfully.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                subCategoryRepository.UpdateSubCategory(subCategoryDetails);
                MessageBox.Show("SubCategory updated successfully.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            ClearAllSubCategories();

            this.Cursor = Cursors.Default;
        }

        private void btnClearSubCategory_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            ClearAllSubCategories();

            Cursor.Current = Cursors.Default;
        }

        private void btnViewAllSubCategories_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            ClearAllSubCategories();

            Cursor.Current = Cursors.Default;
        }

        private void ClearAllSubCategories()
        {
            btnSaveSubCategory.Text = "Save";
            txtSubCategory.Text = "";
            cmbCategory.SelectedIndex = -1;
            dgvSubCategories.Enabled = true;
            MailBoxId = 0;

            List<SubCategoryDetails> subCategoryDetails = new List<SubCategoryDetails>();
            subCategoryDetails = subCategoryRepository.GetAllSubCategories();
            dgvSubCategories.DataSource = subCategoryDetails;

            cmbCategory.Select();
        }

        private void dgvSubCategories_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (e.ColumnIndex == 0)
                {
                    MailBoxId = Convert.ToInt32(dgvSubCategories.Rows[e.RowIndex].Cells["SubCategoryId"].Value);
                    txtSubCategory.Text = Convert.ToString(dgvSubCategories.Rows[e.RowIndex].Cells["SubCategory"].Value);
                    cmbCategory.Text = Convert.ToString(dgvSubCategories.Rows[e.RowIndex].Cells["CategorySubCategory"].Value);
                    cmbCategory.Focus();

                    btnSaveSubCategory.Text = "Update";
                    dgvSubCategories.Enabled = false;
                }

                if (e.ColumnIndex == 1)
                {
                    if (MessageBox.Show("Are you sure to delete the SubCategory?", "ECMS Tool - Ryder", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        MailBoxId = Convert.ToInt32(dgvSubCategories.Rows[e.RowIndex].Cells["SubCategoryId"].Value);
                        subCategoryRepository.DeleteSubCategory(MailBoxId);
                        ClearAllSubCategories();
                        MessageBox.Show("SubCategory deleted successfully.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void fillSubCategoriesCombo()
        {
            List<SubCategoryDetails> subCategorylist = new List<SubCategoryDetails>();
            subCategorylist = subCategoryRepository.GetAllSubCategories();

            cmbSubCategory.DataSource = null;
            cmbSubCategory.DataSource = subCategorylist;
            cmbSubCategory.DisplayMember = "SubCategory";
            cmbSubCategory.ValueMember = "SubCategoryId";
            cmbSubCategory.SelectedIndex = -1;
        }

        private void btnSaveInclusion_Click(object sender, EventArgs e)
        {
            if (cmbSubCategory.SelectedIndex == -1)
            {
                cmbSubCategory.Focus();
                MessageBox.Show("Please select SubCategory.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            if (txtInclusion.Text.Trim() == "")
            {
                txtInclusion.Focus();
                MessageBox.Show("Please enter inclusion.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            this.Cursor = Cursors.WaitCursor;

            InclusionDetails inclusionDetails = new InclusionDetails();

            inclusionDetails.InclusionId = MailBoxId;
            inclusionDetails.SubCategoryId = Convert.ToInt32(cmbSubCategory.SelectedValue);
            inclusionDetails.Inclusion = txtInclusion.Text;

            //inclusionDetails.EntryUser = clsDBConnection.strLoggedInUID;
            //inclusionDetails.EntryDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            if (btnSaveInclusion.Text == "Save")
            {
                inclusionRepository.CreateInclusion(inclusionDetails);
                MessageBox.Show("Inclusion created successfully.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                inclusionRepository.UpdateInclusion(inclusionDetails);
                MessageBox.Show("Inclusion updated successfully.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            ClearAllInclusions();

            this.Cursor = Cursors.Default;
        }

        private void ClearAllInclusions()
        {
            btnSaveInclusion.Text = "Save";
            txtInclusion.Text = "";
            cmbSubCategory.SelectedIndex = -1;
            dgvInclusions.Enabled = true;
            MailBoxId = 0;

            List<InclusionDetails> inclusionDetails = new List<InclusionDetails>();
            inclusionDetails = inclusionRepository.GetAllInclusions();
            dgvInclusions.DataSource = inclusionDetails;

            cmbSubCategory.Select();
        }

        private void btnClearInclusion_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            ClearAllInclusions();

            Cursor.Current = Cursors.Default;
        }

        private void btnViewAllInclusion_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            ClearAllInclusions();

            Cursor.Current = Cursors.Default;
        }

        private void dgvInclusions_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (e.ColumnIndex == 0)
                {
                    MailBoxId = Convert.ToInt32(dgvInclusions.Rows[e.RowIndex].Cells["InclusionID"].Value);
                    txtInclusion.Text = Convert.ToString(dgvInclusions.Rows[e.RowIndex].Cells["Inclusion"].Value);
                    cmbSubCategory.Text = Convert.ToString(dgvInclusions.Rows[e.RowIndex].Cells["SubCategoryInclusion"].Value);
                    cmbSubCategory.Focus();

                    btnSaveInclusion.Text = "Update";
                    dgvInclusions.Enabled = false;
                }

                if (e.ColumnIndex == 1)
                {
                    if (MessageBox.Show("Are you sure to delete the Inclusion?", "ECMS Tool - Ryder", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        MailBoxId = Convert.ToInt32(dgvInclusions.Rows[e.RowIndex].Cells["InclusionID"].Value);
                        inclusionRepository.DeleteInclusion(MailBoxId);
                        ClearAllInclusions();
                        MessageBox.Show("Inclusion deleted successfully.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }
    }
}
