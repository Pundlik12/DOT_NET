﻿using System;
using System.Windows.Forms;
using InventoryManagement.DataAccessLogic;

namespace InventoryManagement
{
    public partial class frmChangePassword : Form
    {
        AuthDAL objAuthDAL = null;

        public frmChangePassword()
        {
            InitializeComponent();
        }

        private void frmChangePassword_Load(object sender, EventArgs e)
        {
            txtEmail.Text = common.strUserEmail;
            objAuthDAL = new AuthDAL();
            txtNewPassword.Select();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtEmail.Text.Trim() == "")
            {
                txtEmail.Focus();
                MessageBox.Show("Please enter email.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtNewPassword.Text.Trim() == "")
            {
                txtNewPassword.Focus();
                MessageBox.Show("Please enter new password.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtConfirmPassword.Text.Trim() == "")
            {
                txtConfirmPassword.Focus();
                MessageBox.Show("Please enter confirm password.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtNewPassword.Text != txtConfirmPassword.Text)
            {
                txtNewPassword.Focus();
                MessageBox.Show("Passwords doesnt match.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                Cursor = Cursors.WaitCursor;
                objAuthDAL.ChangePassword(txtEmail.Text.Trim(), txtNewPassword.Text.Trim());
                ClearFields();
                //MessageBox.Show("Password changed successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                Cursor = Cursors.Default;
            }
        }

        private void ClearFields()
        {
            txtNewPassword.Text = "";
            txtConfirmPassword.Text = "";
            txtNewPassword.Focus();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
