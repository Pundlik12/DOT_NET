﻿using System.Collections.Generic;

namespace HBAccessTool
{
    public interface iAuxDetails
    {
        List<AuxModel> GetAllAuxDetails();
        AuxModel GetAuxDetailsByAuxID(int AuxId);
        AuxModel GetAuxDetailsByUserID(int UserId);
        int AddAux(AuxModel Ax);
        int UpdateAux(AuxModel Ax);
        int DeleteAux(int AuxId);
    }
}
