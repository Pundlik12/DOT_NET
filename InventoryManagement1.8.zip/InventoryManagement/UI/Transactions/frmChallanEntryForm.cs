﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;
using InventoryManagement.DataAccessLogic;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;

namespace InventoryManagement
{
    public partial class frmChallanEntryForm : Form
    {
        IGenericRepository<CustomerModel> objCustomerDal = null;
        IGenericRepository<CustomerItemModel> objCustomerItemDal = null;
        IGenericRepository<ChallanHeaderModel> objChallanDal = null;
        iReports objReportDal = null;

        List<CustomerModel> lstCustomer = null;
        List<CustomerItemModel> objCustomerItemList = null;
        
        public frmChallanEntryForm()
        {
            InitializeComponent();
        }

        private void frmChallanEntry_Load(object sender, EventArgs e)
        {
            objChallanDal = new ChallanDAL();
            objReportDal = new ChallanDAL();

            objCustomerDal = new CustomerDAL();
            lstCustomer = objCustomerDal.GetAll();

            objCustomerItemDal = new CustomerItemDAL();
            objCustomerItemList = objCustomerItemDal.GetAll();

            lblCount.Text = "0";
            txtGrandTotal.Text = "0";
            txtTotalGST.Text = "0";
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                FolderBrowserDialog fbd = new FolderBrowserDialog();

                if (fbd.ShowDialog() == DialogResult.OK)
                {
                    Cursor = Cursors.WaitCursor;
                    lnkHardDrivePath.Text = fbd.SelectedPath;
                    List<Challan> objChallanList = new List<Challan>();

                    StringBuilder sbLog = new StringBuilder();

                    lblCount.Text = "0";
                    txtGrandTotal.Text = "0";
                    txtTotalGST.Text = "0";

                    string strCustomerNameFolder = "";
                    string strItemNameFolder = "";
                    string strQuantityFolder = "";

                    strCustomerNameFolder = Path.GetFileName(Path.GetDirectoryName(fbd.SelectedPath + "//test.txt"));

                    List<CustomerModel> data = lstCustomer.Where(x => x.Name.ToUpper() == strCustomerNameFolder.ToUpper()).ToList();
                    if (data.Count == 0)
                    {
                        sbLog.AppendLine(strCustomerNameFolder + " Customer Name not found in customer master.");
                    }
                    else
                    {
                        string[] ItemsDirectories = Directory.GetDirectories(fbd.SelectedPath);
                        Boolean isValid = false;

                        foreach (string ItemsDirectory in ItemsDirectories)
                        {
                            strItemNameFolder = Path.GetFileName(Path.GetDirectoryName(ItemsDirectory + "//test.txt"));

                            List<CustomerItemModel> data1 = objCustomerItemList.Where(x => x.ItemName.ToUpper() == strItemNameFolder.ToUpper() && x.CustomerName.ToUpper() == strCustomerNameFolder).ToList();

                            if (data1.Count == 0)
                            {
                                sbLog.AppendLine(strItemNameFolder + " Item Name not found in Item master.");
                            }
                            else
                            {
                                double dblGstPercent = Convert.ToDouble(data1[0].GSTPercent);

                                string[] QuantitiesDirectories = Directory.GetDirectories(ItemsDirectory);

                                foreach (string QuantityDirectory in QuantitiesDirectories)
                                {
                                    strQuantityFolder = Path.GetFileName(Path.GetDirectoryName(QuantityDirectory + "//test.txt"));
                                    try
                                    {
                                        Convert.ToDouble(strQuantityFolder);
                                        isValid = true;
                                    }
                                    catch (Exception)
                                    {
                                        isValid = false;
                                    }

                                    if (isValid == true)
                                    {
                                        string[] descriptions = Directory.GetFiles(QuantityDirectory);

                                        foreach (string descriptionsDirectory in descriptions)
                                        {
                                            string strDescription = Path.GetFileNameWithoutExtension(descriptionsDirectory);

                                            Challan objChallan = new Challan();

                                            objChallan.CustomerCode = Convert.ToString(data[0].Code);
                                            objChallan.CustomerName = strCustomerNameFolder;

                                            objChallan.ItemCode = Convert.ToString(data1[0].ItemCode);
                                            objChallan.ItemName = strItemNameFolder;
                                            objChallan.Rate = Convert.ToDouble(data1[0].Rate);

                                            objChallan.Description = strDescription;
                                            objChallan.Qty = Convert.ToDouble(strQuantityFolder);

                                            double dblAmount = Convert.ToDouble(objChallan.Qty) * Convert.ToDouble(objChallan.Rate);
                                            double dblGstAmount = (dblAmount * (dblGstPercent / 100));

                                            objChallan.GSTPercent = dblGstPercent;
                                            objChallan.GSTAmount = dblGstAmount;
                                            objChallan.LineTotal = (dblAmount + dblGstAmount);

                                            objChallanList.Add(objChallan);

                                            txtGrandTotal.Text = Convert.ToString(Convert.ToDouble(txtGrandTotal.Text) + dblAmount + dblGstAmount);
                                            txtTotalGST.Text = Convert.ToString(Convert.ToDouble(txtTotalGST.Text) + dblGstAmount);
                                        }
                                    }
                                    else
                                    {
                                        sbLog.AppendLine(strQuantityFolder + " Qty should be numeric only.");
                                    }
                                }
                            }
                        }
                    }

                    //strCustomerNameFolder = Path.GetFileName(Path.GetDirectoryName(fbd.SelectedPath));

                    //List<CustomerModel> data = lstCustomer.Where(x => x.Name.ToUpper() == strCustomerNameFolder.ToUpper()).ToList();
                    //if (data.Count == 0)
                    //{
                    //    sbLog.AppendLine(strCustomerNameFolder + " Customer Name not found in customer master.");
                    //}
                    //else
                    //{
                    //    strItemNameFolder = Path.GetFileName(Path.GetDirectoryName(fbd.SelectedPath + "//test.txt"));
                    //    Boolean isValid = false;
    
                    //    List<CustomerItemModel> CustomerItemDetails = objCustomerItemList.Where(x => x.ItemName.ToUpper() == strItemNameFolder.ToUpper() && x.CustomerName.ToUpper() == strCustomerNameFolder).ToList();

                    //    if (CustomerItemDetails.Count == 0)
                    //    {
                    //        sbLog.AppendLine(strItemNameFolder + " Item Name not found in Item master.");
                    //    }
                    //    else
                    //    {
                    //        double dblGstPercent = Convert.ToDouble(CustomerItemDetails[0].GSTPercent);

                    //        string[] QuantitiesDirectories = Directory.GetDirectories(fbd.SelectedPath);

                    //        foreach (string QuantityDirectory in QuantitiesDirectories)
                    //        {
                    //            strQuantityFolder = Path.GetFileName(Path.GetDirectoryName(QuantityDirectory + "//test.txt"));
                    //            try
                    //            {
                    //                Convert.ToDouble(strQuantityFolder);
                    //                isValid = true;
                    //            }
                    //            catch (Exception)
                    //            {
                    //                isValid = false;
                    //            }

                    //            if (isValid == true)
                    //            {
                    //                string[] descriptions = Directory.GetFiles(QuantityDirectory);

                    //                foreach (string descriptionsDirectory in descriptions)
                    //                {
                    //                    string strDescription = Path.GetFileNameWithoutExtension(descriptionsDirectory);

                    //                    Challan objChallan = new Challan();

                    //                    objChallan.CustomerCode = Convert.ToString(data[0].Code);
                    //                    objChallan.CustomerName = strCustomerNameFolder;

                    //                    objChallan.ItemCode = Convert.ToString(CustomerItemDetails[0].ItemCode);
                    //                    objChallan.ItemName = strItemNameFolder;
                    //                    objChallan.Rate = Convert.ToDouble(CustomerItemDetails[0].Rate);

                    //                    objChallan.Description = strDescription;
                    //                    objChallan.Qty = Convert.ToDouble(strQuantityFolder);

                    //                    double dblAmount = Convert.ToDouble(objChallan.Qty) * Convert.ToDouble(objChallan.Rate);
                    //                    double dblGstAmount = (dblAmount * (dblGstPercent / 100));

                    //                    objChallan.GSTPercent = dblGstPercent;
                    //                    objChallan.GSTAmount = dblGstAmount;
                    //                    objChallan.LineTotal = (dblAmount + dblGstAmount);

                    //                    objChallanList.Add(objChallan);

                    //                    txtGrandTotal.Text = Convert.ToString(Convert.ToDouble(txtGrandTotal.Text) + dblAmount + dblGstAmount);
                    //                    txtTotalGST.Text = Convert.ToString(Convert.ToDouble(txtTotalGST.Text) + dblGstAmount);
                    //                }
                    //            }
                    //            else
                    //            {
                    //                sbLog.AppendLine(strQuantityFolder + " Qty should be numeric only.");
                    //            }
                    //        }
                    //    }
                    //}

                    if (sbLog.ToString() != "")
                    {
                        MessageBox.Show(sbLog.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }
                    else
                    {
                        Int64 counter = 0;
                        foreach (Challan item in objChallanList)
                        {
                            counter = counter + 1;
                            dgvChallan.Rows.Add(item.CustomerCode, item.CustomerName, item.ItemCode, item.ItemName, item.Description, item.Rate, item.Qty, item.GSTPercent, item.GSTAmount, item.LineTotal);
                        }
                        lblCount.Text = Convert.ToString(counter);
                    }
                    Cursor = Cursors.Default;
                }
            }
            catch (Exception ex)
            {
                Cursor = Cursors.Default;
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvChallan.Rows.Count > 0)
                {
                    Cursor = Cursors.WaitCursor;
                    ChallanHeaderModel ObjChallanHeader = new ChallanHeaderModel();

                    ObjChallanHeader.ChallanDate = Convert.ToDateTime(DateTime.Now.ToString("dd-MMM-yyyy"));
                    ObjChallanHeader.CustomerCode = Convert.ToInt32(dgvChallan.Rows[0].Cells["CustomerCode"].Value);
                    ObjChallanHeader.TotalGST = Convert.ToDouble(txtTotalGST.Text);
                    ObjChallanHeader.TotalAmount = Convert.ToDouble(txtGrandTotal.Text);
                    ObjChallanHeader.CreatedBy = common.strUserEmail;

                    List<ChallanDetailsModel> ObjChallanDetailsList = new List<ChallanDetailsModel>();

                    foreach (DataGridViewRow item in dgvChallan.Rows)
                    {
                        ChallanDetailsModel ObjChallanDetail = new ChallanDetailsModel();

                        ObjChallanDetail.ItemCode = Convert.ToInt32(item.Cells["ItemCode"].Value);
                        ObjChallanDetail.Description = Convert.ToString(item.Cells["Description"].Value);
                        ObjChallanDetail.Qty = Convert.ToInt32(item.Cells["Qty"].Value);
                        ObjChallanDetail.Rate = Convert.ToInt32(item.Cells["Rate"].Value);
                        ObjChallanDetail.GST = Convert.ToInt32(item.Cells["GSTAmount"].Value);
                        ObjChallanDetail.Amount = Convert.ToInt32(item.Cells["LineTotal"].Value);

                        ObjChallanDetailsList.Add(ObjChallanDetail);
                    }
                    ObjChallanHeader.ChallanDetails = ObjChallanDetailsList;

                    objChallanDal.Add(ObjChallanHeader);

                    if (chkPrint.Checked == true)
                    {
                        DataTable dt = objReportDal.PrintChallan();

                        if (dt != null && dt.Rows.Count > 0)
                        {
                            common.PrintInvoice(dt);
                        }
                    }

                    int RowsCount = dgvChallan.Rows.Count;
                    for (int i = 0; i < RowsCount; i++)
                    {
                        dgvChallan.Rows.RemoveAt(0);
                    }

                    lblCount.Text = "0";
                    txtGrandTotal.Text = "";
                    txtTotalGST.Text = "";
                    lnkHardDrivePath.Text = "-";
                    Cursor = Cursors.Default;
                }
            }
            catch (Exception ex)
            {
                Cursor = Cursors.Default;
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
