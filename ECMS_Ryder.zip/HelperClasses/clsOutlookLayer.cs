﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows;
using ECMS_Ryder.Models;
using MyOutlookApp = Microsoft.Office.Interop.Outlook;

namespace ECMS_Ryder.HelperClasses
{
    internal class clsOutlookLayer
    {
        private MyOutlookApp.Application outlookApp;
        //private MyOutlookApp.Store store;
        private MyOutlookApp.NameSpace olNS;
        private MyOutlookApp.MAPIFolder FolderToFind = null;
        public string strEmailAddress = "";
        public string FolderNameToSearch = "";
        public string strFromDate = "";
        public string strToDate = "";

        public clsOutlookLayer()
        {
            outlookApp = new MyOutlookApp.Application();
            olNS = outlookApp.GetNamespace("MAPI");
        }

        public Boolean CheckEmailBoxAvailable()
        {
            Boolean isEmailIDFound = false;

            foreach (MyOutlookApp.MAPIFolder folder in olNS.Folders)
            {
                if (folder.Name.ToUpper().Trim() == clsDBConnection.strEmailAddress.ToUpper().Trim())
                {
                    isEmailIDFound = true;
                    break;
                }
            }

            if (isEmailIDFound == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<string> GetSubFoldersOfInbox()
        {
            Boolean isEmailIDFound = false;
            MyOutlookApp.MAPIFolder EmailFolder = null;
            MyOutlookApp.MAPIFolder InboxFolder = null;
            List<string> InboxFolderList = new List<string>();

            foreach (MyOutlookApp.MAPIFolder mailBoxFolder in olNS.Folders)
            {
                if (mailBoxFolder.Name.ToUpper().Trim() == clsDBConnection.strEmailAddress.ToUpper().Trim())
                {
                    isEmailIDFound = true;
                    EmailFolder = mailBoxFolder;
                    break;
                }
            }

            if (isEmailIDFound == true)
            {
                foreach (MyOutlookApp.MAPIFolder inboxFolder in EmailFolder.Folders)
                {
                    if (inboxFolder.Name.ToUpper().Trim() == "INBOX")
                    {
                        InboxFolder = inboxFolder;
                        break;
                    }
                }

                foreach (MyOutlookApp.MAPIFolder subFolder in InboxFolder.Folders)
                {
                    InboxFolderList.Add(subFolder.Name);
                }
            }

            return InboxFolderList;
        }

        public List<EmailDetails> GetOutlookEmails()
        {
            try
            {
                MyOutlookApp.MAPIFolder EmailFolder = null;
                MyOutlookApp.MAPIFolder FolderFound = null;
                Boolean isEmailIDFound = false;
                FolderToFind = null;

                foreach (MyOutlookApp.MAPIFolder folder in olNS.Folders)
                {
                    if (folder.Name.ToUpper().Trim() == clsDBConnection.strEmailAddress.ToUpper().Trim())
                    {
                        isEmailIDFound = true;
                        EmailFolder = folder;
                        break;
                    }
                }

                if (isEmailIDFound == true)
                {
                    FolderFound = GetFolder(EmailFolder);
                    //FolderFound = GetInboxFolder(EmailFolder);

                    if (FolderFound != null)
                    {
                        List<EmailDetails> EmailsList = new List<EmailDetails>();
                        EmailDetails objEmail = null;
                        MyOutlookApp.Items EmailItems = null;

                        string filterFromDate = Convert.ToDateTime(strFromDate).ToString("MM/dd/yyyy HH:mm");
                        string filterToDate = Convert.ToDateTime(strToDate).AddDays(1).ToString("MM/dd/yyyy HH:mm");

                        string sFilter = "[ReceivedTime] >= '" + filterFromDate + "' and [ReceivedTime] < '" + filterToDate + "'";

                        EmailItems = FolderFound.Items.Restrict(sFilter);

                        foreach (var item in EmailItems)
                        {
                            if (item is MyOutlookApp.MailItem)
                            {
                                MyOutlookApp.MailItem mailItem = (MyOutlookApp.MailItem)item;

                                string strSenderName = "";
                                string strSenderEmailAddress = "";
                                string strTo = "";
                                string strCC = "";
                                string strBCC = "";
                                string strReceivedTime = "";
                                string strBody = "";
                                string strSubject = "";
                                string strSensitivity = "";
                                string strAttachments = "";
                                string strEntryID = "";
                                string strConversationID = "";

                                strSenderName = mailItem.SenderName.ToString();
                                strSenderEmailAddress = mailItem.SenderEmailAddress;

                                if (!string.IsNullOrEmpty(mailItem.To))
                                {
                                    strTo = Convert.ToString(mailItem.To);
                                }

                                if (!string.IsNullOrEmpty(mailItem.CC))
                                {
                                    strCC = Convert.ToString(mailItem.CC);
                                }

                                if (!string.IsNullOrEmpty(mailItem.BCC))
                                {
                                    strBCC = Convert.ToString(mailItem.BCC);
                                }

                                strReceivedTime = mailItem.ReceivedTime.ToString("yyyy-MM-dd HH:mm:ss");

                                if (!string.IsNullOrEmpty(mailItem.Body))
                                {
                                    strBody = Convert.ToString(mailItem.Body);
                                }

                                if (!string.IsNullOrEmpty(mailItem.Subject))
                                {
                                    strSubject = Convert.ToString(mailItem.Subject);
                                }

                                if (mailItem.Sensitivity == MyOutlookApp.OlSensitivity.olConfidential)
                                {
                                    strSensitivity = "Urgent";
                                }
                                else
                                {
                                    strSensitivity = "Normal";
                                }

                                strAttachments = mailItem.Attachments.Count.ToString();
                                strEntryID = mailItem.EntryID.ToString();
                                strConversationID = mailItem.ConversationID.ToString();

                                if (strSubject.ToLower().Contains("your fax has been successfully sent") == false)
                                {
                                    objEmail = new EmailDetails();
                                    objEmail.EmailAddress = strEmailAddress;
                                    objEmail.FolderName = FolderNameToSearch;
                                    objEmail.SenderName = strSenderName;
                                    objEmail.SenderEmailAddress = strSenderEmailAddress;
                                    objEmail.To = strTo;
                                    objEmail.Cc = strCC;
                                    objEmail.Bcc = strBCC;
                                    objEmail.ReceivedTime = strReceivedTime;
                                    objEmail.Subject = strSubject;
                                    objEmail.Body = strBody;
                                    objEmail.Priority = strSensitivity;

                                    if (Convert.ToInt32(strAttachments) > 0)
                                    {
                                        objEmail.HasAttachments = "Yes";
                                    }
                                    else
                                    {
                                        objEmail.HasAttachments = "No";
                                    }

                                    objEmail.EntryID = strEntryID;
                                    objEmail.ConversationID = strConversationID;
                                    objEmail.Status = "New";

                                    string[] AccountNumbersList = Regex.Split(strSubject, @"\D+");
                                    string iAccountNumber = "";

                                    foreach (string strAccountNumber in AccountNumbersList)
                                    {
                                        if (!string.IsNullOrEmpty(strAccountNumber))
                                        {
                                            iAccountNumber = strAccountNumber;
                                            break;
                                        }
                                    }

                                    string[] strSplitText = strSubject.Split(new char[0]);
                                    string strNewAccountNumber = strSplitText[strSplitText.Length - 1].Trim();

                                    Boolean isNumeric = false;
                                    try
                                    {
                                        Convert.ToInt32(strNewAccountNumber);
                                        isNumeric = true;
                                    }
                                    catch (Exception)
                                    {
                                        isNumeric = false;
                                    }

                                    if (isNumeric == true)
                                    {
                                        iAccountNumber = strNewAccountNumber;
                                    }

                                    objEmail.AccountNumber = iAccountNumber;

                                    EmailsList.Add(objEmail);
                                }
                            }
                        }

                        return EmailsList;
                    }
                    else
                    {
                        return null;
                    }
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetOutlookEmails:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
        }

        public MyOutlookApp.MAPIFolder GetFolder(MyOutlookApp.MAPIFolder folder)
        {   
            if (folder.Folders.Count == 0)
            {
                Console.WriteLine(folder.FullFolderPath);
            }
            else
            {
                foreach (MyOutlookApp.MAPIFolder subFolder in folder.Folders)
                {
                    if (subFolder.Name.ToUpper().Trim() == FolderNameToSearch.ToUpper().Trim())
                    {
                        FolderToFind = subFolder;
                        break;
                    }
                    else
                    {
                        if (FolderToFind is null)
                        {
                            GetFolder(subFolder);
                        }
                        else 
                        { 
                            break; 
                        }
                    }                        
                }
            }
            return FolderToFind;
        }

        public MyOutlookApp.MAPIFolder GetInboxFolder(MyOutlookApp.MAPIFolder _inboxFolder)
        {
            MyOutlookApp.MAPIFolder InboxFolder = null;
            try
            {
                foreach (MyOutlookApp.MAPIFolder Folder in _inboxFolder.Folders)
                {
                    if (Folder.Name.ToUpper().Trim() == FolderNameToSearch.ToUpper().Trim())
                    {
                        InboxFolder = Folder;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetInboxFolder:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            
            return InboxFolder;
        }

        public void OpenEmail(string strEntryID)
        {
            try
            {
                MyOutlookApp.MailItem mailItem = (MyOutlookApp.MailItem)olNS.GetItemFromID(strEntryID);
                mailItem.Display(true);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in OpenEmail:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButton.OK,MessageBoxImage.Error);
            }
        }
    }
}
