﻿using System;

namespace ECMS_Ryder.Models
{
    internal class EmailBox
    {
        public Int32 EmailBoxId { get; set; }
        public string EmailAddress { get; set; }
        public string FolderName { get; set; }
        public string Status { get; set; }
        public string EntryUser { get; set; }
        public string EntryDateTime { get; set; }
    }
}
