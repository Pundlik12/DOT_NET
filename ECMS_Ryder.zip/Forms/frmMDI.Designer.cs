﻿namespace ECMS_Ryder.Forms
{
    partial class frmMDI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMDI));
            this.label1 = new System.Windows.Forms.Label();
            this.MainFormSplitContainer = new System.Windows.Forms.SplitContainer();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbMailBoxes = new System.Windows.Forms.ComboBox();
            this.btnSwitchAccount = new System.Windows.Forms.Button();
            this.btnGo = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.lblUserName = new System.Windows.Forms.Label();
            this.lblUserRole = new System.Windows.Forms.Label();
            this.btnDisposeEmails = new System.Windows.Forms.Button();
            this.btnDeAllocateEmails = new System.Windows.Forms.Button();
            this.btnDownloads = new System.Windows.Forms.Button();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.btnAssignEmails = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSyncOutlookEmails = new System.Windows.Forms.Button();
            this.btnUserForm = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.MainFormSplitContainer.Panel1.SuspendLayout();
            this.MainFormSplitContainer.Panel2.SuspendLayout();
            this.MainFormSplitContainer.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Rockwell", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1769, 52);
            this.label1.TabIndex = 0;
            this.label1.Text = "Email Case Management System";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MainFormSplitContainer
            // 
            this.MainFormSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainFormSplitContainer.Location = new System.Drawing.Point(0, 52);
            this.MainFormSplitContainer.Name = "MainFormSplitContainer";
            // 
            // MainFormSplitContainer.Panel1
            // 
            this.MainFormSplitContainer.Panel1.Controls.Add(this.panel3);
            this.MainFormSplitContainer.Panel1.Controls.Add(this.panel2);
            this.MainFormSplitContainer.Panel1.Controls.Add(this.btnDisposeEmails);
            this.MainFormSplitContainer.Panel1.Controls.Add(this.btnDeAllocateEmails);
            this.MainFormSplitContainer.Panel1.Controls.Add(this.btnDownloads);
            this.MainFormSplitContainer.Panel1.Controls.Add(this.btnDashboard);
            this.MainFormSplitContainer.Panel1.Controls.Add(this.btnAssignEmails);
            this.MainFormSplitContainer.Panel1.Controls.Add(this.btnExit);
            this.MainFormSplitContainer.Panel1.Controls.Add(this.btnSyncOutlookEmails);
            this.MainFormSplitContainer.Panel1.Controls.Add(this.btnUserForm);
            // 
            // MainFormSplitContainer.Panel2
            // 
            this.MainFormSplitContainer.Panel2.Controls.Add(this.panel1);
            this.MainFormSplitContainer.Size = new System.Drawing.Size(1769, 815);
            this.MainFormSplitContainer.SplitterDistance = 290;
            this.MainFormSplitContainer.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.cmbMailBoxes);
            this.panel3.Controls.Add(this.btnSwitchAccount);
            this.panel3.Controls.Add(this.btnGo);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 110);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(290, 148);
            this.panel3.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(277, 23);
            this.label3.TabIndex = 0;
            this.label3.Text = "Select MailBox";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmbMailBoxes
            // 
            this.cmbMailBoxes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbMailBoxes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMailBoxes.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMailBoxes.FormattingEnabled = true;
            this.cmbMailBoxes.Location = new System.Drawing.Point(4, 37);
            this.cmbMailBoxes.Name = "cmbMailBoxes";
            this.cmbMailBoxes.Size = new System.Drawing.Size(281, 28);
            this.cmbMailBoxes.TabIndex = 1;
            // 
            // btnSwitchAccount
            // 
            this.btnSwitchAccount.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSwitchAccount.BackColor = System.Drawing.Color.Teal;
            this.btnSwitchAccount.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSwitchAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSwitchAccount.ForeColor = System.Drawing.Color.White;
            this.btnSwitchAccount.Location = new System.Drawing.Point(112, 76);
            this.btnSwitchAccount.Name = "btnSwitchAccount";
            this.btnSwitchAccount.Size = new System.Drawing.Size(174, 48);
            this.btnSwitchAccount.TabIndex = 3;
            this.btnSwitchAccount.Text = "Switch Account";
            this.btnSwitchAccount.UseVisualStyleBackColor = false;
            this.btnSwitchAccount.Click += new System.EventHandler(this.btnSwitchAccount_Click);
            // 
            // btnGo
            // 
            this.btnGo.BackColor = System.Drawing.Color.Teal;
            this.btnGo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGo.ForeColor = System.Drawing.Color.White;
            this.btnGo.Location = new System.Drawing.Point(4, 76);
            this.btnGo.Name = "btnGo";
            this.btnGo.Size = new System.Drawing.Size(108, 48);
            this.btnGo.TabIndex = 2;
            this.btnGo.Text = "GO";
            this.btnGo.UseVisualStyleBackColor = false;
            this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.lblUserName);
            this.panel2.Controls.Add(this.lblUserRole);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(290, 110);
            this.panel2.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(286, 33);
            this.label2.TabIndex = 0;
            this.label2.Text = "Logged In User";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblUserName
            // 
            this.lblUserName.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.Location = new System.Drawing.Point(3, 37);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(276, 27);
            this.lblUserName.TabIndex = 1;
            this.lblUserName.Text = "User Name";
            this.lblUserName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblUserRole
            // 
            this.lblUserRole.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserRole.Location = new System.Drawing.Point(3, 68);
            this.lblUserRole.Name = "lblUserRole";
            this.lblUserRole.Size = new System.Drawing.Size(276, 27);
            this.lblUserRole.TabIndex = 2;
            this.lblUserRole.Text = "Log In As ";
            this.lblUserRole.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnDisposeEmails
            // 
            this.btnDisposeEmails.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDisposeEmails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnDisposeEmails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDisposeEmails.Font = new System.Drawing.Font("Microsoft Tai Le", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisposeEmails.ForeColor = System.Drawing.Color.Black;
            this.btnDisposeEmails.Location = new System.Drawing.Point(6, 458);
            this.btnDisposeEmails.Name = "btnDisposeEmails";
            this.btnDisposeEmails.Size = new System.Drawing.Size(281, 60);
            this.btnDisposeEmails.TabIndex = 4;
            this.btnDisposeEmails.Text = "4 -> &Process/Dispose Emails";
            this.btnDisposeEmails.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDisposeEmails.UseVisualStyleBackColor = false;
            this.btnDisposeEmails.Click += new System.EventHandler(this.btnDisposeEmails_Click);
            // 
            // btnDeAllocateEmails
            // 
            this.btnDeAllocateEmails.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDeAllocateEmails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnDeAllocateEmails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeAllocateEmails.Font = new System.Drawing.Font("Microsoft Tai Le", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeAllocateEmails.ForeColor = System.Drawing.Color.Black;
            this.btnDeAllocateEmails.Location = new System.Drawing.Point(6, 392);
            this.btnDeAllocateEmails.Name = "btnDeAllocateEmails";
            this.btnDeAllocateEmails.Size = new System.Drawing.Size(281, 60);
            this.btnDeAllocateEmails.TabIndex = 3;
            this.btnDeAllocateEmails.Text = "3 -> &DeAllocate Emails";
            this.btnDeAllocateEmails.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDeAllocateEmails.UseVisualStyleBackColor = false;
            this.btnDeAllocateEmails.Click += new System.EventHandler(this.btnDeAllocateEmails_Click);
            // 
            // btnDownloads
            // 
            this.btnDownloads.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDownloads.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnDownloads.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDownloads.Font = new System.Drawing.Font("Microsoft Tai Le", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDownloads.ForeColor = System.Drawing.Color.Black;
            this.btnDownloads.Location = new System.Drawing.Point(6, 524);
            this.btnDownloads.Name = "btnDownloads";
            this.btnDownloads.Size = new System.Drawing.Size(281, 60);
            this.btnDownloads.TabIndex = 5;
            this.btnDownloads.Text = "5 -> &Report Downloads";
            this.btnDownloads.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDownloads.UseVisualStyleBackColor = false;
            this.btnDownloads.Click += new System.EventHandler(this.btnDownloads_Click);
            // 
            // btnDashboard
            // 
            this.btnDashboard.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDashboard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDashboard.Font = new System.Drawing.Font("Microsoft Tai Le", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashboard.ForeColor = System.Drawing.Color.Black;
            this.btnDashboard.Location = new System.Drawing.Point(6, 590);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(281, 60);
            this.btnDashboard.TabIndex = 6;
            this.btnDashboard.Text = "6 -> Summary Report";
            this.btnDashboard.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDashboard.UseVisualStyleBackColor = false;
            this.btnDashboard.Click += new System.EventHandler(this.btnDashboard_Click);
            // 
            // btnAssignEmails
            // 
            this.btnAssignEmails.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAssignEmails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnAssignEmails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAssignEmails.Font = new System.Drawing.Font("Microsoft Tai Le", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAssignEmails.ForeColor = System.Drawing.Color.Black;
            this.btnAssignEmails.Location = new System.Drawing.Point(6, 326);
            this.btnAssignEmails.Name = "btnAssignEmails";
            this.btnAssignEmails.Size = new System.Drawing.Size(281, 60);
            this.btnAssignEmails.TabIndex = 2;
            this.btnAssignEmails.Text = "2 -> Allocate &Emails";
            this.btnAssignEmails.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAssignEmails.UseVisualStyleBackColor = false;
            this.btnAssignEmails.Click += new System.EventHandler(this.btnAssignEmails_Click);
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Verdana", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(6, 722);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(281, 85);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "8 -> &Log Out";
            this.btnExit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSyncOutlookEmails
            // 
            this.btnSyncOutlookEmails.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSyncOutlookEmails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnSyncOutlookEmails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSyncOutlookEmails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSyncOutlookEmails.Font = new System.Drawing.Font("Microsoft Tai Le", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSyncOutlookEmails.ForeColor = System.Drawing.Color.Black;
            this.btnSyncOutlookEmails.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSyncOutlookEmails.Location = new System.Drawing.Point(6, 260);
            this.btnSyncOutlookEmails.Name = "btnSyncOutlookEmails";
            this.btnSyncOutlookEmails.Size = new System.Drawing.Size(281, 60);
            this.btnSyncOutlookEmails.TabIndex = 1;
            this.btnSyncOutlookEmails.Text = "1 -> &Sync Outlook Emails";
            this.btnSyncOutlookEmails.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSyncOutlookEmails.UseVisualStyleBackColor = false;
            this.btnSyncOutlookEmails.Click += new System.EventHandler(this.btnSyncOutlookEmails_Click);
            // 
            // btnUserForm
            // 
            this.btnUserForm.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUserForm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnUserForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUserForm.Font = new System.Drawing.Font("Microsoft Tai Le", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUserForm.ForeColor = System.Drawing.Color.Black;
            this.btnUserForm.Location = new System.Drawing.Point(6, 656);
            this.btnUserForm.Name = "btnUserForm";
            this.btnUserForm.Size = new System.Drawing.Size(281, 60);
            this.btnUserForm.TabIndex = 7;
            this.btnUserForm.Text = "7 -> &Admin Center";
            this.btnUserForm.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUserForm.UseVisualStyleBackColor = false;
            this.btnUserForm.Click += new System.EventHandler(this.btnUserForm_Click);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1475, 815);
            this.panel1.TabIndex = 0;
            // 
            // frmMDI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1769, 867);
            this.Controls.Add(this.MainFormSplitContainer);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMDI";
            this.Text = "ECMS Tool - Ryder";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMDI_FormClosing);
            this.Load += new System.EventHandler(this.frmMDI_Load);
            this.MainFormSplitContainer.Panel1.ResumeLayout(false);
            this.MainFormSplitContainer.Panel2.ResumeLayout(false);
            this.MainFormSplitContainer.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.SplitContainer MainFormSplitContainer;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnUserForm;
        private System.Windows.Forms.Button btnSyncOutlookEmails;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblUserRole;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Button btnAssignEmails;
        private System.Windows.Forms.ComboBox cmbMailBoxes;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnGo;
        private System.Windows.Forms.Button btnDownloads;
        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.Button btnDeAllocateEmails;
        private System.Windows.Forms.Button btnDisposeEmails;
        private System.Windows.Forms.Button btnSwitchAccount;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
    }
}