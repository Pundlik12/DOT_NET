﻿
namespace ECMS_Ryder.Models
{
    public enum UserRole
    {
        Admin,
        Associate
    }
}
