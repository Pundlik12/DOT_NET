﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;
using InventoryManagement.DataAccessLogic;

namespace InventoryManagement
{
    public partial class frmCompany : Form
    {
        CompanyModel objCompanyModel = null;
        IGenericRepository<CompanyModel> objCompanyDal = null;

        public frmCompany()
        {
            InitializeComponent();
        }

        private void frmCompany_Load(object sender, EventArgs e)
        {
            objCompanyDal = new CompanyDAL();
            ClearFields();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {            
            if (txtName.Text.Trim() == "")
            {
                txtName.Focus();
                MessageBox.Show("Please enter name.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtAddress.Text.Trim() == "")
            {
                txtAddress.Focus();
                MessageBox.Show("Please enter address.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtPINCode.Text.Trim() == "")
            {
                txtPINCode.Focus();
                MessageBox.Show("Please enter pin code.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtCity.Text.Trim() == "")
            {
                txtCity.Focus();
                MessageBox.Show("Please enter city.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtState.Text.Trim() == "")
            {
                txtState.Focus();
                MessageBox.Show("Please enter status.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtMobile.Text.Trim() == "")
            {
                txtMobile.Focus();
                MessageBox.Show("Please enter mobile.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtEmail.Text.Trim() == "")
            {
                txtEmail.Focus();
                MessageBox.Show("Please enter email.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtGST.Text.Trim() == "")
            {
                txtGST.Focus();
                MessageBox.Show("Please enter gst no.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                Cursor = Cursors.WaitCursor;
                objCompanyModel = new CompanyModel();
                objCompanyModel.Name = txtName.Text.Trim();
                objCompanyModel.Address = txtAddress.Text.Trim();
                objCompanyModel.PinCode = txtPINCode.Text.Trim();
                objCompanyModel.City = txtCity.Text.Trim();
                objCompanyModel.State = txtState.Text.Trim();
                objCompanyModel.Mobile = txtMobile.Text.Trim();
                objCompanyModel.Email = txtEmail.Text.Trim();
                objCompanyModel.Mobile = txtMobile.Text.Trim();
                objCompanyModel.GSTNo = txtGST.Text.Trim();
                objCompanyModel.CreatedBy = common.strUserEmail;

                if (btnSave.Text == "Save")
                {
                    objCompanyDal.Add(objCompanyModel);
                    ClearFields();
                    //MessageBox.Show("Company saved successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    objCompanyModel.Code = Convert.ToInt32(txtCode.Text);
                    objCompanyDal.Update(objCompanyModel);
                    ClearFields();
                    //MessageBox.Show("Company updated successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                Cursor = Cursors.Default;
            }
        }

        private void ClearFields()
        {
            txtCode.Text = "";
            txtName.Text = "";
            txtAddress.Text = "";
            txtPINCode.Text = "";
            txtCity.Text = "";
            txtState.Text = "";
            txtMobile.Text = "";
            txtEmail.Text = "";
            txtGST.Text = "";
            btnSave.Text = "Save";
            dgvData.Enabled = true;
            txtName.Select();
            DisplayData();
        }

        private void DisplayData()
        {
            List<CompanyModel> lstFilteredData = null;
            List<CompanyModel> lstFilteredData1 = null;
            List<CompanyModel> lstFilteredData2 = null;

            List<CompanyModel> lstData = objCompanyDal.GetAll();

            if (txtNameSearch.Text != "")
            {
                lstFilteredData = lstData.Where(x => x.Name.Contains(txtNameSearch.Text)).ToList();
            }
            else
            {
                lstFilteredData = lstData;
            }

            if (txtCitySearch.Text != "")
            {
                lstFilteredData1 = lstFilteredData.Where(x => x.City.Contains(txtCitySearch.Text)).ToList();
            }
            else
            {
                lstFilteredData1 = lstFilteredData;
            }

            if (txtStateSearch.Text != "")
            {
                lstFilteredData2 = lstFilteredData1.Where(x => x.State.Contains(txtStateSearch.Text)).ToList();
            }
            else
            {
                lstFilteredData2 = lstFilteredData1;
            }

            dgvData.DataSource = lstFilteredData2;
        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (e.ColumnIndex == 0)
                {
                    txtCode.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Code"].Value);
                    txtName.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["CompanyName"].Value);
                    txtAddress.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Address"].Value);
                    txtPINCode.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["PINCode"].Value);
                    txtCity.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["City"].Value);
                    txtState.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["State"].Value);
                    txtMobile.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Mobile"].Value);
                    txtEmail.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Email"].Value);
                    txtGST.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["GSTNo"].Value);

                    btnSave.Text = "Update";
                    dgvData.Enabled = false;
                }
                if (e.ColumnIndex == 1)
                {
                    if (MessageBox.Show("Do you want to delete?", common.strProjectTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        Int32 code = Convert.ToInt32(dgvData.Rows[e.RowIndex].Cells["Code"].Value);
                        objCompanyDal.Delete(code);

                        ClearFields();

                        //MessageBox.Show("Company deleted successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtNameSearch_TextChanged(object sender, EventArgs e)
        {
            DisplayData();
        }

        private void txtCitySearch_TextChanged(object sender, EventArgs e)
        {
            DisplayData();
        }

        private void txtStateSearch_TextChanged(object sender, EventArgs e)
        {
            DisplayData();
        }
    }
}
