﻿
namespace InventoryManagement.BusinessLogic
{
    public class Challan
    {
        public string CustomerCode { get; set; }
        public string CustomerName { get; set; }
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public string Description { get; set; }
        public double Rate { get; set; }
        public double Qty { get; set; }
        public double GSTPercent { get; set; }
        public double GSTAmount { get; set; }
        public double LineTotal { get; set; }
    }
}
