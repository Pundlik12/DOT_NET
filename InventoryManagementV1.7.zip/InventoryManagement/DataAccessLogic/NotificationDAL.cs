﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using DocumentFormat.OpenXml.Office2010.PowerPoint;
using InventoryManagement.BusinessLogic;

namespace InventoryManagement.DataAccessLogic
{
    public class NotificationDAL : IGenericRepository<NotificationModel>
    {
        public NotificationDAL()
        {
            DatabaseContext.CreateConnection();
        }

        public List<NotificationModel> GetAll()
        {
            List<NotificationModel> lstData = new List<NotificationModel>();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT NotificationID,EmployeeID,Meassage,Status,CreatedBy,CreatedDateTime FROM Notification";
                
                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    NotificationModel objNotification = new NotificationModel();
                    objNotification.NotificationID = Convert.ToString(DatabaseContext.dbdr["NotificationID"]);
                    objNotification.EmployeeID = Convert.ToString(DatabaseContext.dbdr["EmployeeID"]);
                    objNotification.Meassage = Convert.ToString(DatabaseContext.dbdr["Meassage"]);
                    objNotification.Status = Convert.ToString(DatabaseContext.dbdr["Status"]);
                    objNotification.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objNotification.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objNotification);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public List<NotificationModel> GetByDates(string strFromDate, string strToDate)
        {
            throw new NotImplementedException();
        }

        public NotificationModel GetByID(Int32 NotificationID)
        {
            NotificationModel objNotification = new NotificationModel();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT NotificationID,EmployeeID,Meassage,Status,CreatedBy,CreatedDateTime FROM Notification WHERE NotificationID = " + NotificationID;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    objNotification.NotificationID = Convert.ToString(DatabaseContext.dbdr["NotificationID"]);
                    objNotification.EmployeeID = Convert.ToString(DatabaseContext.dbdr["EmployeeID"]);
                    objNotification.Meassage = Convert.ToString(DatabaseContext.dbdr["Meassage"]);
                    objNotification.Status = Convert.ToString(DatabaseContext.dbdr["Status"]);
                    objNotification.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objNotification.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return objNotification;
        }

        public void Add(NotificationModel objNotification)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "INSERT INTO LeaveRequest (EmployeeID,Meassage,Status,CreatedBy,CreatedDateTime) VALUES(@EmployeeID,@Meassage,@Status,@CreatedBy,@CreatedDateTime)";
                
                DatabaseContext.dbcmd.Parameters.AddWithValue("EmployeeID", objNotification.EmployeeID);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Meassage", objNotification.Meassage);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Status", objNotification.Status);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objNotification.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Update(NotificationModel objNotification)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "UPDATE Notification SET EmployeeID = @EmployeeID,Meassage = @Meassage,Status = @Status, CreatedBy = @CreatedBy, CreatedDateTime = @CreatedDateTime WHERE NotificationID = " + objNotification.NotificationID;

                DatabaseContext.dbcmd.Parameters.AddWithValue("EmployeeID", objNotification.EmployeeID);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Meassage", objNotification.Meassage);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Status", objNotification.Status);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objNotification.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Delete(Int32 NotificationID)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "DELETE FROM Notification WHERE NotificationID = " + NotificationID;
                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
