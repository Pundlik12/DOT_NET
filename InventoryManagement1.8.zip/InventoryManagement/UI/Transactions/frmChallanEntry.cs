﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;
using InventoryManagement.DataAccessLogic;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;

namespace InventoryManagement
{
    public partial class frmChallanEntry : Form
    {
        int Counter = 0;
        IGenericRepository<CustomerModel> objCustomerDal = null;
        IGenericRepository<CustomerItemModel> objCustomerItemDal = null;
        IGenericRepository<ChallanHeaderModel> objChallanDal = null;

        List<CustomerModel> lstCustomer = null;
        List<CustomerItemModel> objCustomerItemList = null;
        List<CustomerItemModel> FilteredCustmerItems = null;
        
        public frmChallanEntry()
        {
            InitializeComponent();
        }

        private void frmChallanEntry_Load(object sender, EventArgs e)
        {
            objCustomerDal = new CustomerDAL();
            objCustomerItemDal = new CustomerItemDAL();
            objChallanDal = new ChallanDAL();

            objCustomerItemList = objCustomerItemDal.GetAll();

            Fill_Customer_Dropdowns();

            txtChallanNo.Text = "INV/" + DateTime.Now.ToString("yyyy") + "/";
            txtGrandTotal.Text = "0";
            txtTotalGST.Text = "0";
            cboCustomer.SelectedIndex = -1;
            cboCustomer.Select();
        }

        private void Fill_Customer_Dropdowns()
        {
            lstCustomer = new List<CustomerModel>();
            lstCustomer = objCustomerDal.GetAll();

            cboCustomer.DataSource = lstCustomer;
            cboCustomer.DisplayMember = "Name";
            cboCustomer.ValueMember = "Code";
        }

        private void btnAddItem_Click(object sender, EventArgs e)
        {
            if (Convert.ToString(cboCustomer.SelectedValue) == "")
            {
                cboCustomer.Select();
                MessageBox.Show("Please select customer.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (Convert.ToString(cboItem.SelectedValue) == "")
            {
                cboItem.Select();
                MessageBox.Show("Please select item.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtQty.Text == "")
            {
                txtQty.Select();
                MessageBox.Show("Please enter qty.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtRate.Text == "")
            {
                txtRate.Select();
                MessageBox.Show("Please select item.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                string ItemCode = Convert.ToString(cboItem.SelectedValue);
                string ItemName = Convert.ToString(cboItem.Text);

                double dblRate = Convert.ToDouble(txtRate.Text);
                double dblGstPercent = Convert.ToDouble(txtGSTPercent.Text);
                double dblQty = Convert.ToDouble(txtQty.Text);

                double dblAmount = dblQty * dblRate;
                double dblGSTAmount = dblAmount * (dblGstPercent / 100);
                double dblLineTotal = dblAmount + dblGSTAmount;
                
                double dblGrandTotal = Convert.ToDouble(txtGrandTotal.Text);
                txtGrandTotal.Text = Convert.ToString(dblGrandTotal + dblLineTotal);

                double dblGstTotal = Convert.ToDouble(txtTotalGST.Text);
                txtTotalGST.Text = Convert.ToString(dblGstTotal + dblGSTAmount);

                dgvCartItems.Rows.Add("", ItemCode, ItemName, dblRate, dblQty, dblGstPercent, dblGSTAmount, dblLineTotal);
                
                cboItem.SelectedIndex = -1;
                txtRate.Text = "";
                txtQty.Text = "";
                txtGSTPercent.Text = "";
                txtGSTAmount.Text = "";
                txtAmount.Text = "";
                cboItem.Select();
            }
        }

        private void cboItem_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var rateList = FilteredCustmerItems.Where(x => x.ItemCode == Convert.ToString(cboItem.SelectedValue)).ToList();

                if (rateList.Count > 0)
                {
                    txtRate.Text = rateList[0].Rate;
                    txtGSTPercent.Text = rateList[0].GSTPercent;
                }
            }
            catch (Exception)
            {
            }
        }

        private void txtQty_TextChanged(object sender, EventArgs e)
        {
            if (txtQty.Text.Trim() != "" && txtRate.Text.Trim() != "")
            {
                try
                {
                    double dblAmount = Convert.ToDouble(txtRate.Text) * Convert.ToDouble(txtQty.Text);
                    double dblGstPercent = Convert.ToDouble(txtGSTPercent.Text);
                    double dblGst = (dblAmount * (dblGstPercent / 100));
                    
                    txtAmount.Text = Convert.ToString(dblAmount);
                    txtGSTAmount.Text = Convert.ToString(dblGst);
                }
                catch (Exception)
                {
                    txtAmount.Text = "0";
                    txtGSTAmount.Text = "0";
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cboCustomer_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cboCustomer.SelectedValue != null)
            {
                if (Counter == 3)
                {
                    FilteredCustmerItems = objCustomerItemList.Where(x => x.CustomerCode == Convert.ToString(cboCustomer.SelectedValue)).ToList();
                    cboItem.DataSource = FilteredCustmerItems;
                    cboItem.ValueMember = "ItemCode";
                    cboItem.DisplayMember = "ItemName";
                    cboItem.SelectedIndex = -1;
                    txtRate.Text = "";
                    txtGSTPercent.Text = "";
                }
                else
                {
                    Counter = Counter + 1;
                }
            }       
        }

        private void dgvCartItems_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (e.ColumnIndex == 0)
                {
                    double dblAmount = Convert.ToDouble(dgvCartItems.Rows[e.RowIndex].Cells["Amount"].Value);
                    double dblGrandTotal = Convert.ToDouble(txtGrandTotal.Text);
                    txtGrandTotal.Text = Convert.ToString(dblGrandTotal - dblAmount);

                    double dblGstAmount = Convert.ToDouble(dgvCartItems.Rows[e.RowIndex].Cells["GSTAmount"].Value);
                    double dblGstTotal = Convert.ToDouble(txtTotalGST.Text);
                    txtTotalGST.Text = Convert.ToString(dblGstTotal - dblGstAmount);

                    dgvCartItems.Rows.RemoveAt(e.RowIndex);
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (Convert.ToString(cboCustomer.SelectedValue) == "")
            {
                cboCustomer.Select();
                MessageBox.Show("Please select customer.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (dgvCartItems.Rows.Count <= 0)
            {
                cboItem.Select();
                MessageBox.Show("Please add items first.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                ChallanHeaderModel ObjChallanHeader = new ChallanHeaderModel();
                
                ObjChallanHeader.ChallanNo = txtChallanNo.Text;
                ObjChallanHeader.ChallanDate = Convert.ToDateTime(dtpChallanDate.Text);
                ObjChallanHeader.CustomerCode = Convert.ToInt32(cboCustomer.SelectedValue);
                ObjChallanHeader.TotalGST = Convert.ToDouble(txtTotalGST.Text);
                ObjChallanHeader.TotalAmount = Convert.ToDouble(txtGrandTotal.Text);
                ObjChallanHeader.CreatedBy = common.strUserEmail;

                List<ChallanDetailsModel> ObjChallanDetailsList = new List<ChallanDetailsModel>();

                foreach (DataGridViewRow item in dgvCartItems.Rows)
                {
                    ChallanDetailsModel ObjChallanDetail = new ChallanDetailsModel();
                    
                    ObjChallanDetail.ItemCode = Convert.ToInt32(item.Cells["ItemCode"].Value);
                    ObjChallanDetail.Qty = Convert.ToInt32(item.Cells["Qty"].Value);
                    ObjChallanDetail.Rate = Convert.ToInt32(item.Cells["Rate"].Value);
                    ObjChallanDetail.GST = Convert.ToInt32(item.Cells["GSTAmount"].Value);
                    ObjChallanDetail.Amount = Convert.ToInt32(item.Cells["Amount"].Value);
                    
                    ObjChallanDetailsList.Add(ObjChallanDetail);
                }
                ObjChallanHeader.ChallanDetails = ObjChallanDetailsList;

                objChallanDal.Add(ObjChallanHeader);

                foreach (DataGridViewRow item in dgvCartItems.Rows)
                {
                    dgvCartItems.Rows.RemoveAt(0);
                }

                cboCustomer.SelectedIndex = -1;

                MessageBox.Show("Challan created successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
