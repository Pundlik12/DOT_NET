﻿using System;

namespace ECMS_Ryder.Models
{
    internal class DispositionDetails
    {
        public Int32 DispositionDetailsId { get; set; }
        public Int32 EmailDetailsId { get; set; }
        public string StartTime { get; set; }
        public string Category { get; set; }
        public string SubCategory { get; set; }
        public string Inclusions { get; set; }
        public string Dependency { get; set; }
        public string ManualFollowUp { get; set; }
        public string Comments { get; set; }
        public string EntryUser { get; set; }
        public string EntryDateTime { get; set; }
    }
}
