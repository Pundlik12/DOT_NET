﻿using System;
using System.Data;
using System.Data.OleDb;
using ECMS_Ryder.Models;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ECMS_Ryder.Repositories
{
    interface iEmailBoxRepository
    {
        List<EmailBox> GetAllEmailBoxes();
        EmailBox GetEmailBoxByID(string EmailBoxID);
        Boolean CheckEmailBoxExists(string EmailAddress);
        void CreateEmailBox(EmailBox user);
        void UpdateEmailBox(EmailBox user);
        void DeleteEmailBox(Int32 EmailBoxId);
    }

    internal class EmailBoxRepository : iEmailBoxRepository
    {
        private readonly string strConnectionString = "";

        public EmailBoxRepository(string _strConnectionString)
        {
            strConnectionString = _strConnectionString;
        }

        public List<EmailBox> GetAllEmailBoxes()
        {
            List<EmailBox> emailBoxes = new List<EmailBox>();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "GetAllEmailBoxes";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;

                    OleDbDataReader OleDbDataReader = cmd.ExecuteReader();

                    while (OleDbDataReader.Read())
                    {
                        EmailBox emailBoxDetails = new EmailBox();
                        emailBoxDetails.EmailBoxId = Convert.ToInt32(OleDbDataReader["EmailBoxId"]);
                        emailBoxDetails.EmailAddress = Convert.ToString(OleDbDataReader["EmailAddress"]);
                        emailBoxDetails.FolderName = Convert.ToString(OleDbDataReader["FolderName"]);

                        if (Convert.ToString(OleDbDataReader["Status"]) == UserStatus.Active.ToString())
                        {
                            emailBoxDetails.Status = UserStatus.Active.ToString();
                        }
                        else
                        {
                            emailBoxDetails.Status = UserStatus.InActive.ToString();
                        }

                        emailBoxDetails.EntryUser = Convert.ToString(OleDbDataReader["EntryUser"]);
                        emailBoxDetails.EntryDateTime = Convert.ToString(OleDbDataReader["EntryDateTime"]);

                        emailBoxes.Add(emailBoxDetails);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetAllEmailBoxes:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                emailBoxes = null;
            }

            return emailBoxes;
        }

        public EmailBox GetEmailBoxByID(string EmailBoxID)
        {
            EmailBox emailBoxDetails = new EmailBox();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "GetEmailBoxByID";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@EmailBoxID", EmailBoxID);

                    OleDbDataReader OleDbDataReader = cmd.ExecuteReader();

                    while (OleDbDataReader.Read())
                    {
                        emailBoxDetails.EmailBoxId = Convert.ToInt32(OleDbDataReader["EmailBoxId"]);
                        emailBoxDetails.EmailAddress = Convert.ToString(OleDbDataReader["EmailAddress"]);
                        emailBoxDetails.FolderName = Convert.ToString(OleDbDataReader["FolderName"]);

                        if (Convert.ToString(OleDbDataReader["Status"]) == UserStatus.Active.ToString())
                        {
                            emailBoxDetails.Status = UserStatus.Active.ToString();
                        }
                        else
                        {
                            emailBoxDetails.Status = UserStatus.InActive.ToString();
                        }

                        emailBoxDetails.EntryUser = Convert.ToString(OleDbDataReader["EntryUser"]);
                        emailBoxDetails.EntryDateTime = Convert.ToString(OleDbDataReader["EntryDateTime"]);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetEmailBoxByID:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                emailBoxDetails = null;
            }

            return emailBoxDetails;
        }

        public bool CheckEmailBoxExists(string strEmailAddress)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "CheckEmailBoxExists";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@EmailAddress", strEmailAddress);
                    
                    OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter(cmd);
                    DataTable dataTable = new DataTable();

                    oleDbDataAdapter.Fill(dataTable);
                    
                    if (dataTable.Rows.Count > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in CheckEmailBoxExists:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        public void CreateEmailBox(EmailBox emailBox)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "CreateEmailBox";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@EmailAddress", emailBox.EmailAddress);
                    cmd.Parameters.AddWithValue("@FolderName", emailBox.FolderName);
                    cmd.Parameters.AddWithValue("@Status", emailBox.Status);
                    cmd.Parameters.AddWithValue("@EntryUser", emailBox.EntryUser);
                    cmd.Parameters.AddWithValue("@EntryDateTime", emailBox.EntryDateTime);

                    cmd.ExecuteNonQuery();

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in CreateEmailBox:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void UpdateEmailBox(EmailBox emailBox)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "UpdateEmailBox";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@EmailAddress", emailBox.EmailAddress);
                    cmd.Parameters.AddWithValue("@FolderName", emailBox.FolderName);
                    cmd.Parameters.AddWithValue("@Status", emailBox.Status);
                    cmd.Parameters.AddWithValue("@EntryUser", emailBox.EntryUser);
                    cmd.Parameters.AddWithValue("@EntryDateTime", emailBox.EntryDateTime);
                    cmd.Parameters.AddWithValue("@EmailBoxId", emailBox.EmailBoxId);

                    cmd.ExecuteNonQuery();

                    connection.Close();
                }                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in UpdateEmailBox:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void DeleteEmailBox(int EmailBoxId)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "DeleteEmailBox";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@EmailBoxId", EmailBoxId);

                    cmd.ExecuteNonQuery();

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in DeleteEmailBox:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
