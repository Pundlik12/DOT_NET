﻿using System;
using System.Windows.Forms;
using ECMS_Ryder.Models;
using ECMS_Ryder.Repositories;
using ECMS_Ryder.HelperClasses;
using System.Data;
using System.Linq;
using System.Collections.Generic;

namespace ECMS_Ryder.Forms
{
    public partial class frmDispositionForm : Form
    {
        private readonly EmailDetailsRepository objEmailDetailsRepository;
        private readonly MasterDetailsRepository objMasterDetailsRepository;
        private readonly clsOutlookLayer objOutlook;
        
        Int32 iTransactionId = 0;
        string strTransactionStartTime = "";
        Timer tmr = null;
        DateTime dtStartDate;
        string strEntryId;

        List<EmailDetails> pendingEmailDetailsList = null;
        List<CategoryDetails> categories = null;
        List<SubCategoryDetails> subCategories = null;
        List<InclusionDetails> inclusions = null;

        public frmDispositionForm()
        {
            InitializeComponent();

            objOutlook = new clsOutlookLayer();
            objEmailDetailsRepository = new EmailDetailsRepository(clsDBConnection.strConnectionString);
            objMasterDetailsRepository = new MasterDetailsRepository(clsDBConnection.strConnectionString);
        }

        private void frmDispositionForm_Load(object sender, EventArgs e)
        {
            tmr = new Timer();
            tmr.Interval = 1000;
            tmr.Tick += new EventHandler(tmr_Tick);
            tmr.Enabled = false;

            categories = objMasterDetailsRepository.GetAllCategories();
            cmbCategory.DataSource = categories;
            cmbCategory.DisplayMember = "Category";
            cmbCategory.ValueMember = "CategoryId";

            subCategories = objMasterDetailsRepository.GetAllSubCategories();
            cmbSubCategory.DataSource = subCategories;
            cmbSubCategory.DisplayMember = "SubCategory";
            cmbSubCategory.ValueMember = "SubCategoryId";

            LoadData();
            ClearAll();
            cmbSearchCriteria.SelectedIndex = 0;
        }

        public void LoadData()
        {
            List<EmailDetails> emailDetailsList = objEmailDetailsRepository.GetAssignedEmails();
            pendingEmailDetailsList = (from emails in emailDetailsList where emails.Status != "Completed" select emails).OrderBy(x => x.ReceivedTime).ToList();
        }

        public void ClearAll()
        {
            if (pendingEmailDetailsList.Count == 0)
            {
                LoadData();
            }

            dgvEmails.DataSource = null;
            dgvEmails.DataSource = pendingEmailDetailsList;
            lblEmailsCount.Text = pendingEmailDetailsList.Count.ToString();

            strEntryId = "";
            iTransactionId = 0;
            strTransactionStartTime = "";
            txtSubjectLine.Text = string.Empty;
            txtComments.Text = string.Empty;
            cmbCategory.SelectedIndex = -1;
            cmbSubCategory.SelectedIndex = -1;
            EmailsGroupBox.Enabled = true;
            DispositionGroupBox.Enabled = false;
        }

        private void txtSearchText_TextChanged(object sender, EventArgs e)
        {
            if (cmbSearchCriteria.SelectedIndex == 0)
            {
                MessageBox.Show("Select search criteria first and then try.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                cmbSearchCriteria.Focus();
                return;
            }

            this.Cursor = Cursors.WaitCursor;

            List<EmailDetails> filteredEmails = new List<EmailDetails>();

            if (cmbSearchCriteria.Text == "SenderName")
            {
                filteredEmails = (from emails in pendingEmailDetailsList where emails.SenderName.ToLower().Contains(txtSearchText.Text.Trim()) select emails).ToList();
            }
            else if (cmbSearchCriteria.Text == "To")
            {
                filteredEmails = (from emails in pendingEmailDetailsList where emails.To.ToLower().Contains(txtSearchText.Text.Trim()) select emails).ToList();
            }
            else if (cmbSearchCriteria.Text == "Cc")
            {
                filteredEmails = (from emails in pendingEmailDetailsList where emails.Cc.ToLower().Contains(txtSearchText.Text.Trim()) select emails).ToList();
            }
            else if (cmbSearchCriteria.Text == "Bcc")
            {
                filteredEmails = (from emails in pendingEmailDetailsList where emails.Bcc.ToLower().Contains(txtSearchText.Text.Trim()) select emails).ToList();
            }
            else if (cmbSearchCriteria.Text == "Subject")
            {
                filteredEmails = (from emails in pendingEmailDetailsList where emails.Subject.ToLower().Contains(txtSearchText.Text.Trim()) select emails).ToList();
            }
            else if (cmbSearchCriteria.Text == "Priority")
            {
                filteredEmails = (from emails in pendingEmailDetailsList where emails.Priority.ToLower().Contains(txtSearchText.Text.Trim()) select emails).ToList();
            }
            else if (cmbSearchCriteria.Text == "HasAttachments")
            {
                filteredEmails = (from emails in pendingEmailDetailsList where emails.HasAttachments.ToLower().Contains(txtSearchText.Text.Trim()) select emails).ToList();
            }
            else
            {
                filteredEmails = pendingEmailDetailsList;
            }

            dgvEmails.DataSource = filteredEmails.OrderBy(x => x.ReceivedTime).ToList();
            lblEmailsCount.Text = filteredEmails.Count.ToString();

            this.Cursor = Cursors.Default;
        }

        private void dgvEmails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvEmails.Rows.Count > 0 && e.RowIndex >= 0)
            {
                strEntryId = Convert.ToString(dgvEmails.Rows[e.RowIndex].Cells["EntryID"].Value);
                iTransactionId = Convert.ToInt32(dgvEmails.Rows[e.RowIndex].Cells["EmailDetailsID"].Value);
                txtSubjectLine.Text = Convert.ToString(dgvEmails.Rows[e.RowIndex].Cells["Subject"].Value);
                strTransactionStartTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                EmailsGroupBox.Enabled = false;
                DispositionGroupBox.Enabled = true;
                cmbCategory.Select();
                
                StartTimer();
            }
        }

        private void StartTimer()
        {
            lblTimer.Text = "00:00:00";
            tmr.Enabled = true;            
            tmr.Start();

            dtStartDate = DateTime.Now;
        }

        private void StopTimer()
        {
            tmr.Stop();
            tmr.Enabled = false;
            lblTimer.Text = "00:00:00";
        }

        void tmr_Tick(object sender, EventArgs e)
        {
            DateTime dtEndDate = DateTime.Now;
            TimeSpan sp = dtEndDate.Subtract(dtStartDate);

            string strElapsedTime = sp.ToString();
            lblTimer.Text = Convert.ToDateTime(strElapsedTime).ToString("HH:mm:ss");
        }

        private void cmbCategory_Leave(object sender, EventArgs e)
        {
            if (cmbCategory.Text != "Select")
            {
                var subCategoriesList = (from myRow in subCategories where myRow.CategoryId == Convert.ToInt32(cmbCategory.SelectedValue) select myRow).ToList();

                cmbSubCategory.DataSource = null;
                cmbSubCategory.DisplayMember = "SubCategory";
                cmbSubCategory.ValueMember = "SubCategoryId";
                cmbSubCategory.DataSource = subCategoriesList;
                cmbSubCategory.SelectedIndex = -1;
            }
        }
                
        private void cmbSubCategory_Leave(object sender, EventArgs e)
        {
            //if (cmbSubCategory.Text != "Select")
            //{
            //    var inclusionsList = (from myRow in inclusions where myRow.SubCategoryId == Convert.ToInt32(cmbSubCategory.SelectedValue) select myRow).ToList();
            //}
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (cmbCategory.SelectedIndex == -1)
            {
                cmbCategory.Focus();
                MessageBox.Show("Please select category.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            if (cmbSubCategory.SelectedIndex == -1)
            {
                cmbSubCategory.Focus();
                MessageBox.Show("Please select subcategory.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            this.Cursor = Cursors.WaitCursor;
            
            DispositionGroupBox.Enabled = false;

            DispositionDetails dispositionDetails = new DispositionDetails();
            dispositionDetails.EmailDetailsId = iTransactionId;
            dispositionDetails.StartTime = strTransactionStartTime;
            dispositionDetails.Category = cmbCategory.Text;
            dispositionDetails.SubCategory = cmbSubCategory.Text;
            dispositionDetails.Inclusions = "";
            dispositionDetails.Dependency = "";
            dispositionDetails.ManualFollowUp = "";
            dispositionDetails.Comments = txtComments.Text.Trim();
            dispositionDetails.EntryDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            objEmailDetailsRepository.DisposeEmails(dispositionDetails);

            var itemToRemove = pendingEmailDetailsList.Single(r => r.EmailDetailsId == iTransactionId);
            pendingEmailDetailsList.Remove(itemToRemove);

            ClearAll();
            StopTimer();

            MessageBox.Show("Data submitted sucessfully.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Information); 
            
            this.Cursor = Cursors.Default;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearAll();
            StopTimer();
        }

        private void frmDispositionForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(DispositionGroupBox.Enabled == true)
            {
                e.Cancel = true;
                MessageBox.Show("Please complete the transaction or cancel the transaction.", "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                e.Cancel = false;
            }
        }

        private void lblOpenEmail_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            objOutlook.OpenEmail(strEntryId);
        }
    }
}
