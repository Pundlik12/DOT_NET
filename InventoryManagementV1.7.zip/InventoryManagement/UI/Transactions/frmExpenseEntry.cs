﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;
using InventoryManagement.DataAccessLogic;

namespace InventoryManagement
{
    public partial class frmExpenseEntry : Form
    {
        ExpenseModel objExpense = null;
        IGenericRepository<ExpenseModel> objExpenseDal = null;

        public frmExpenseEntry()
        {
            InitializeComponent();       
        }

        private void frmCustomer_Load(object sender, EventArgs e)
        {
            objExpenseDal = new ExpenseDAL();
            ClearFields();
            dtpTrnDate.MaxDate = DateTime.Now;
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (cboModeOfPayment.Text == "Select")
            {
                cboModeOfPayment.Focus();
                MessageBox.Show("Please select mode of payment.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtDescription.Text.Trim() == "")
            {
                txtDescription.Focus();
                MessageBox.Show("Please enter description.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtAmount.Text.Trim() == "")
            {
                txtAmount.Focus();
                MessageBox.Show("Please enter amount.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                Boolean isValid = false;
                try
                {
                    Convert.ToDouble(txtAmount.Text.Trim());
                    isValid = true;
                }
                catch (Exception)
                {
                    isValid = false;
                }

                if (isValid)
                {
                    Cursor = Cursors.WaitCursor;
                    objExpense = new ExpenseModel();
                    objExpense.TrnDate = dtpTrnDate.Text;
                    objExpense.Mode = cboModeOfPayment.Text;
                    objExpense.Description = txtDescription.Text.Trim();
                    objExpense.Amount = txtAmount.Text.Trim();                    
                    objExpense.CreatedBy = common.strUserEmail;

                    if (btnSave.Text == "Save")
                    {
                        objExpenseDal.Add(objExpense);
                        ClearFields();
                        //MessageBox.Show("Expense saved successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        objExpense.Code = Convert.ToInt32(txtCode.Text);
                        objExpenseDal.Update(objExpense);
                        ClearFields();
                        //MessageBox.Show("Expense updated successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    Cursor = Cursors.Default;
                }
                else
                {
                    MessageBox.Show("Amount should be numeric.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
        }

        private void ClearFields()
        {
            txtCode.Text = "";
            txtAmount.Text = "";
            txtDescription.Text = "";
            cboModeOfPayment.SelectedIndex = 0;
            btnSave.Text = "Save";
            dgvData.Enabled = true;
            cboModeOfPayment.Select();
            DisplayData();            
        }

        private void DisplayData()
        {
            List<ExpenseModel> lstData = objExpenseDal.GetAll();
            dgvData.DataSource = lstData;
        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (e.ColumnIndex == 0)
                {
                    txtCode.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Code"].Value);
                    dtpTrnDate.Value = Convert.ToDateTime(dgvData.Rows[e.RowIndex].Cells["TrnDate"].Value);
                    cboModeOfPayment.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Mode"].Value);
                    txtDescription.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Description"].Value);
                    txtAmount.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Amount"].Value);
                    
                    btnSave.Text = "Update";
                    dgvData.Enabled = false;
                    cboModeOfPayment.Select();
                }
                if (e.ColumnIndex == 1)
                {
                    if (MessageBox.Show("Do you want to delete?", common.strProjectTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        Int32 code = Convert.ToInt32(dgvData.Rows[e.RowIndex].Cells["Code"].Value);
                        
                        objExpenseDal.Delete(code);

                        ClearFields();

                        //MessageBox.Show("Expense deleted successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
