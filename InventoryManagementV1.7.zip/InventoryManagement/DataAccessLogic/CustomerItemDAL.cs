﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;

namespace InventoryManagement.DataAccessLogic
{
    public class CustomerItemDAL : IGenericRepository<CustomerItemModel>
    {
        string strQuery = "";
        public CustomerItemDAL()
        {
            DatabaseContext.CreateConnection();
        }

        public List<CustomerItemModel> GetAll()
        {
            List<CustomerItemModel> lstData = new List<CustomerItemModel>();
            try
            {
                DatabaseContext.CreateCommand();

                strQuery = "";
                strQuery = "SELECT CItem.Code,CItem.CustomerCode,cust.Name AS CustomerName,CItem.ItemCode,Item.Name AS ItemName,CItem.Rate,Item.GSTPercent,CItem.CreatedBy,CItem.CreatedDateTime\n";
                strQuery = strQuery + "FROM ((tblCustomerItems as CItem INNER JOIN tblCustomer as cust ON CItem.CustomerCode = cust.Code)\n";
                strQuery = strQuery + "INNER JOIN tblItem as Item ON CItem.ItemCode = Item.Code)\n";
                
                DatabaseContext.dbcmd.CommandText = strQuery;
                
                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    CustomerItemModel objCustomer = new CustomerItemModel();
                    objCustomer.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objCustomer.CustomerCode = Convert.ToString(DatabaseContext.dbdr["CustomerCode"]);
                    objCustomer.CustomerName = Convert.ToString(DatabaseContext.dbdr["CustomerName"]);
                    objCustomer.ItemCode = Convert.ToString(DatabaseContext.dbdr["ItemCode"]);
                    objCustomer.ItemName = Convert.ToString(DatabaseContext.dbdr["ItemName"]);
                    objCustomer.Rate = Convert.ToString(DatabaseContext.dbdr["Rate"]);
                    objCustomer.GSTPercent = Convert.ToString(DatabaseContext.dbdr["GSTPercent"]);
                    objCustomer.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objCustomer.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objCustomer);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public List<CustomerItemModel> GetByDates(string strFromDate, string strToDate)
        {
            List<CustomerItemModel> lstData = new List<CustomerItemModel>();
            try
            {
                DatabaseContext.CreateCommand();

                strQuery = "";
                strQuery = "SELECT CItem.Code,CItem.CustomerCode,cust.Name AS CustomerName,CItem.ItemCode,Item.Name AS ItemName,CItem.Rate,Item.GSTPercent,CItem.CreatedBy,CItem.CreatedDateTime\n";
                strQuery = strQuery + "FROM ((tblCustomerItems as CItem INNER JOIN tblCustomer as cust ON CItem.CustomerCode = cust.Code)\n";
                strQuery = strQuery + "INNER JOIN tblItem as Item ON CItem.ItemCode = Item.Code)\n";

                DatabaseContext.dbcmd.CommandText = strQuery;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();

                while (DatabaseContext.dbdr.Read())
                {
                    CustomerItemModel objCustomer = new CustomerItemModel();
                    objCustomer.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objCustomer.CustomerCode = Convert.ToString(DatabaseContext.dbdr["CustomerCode"]);
                    objCustomer.CustomerName = Convert.ToString(DatabaseContext.dbdr["CustomerName"]);
                    objCustomer.ItemCode = Convert.ToString(DatabaseContext.dbdr["ItemCode"]);
                    objCustomer.ItemName = Convert.ToString(DatabaseContext.dbdr["ItemName"]);
                    objCustomer.Rate = Convert.ToString(DatabaseContext.dbdr["Rate"]);
                    objCustomer.GSTPercent = Convert.ToString(DatabaseContext.dbdr["GSTPercent"]);
                    objCustomer.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objCustomer.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objCustomer);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public CustomerItemModel GetByID(Int32 CustomerItemCode)
        {
            CustomerItemModel objCustomer = new CustomerItemModel();
            try
            {
                strQuery = "";
                strQuery = "SELECT CItem.Code,CItem.CustomerCode,cust.Name AS CustomerName,CItem.ItemCode,Item.Name AS ItemName,CItem.Rate,Item.GSTPercent,CItem.CreatedBy,CItem.CreatedDateTime\n";
                strQuery = strQuery + "FROM ((tblCustomerItems as CItem INNER JOIN tblCustomer as cust ON CItem.CustomerCode = cust.Code)\n";
                strQuery = strQuery + "INNER JOIN tblItem as Item ON CItem.ItemCode = Item.Code)\n";
                strQuery = strQuery + "WHERE CItem.Code = " + CustomerItemCode;

                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = strQuery;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    objCustomer.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objCustomer.CustomerCode = Convert.ToString(DatabaseContext.dbdr["CustomerCode"]);
                    objCustomer.CustomerName = Convert.ToString(DatabaseContext.dbdr["CustomerName"]);
                    objCustomer.ItemCode = Convert.ToString(DatabaseContext.dbdr["ItemCode"]);
                    objCustomer.ItemName = Convert.ToString(DatabaseContext.dbdr["ItemName"]);
                    objCustomer.Rate = Convert.ToString(DatabaseContext.dbdr["Rate"]);
                    objCustomer.GSTPercent = Convert.ToString(DatabaseContext.dbdr["GSTPercent"]);
                    objCustomer.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objCustomer.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return objCustomer;
        }

        public void Add(CustomerItemModel objCustomer)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "INSERT INTO tblCustomerItems (CustomerCode,ItemCode,Rate,CreatedBy,CreatedDateTime) VALUES(@CustomerCode,@ItemCode,@Rate,@CreatedBy,@CreatedDateTime)";
                
                DatabaseContext.dbcmd.Parameters.AddWithValue("CustomerCode", objCustomer.CustomerCode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("ItemCode", objCustomer.ItemCode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Rate", objCustomer.Rate);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objCustomer.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Update(CustomerItemModel objCustomer)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "UPDATE tblCustomerItems SET CustomerCode = @CustomerCode,ItemCode = @ItemCode,Rate = @Rate, CreatedBy = @CreatedBy,CreatedDateTime = @CreatedDateTime WHERE Code = " + objCustomer.Code;

                DatabaseContext.dbcmd.Parameters.AddWithValue("CustomerCode", objCustomer.CustomerCode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("ItemCode", objCustomer.ItemCode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Rate", objCustomer.Rate);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objCustomer.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Delete(Int32 CustomerItemCode)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "DELETE FROM tblCustomerItems WHERE Code = " + CustomerItemCode;
                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
