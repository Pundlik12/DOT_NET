﻿using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HBAccessTool
{
    public static class ExcelOps
    {
        public static void ExportToExcel(string strFolderPath, string strFileName, DataTable dt)
        {
            try
            {
                if (!Directory.Exists(strFolderPath))
                {
                    Directory.CreateDirectory(strFolderPath);
                }

                using (XLWorkbook wb = new XLWorkbook())
                {
                    wb.Worksheets.Add(dt, strFileName);
                    wb.SaveAs(Path.Combine(strFolderPath, strFileName + ".xlsx"));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ExportToExcel", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        public static void ImportExcel(string strFilePath)
        {
            try
            {
                using (XLWorkbook wb = new XLWorkbook())
                {
                    IXLWorksheet ws = wb.Worksheets.Worksheet(1);
                    Int32 RowCount = ws.RowsUsed().Count();
                    Int32 ColumnCount = ws.ColumnsUsed().Count();
                    
                    for (int iRow = 1; iRow < RowCount; iRow++)
                    {
                        for (int iCol = 1; iCol < RowCount; iCol++)
                        {
                            var strData = ws.Cell(iRow, iCol).Value;

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ImportExcel", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
    }
}
