﻿using System;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Windows.Forms;

namespace HBAccessTool
{
    class Program
    {
        static string strDisplayName = "";
        //static string strFullName = "";
        static string strFirstName = "";
        static string strLastName = "";
        static string strUID = "";

        [STAThread]
        static void Main(string[] args)
        {
            //var key = "b14ca5898a4e4133bbce2ea2315a1916";
            //string test = clsCommon.EncryptString(key, "30-Jun-2023");
            //string test1 = clsCommon.DecryptString(key, test);

            clsCommon.CheckLicense();
            clsDBConnection.GetDBConnection();

            try
            {
                ////Option 1
                //WindowsIdentity CurentIdentity = WindowsIdentity.GetCurrent();
                //UserPrincipal userPrincipal = UserPrincipal.Current;
                //strDisplayName = userPrincipal.DisplayName;
                ////strFullName = userPrincipal.Name;
                //strFirstName = userPrincipal.GivenName;
                //strLastName = userPrincipal.Surname;
                //strUID = userPrincipal.SamAccountName;

                ////Option 2
                //Thread.GetDomain().SetPrincipalPolicy(PrincipalPolicy.WindowsPrincipal);
                //WindowsPrincipal principal = (WindowsPrincipal)Thread.CurrentPrincipal;

                //using (PrincipalContext pc = new PrincipalContext(ContextType.Domain))
                //{
                //    UserPrincipal up = UserPrincipal.FindByIdentity(pc, principal.Identity.Name);
                //    strDisplayName = up.DisplayName;
                //    //strFullName = up.Name;
                //    strFirstName = up.GivenName;
                //    strLastName = up.Surname;
                //    strUID = up.SamAccountName;
                //}

                ////Option 3
                UserPrincipal up = UserPrincipal.Current;
                strDisplayName = up.DisplayName;
                //strFullName = up.Name;
                strFirstName = up.GivenName;
                strLastName = up.Surname;
                strUID = up.SamAccountName;

                clsDBConnection.strStartTime = DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss");

                UserRepository ur = new UserRepository();
                
                var users = (from table in ur.GetAllUsers() where table.Uid == strUID select table).ToList();

                if (users.Count == 0)//If user does not exists register the user
                {
                    UserModel um = new UserModel();
                    um.Uid = strUID;
                    um.FirstName = strFirstName;
                    um.LastName = strLastName;
                    um.DisplayName = strDisplayName;
                    um.Role = "Associate";
                    um.IsActive = 1;
                    um.EntryID = 1;
                    um.EntryDateTime = DateTime.Now;

                    ur.AddUser(um);

                    users = (from table in ur.GetAllUsers() where table.Uid == strUID select table).ToList();
                }
                else
                {
                    if (users[0].IsActive == 0)
                    {
                        MessageBox.Show("User is disabled.Please contact to administrator.", "Main", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        Environment.Exit(Environment.ExitCode);
                    }
                }

                //Insert Login AUX
                AuxModel ax = new AuxModel();
                ax.AuxName = "Login";
                ax.UserID = users[0].UserID;
                ax.StartTime = DateTime.Now;

                AuxRepository axr = new AuxRepository();
                axr.AddAux(ax);

                clsDBConnection.intLoginUserID = users[0].UserID;
                clsDBConnection.strLoginUserUID = users[0].Uid;
                clsDBConnection.strLoginUserName = users[0].DisplayName;
                clsDBConnection.strLoginUserRole = users[0].Role;

                clsDBConnection.strEndTime = DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss");

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new frmMain());
                System.Environment.Exit(0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Main", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
    }
}
