﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;

namespace InventoryManagement.DataAccessLogic
{
    public class ChallanDAL : IGenericRepository<ChallanHeaderModel>,iReports
    {
        string strQuery = "";
        string strChallanNo = "";

        public ChallanDAL()
        {
            DatabaseContext.CreateConnection();
        }

        public List<ChallanHeaderModel> GetAll()
        {
            List<ChallanHeaderModel> lstData = new List<ChallanHeaderModel>();
            try
            {
                string strChallanDate = "31-DEC-" + DateTime.Now.AddYears(-1).ToString("yyyy");

                strQuery = "";
                strQuery = "SELECT th.ChallanHeaderCode,th.ChallanNo,th.ChallanDate,th.CustomerCode,cus.Name as CustomerName,th.TotalGST,th.TotalAmount,th.CreatedBy,th.CreatedDateTime\n";
                strQuery = strQuery + "FROM tblChallanHeader as th INNER JOIN tblCustomer as cus ON th.CustomerCode = cus.Code\n";
                strQuery = strQuery + "WHERE th.ChallanDate >= cdate('" + strChallanDate + "') and cus.CompanyCode = " + common.strCompanyCode + "\n";
                strQuery = strQuery + "ORDER BY th.ChallanDate DESC";

                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = strQuery;
                
                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    ChallanHeaderModel objChallan = new ChallanHeaderModel();
                    objChallan.ChallanHeaderCode = Convert.ToInt32(DatabaseContext.dbdr["ChallanHeaderCode"]);
                    objChallan.ChallanNo = Convert.ToString(DatabaseContext.dbdr["ChallanNo"]);
                    objChallan.ChallanDate = Convert.ToDateTime(DatabaseContext.dbdr["ChallanDate"]);
                    objChallan.CustomerCode = Convert.ToInt32(DatabaseContext.dbdr["CustomerCode"]);
                    objChallan.CustomerName = Convert.ToString(DatabaseContext.dbdr["CustomerName"]);
                    objChallan.TotalGST = Convert.ToDouble(DatabaseContext.dbdr["TotalGST"]);
                    objChallan.TotalAmount = Convert.ToDouble(DatabaseContext.dbdr["TotalAmount"]);
                    objChallan.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objChallan.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objChallan);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public List<ChallanHeaderModel> GetByDates(string strFromDate, string strToDate)
        {
            List<ChallanHeaderModel> lstData = new List<ChallanHeaderModel>();
            try
            {
                strQuery = "";
                strQuery = "SELECT th.ChallanHeaderCode,th.ChallanNo,th.ChallanDate,th.CustomerCode,cus.Name as CustomerName,th.TotalGST,th.TotalAmount,th.CreatedBy,th.CreatedDateTime\n";
                strQuery = strQuery + "FROM tblChallanHeader as th INNER JOIN tblCustomer as cus ON th.CustomerCode = cus.Code\n";
                strQuery = strQuery + "WHERE th.ChallanDate >= cdate('" + strFromDate + "') and th.ChallanDate <= cdate('" + strToDate + "') and cus.CompanyCode = " + common.strCompanyCode + "\n";
                strQuery = strQuery + "ORDER BY th.ChallanDate DESC";

                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = strQuery;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();

                while (DatabaseContext.dbdr.Read())
                {
                    ChallanHeaderModel objChallan = new ChallanHeaderModel();
                    objChallan.ChallanHeaderCode = Convert.ToInt32(DatabaseContext.dbdr["ChallanHeaderCode"]);
                    objChallan.ChallanNo = Convert.ToString(DatabaseContext.dbdr["ChallanNo"]);
                    objChallan.ChallanDate = Convert.ToDateTime(DatabaseContext.dbdr["ChallanDate"]);
                    objChallan.CustomerCode = Convert.ToInt32(DatabaseContext.dbdr["CustomerCode"]);
                    objChallan.CustomerName = Convert.ToString(DatabaseContext.dbdr["CustomerName"]);
                    objChallan.TotalGST = Convert.ToDouble(DatabaseContext.dbdr["TotalGST"]);
                    objChallan.TotalAmount = Convert.ToDouble(DatabaseContext.dbdr["TotalAmount"]);
                    objChallan.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objChallan.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objChallan);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public ChallanHeaderModel GetByID(Int32 CompanyCode)
        {
            ChallanHeaderModel objChallan = new ChallanHeaderModel();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT Code,Name,Address,PinCode,City,State,Mobile,Email,GSTNo FROM tblCompany WHERE Code = " + CompanyCode;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                //while (DatabaseContext.dbdr.Read())
                //{
                //    objChallan.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                //    objChallan.Name = Convert.ToString(DatabaseContext.dbdr["Name"]);
                //    objChallan.Address = Convert.ToString(DatabaseContext.dbdr["Address"]);
                //    objChallan.PinCode = Convert.ToString(DatabaseContext.dbdr["PinCode"]);
                //    objChallan.City = Convert.ToString(DatabaseContext.dbdr["City"]);
                //    objChallan.State = Convert.ToString(DatabaseContext.dbdr["State"]);
                //    objChallan.Mobile = Convert.ToString(DatabaseContext.dbdr["Mobile"]);
                //    objChallan.Email = Convert.ToString(DatabaseContext.dbdr["Email"]);
                //    objChallan.GSTNo = Convert.ToString(DatabaseContext.dbdr["GSTNo"]);
                //}

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return objChallan;
        }

        public void Add(ChallanHeaderModel objChallan)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT MAX(ChallanHeaderCode) AS ChallanHeaderCode FROM tblChallanHeader";
                DatabaseContext.OpenConnection();
                
                string ChallanHeaderCode = Convert.ToString(DatabaseContext.dbcmd.ExecuteScalar());
                
                if (ChallanHeaderCode == "")
                {
                    ChallanHeaderCode = "1";
                }
                else
                {
                    ChallanHeaderCode = Convert.ToString(Convert.ToInt64(ChallanHeaderCode) + 1);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;

                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "INSERT INTO tblChallanHeader (ChallanNo,ChallanDate,CustomerCode,TotalGST,TotalAmount,CreatedBy,CreatedDateTime) VALUES(@InvoiceNo,@InvoiceDate,@CustomerCode,@TotalGST,@TotalAmount,@CreatedBy,@CreatedDateTime)";

                strChallanNo = "";
                strChallanNo = "CHL/" + DateTime.Now.ToString("yyyy") + "/" + ChallanHeaderCode;
                common.ChallanNo = strChallanNo;

                DatabaseContext.dbcmd.Parameters.AddWithValue("ChallanNo", strChallanNo);
                DatabaseContext.dbcmd.Parameters.AddWithValue("ChallanDate", objChallan.ChallanDate);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CustomerCode", objChallan.CustomerCode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("TotalGST", objChallan.TotalGST);
                DatabaseContext.dbcmd.Parameters.AddWithValue("TotalAmount", objChallan.TotalAmount);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objChallan.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                
                DatabaseContext.dbcmd.CommandText = "SELECT @@Identity";
                int ID = (int)DatabaseContext.dbcmd.ExecuteScalar();
                
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
                
                List<ChallanDetailsModel> ObjChallanDetails = new List<ChallanDetailsModel>();
                ObjChallanDetails = objChallan.ChallanDetails;

                foreach (ChallanDetailsModel item in ObjChallanDetails)
                {
                    DatabaseContext.CreateCommand();
                    DatabaseContext.dbcmd.CommandText = "INSERT INTO tblChallanDetails (ChallanHeaderCode,ItemCode,Description,Rate,Qty,GST,Amount) VALUES(@ChallanHeaderCode,@ItemCode,@Description,@Rate,@Qty,@GST,@Amount)";

                    DatabaseContext.dbcmd.Parameters.AddWithValue("ChallanHeaderCode", ID);
                    DatabaseContext.dbcmd.Parameters.AddWithValue("ItemCode", item.ItemCode);
                    DatabaseContext.dbcmd.Parameters.AddWithValue("Description", item.Description);
                    DatabaseContext.dbcmd.Parameters.AddWithValue("Rate", item.Rate);
                    DatabaseContext.dbcmd.Parameters.AddWithValue("Qty", item.Qty);
                    DatabaseContext.dbcmd.Parameters.AddWithValue("GST", item.GST);
                    DatabaseContext.dbcmd.Parameters.AddWithValue("Amount", item.Amount);

                    DatabaseContext.OpenConnection();
                    DatabaseContext.dbcmd.ExecuteNonQuery();
                    DatabaseContext.CloseConnection();
                    DatabaseContext.dbcmd = null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Update(ChallanHeaderModel objChallan)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "UPDATE tblChallanHeader SET ChallanNo=@ChallanNo,ChallanDate=@ChallanDate,CustomerCode=@CustomerCode,TotalGST=@TotalGST,TotalAmount=@TotalAmount,CreatedBy=@CreatedBy,CreatedDateTime=@CreatedDateTime WHERE ChallanHeaderCode=@ChallanHeaderCode";

                DatabaseContext.dbcmd.Parameters.AddWithValue("ChallanNo", objChallan.ChallanNo);
                DatabaseContext.dbcmd.Parameters.AddWithValue("ChallanDate", objChallan.ChallanDate);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CustomerCode", objChallan.CustomerCode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("TotalGST", objChallan.TotalGST);
                DatabaseContext.dbcmd.Parameters.AddWithValue("TotalAmount", objChallan.TotalAmount);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objChallan.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));
                DatabaseContext.dbcmd.Parameters.AddWithValue("ChallanHeaderCode", objChallan.ChallanHeaderCode);

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;

                List<ChallanDetailsModel> ObjChallanDetails = new List<ChallanDetailsModel>();
                ObjChallanDetails = objChallan.ChallanDetails;

                foreach (ChallanDetailsModel item in ObjChallanDetails)
                {
                    DatabaseContext.CreateCommand();
                    DatabaseContext.dbcmd.CommandText = "UPDATE tblChallanDetails SET ChallanHeaderCode=@ChallanHeaderCode,ProductCode=@ProductCode,Description=@Description,Rate=@Rate,Qty=@Qty,GST=@GST,Amount=@Amount WHERE ChallanDetailsCode=@ChallanDetailsCode";

                    DatabaseContext.dbcmd.Parameters.AddWithValue("ChallanHeaderCode", item.ChallanHeaderCode);
                    DatabaseContext.dbcmd.Parameters.AddWithValue("ProductCode", item.ItemCode);
                    DatabaseContext.dbcmd.Parameters.AddWithValue("Description", item.Description);
                    DatabaseContext.dbcmd.Parameters.AddWithValue("Rate", item.Rate);
                    DatabaseContext.dbcmd.Parameters.AddWithValue("Qty", item.Qty);
                    DatabaseContext.dbcmd.Parameters.AddWithValue("GST", item.GST);
                    DatabaseContext.dbcmd.Parameters.AddWithValue("Amount", item.Amount);
                    DatabaseContext.dbcmd.Parameters.AddWithValue("ChallanDetailsCode", item.ChallanDetailsCode);

                    DatabaseContext.OpenConnection();
                    DatabaseContext.dbcmd.ExecuteNonQuery();
                    DatabaseContext.CloseConnection();
                    DatabaseContext.dbcmd = null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Delete(Int32 ChallanHeaderCode)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "DELETE FROM tblChallanHeader WHERE ChallanHeaderCode = " + ChallanHeaderCode;
                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;

                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "DELETE FROM tblChallanDetails WHERE ChallanHeaderCode = " + ChallanHeaderCode;
                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public DataTable PrintChallan()
        {
            DataTable dt = new DataTable();
            try
            {
                strQuery = "";
                strQuery = strQuery + "SELECT DISTINCT th.ChallanNo,th.ChallanDate,cus.Name as CustomerName,cus.Address,cus.PinCode,cus.City,cus.State,\n";
                strQuery = strQuery + "cus.Mobile,cus.Email,cus.GSTNo,th.TotalGST,th.TotalAmount,Det.Description,Det.Rate,Det.Qty,Det.GST,Det.Amount,Item.HSNNumber,Item.Name as ItemType,Item.GSTPercent\n";
                strQuery = strQuery + "FROM((((tblChallanHeader as th INNER JOIN tblCustomer as cus ON th.CustomerCode = cus.Code)\n";
                strQuery = strQuery + "INNER JOIN tblChallanDetails as Det ON th.ChallanHeaderCode = Det.ChallanHeaderCode)\n";
                strQuery = strQuery + "INNER JOIN tblCustomerItems as CustItem ON th.CustomerCode = CustItem.CustomerCode)\n";
                strQuery = strQuery + "INNER JOIN tblItem as Item ON Det.ItemCode = Item.Code)\n";
                strQuery = strQuery + "WHERE th.ChallanNo = '" + common.ChallanNo + "'\n";
                strQuery = strQuery + "ORDER BY Item.Name,Det.Qty,Det.Description";

                DatabaseContext.OpenConnection();
                
                DatabaseContext.CreateAdapter(strQuery);
                DatabaseContext.dbAdapter.Fill(dt);

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return dt;
        }
    }
}
