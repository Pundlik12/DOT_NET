﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;

namespace InventoryManagement.DataAccessLogic
{
    public class SupplierDAL : IGenericRepository<SupplierModel>
    {
        public SupplierDAL()
        {
            DatabaseContext.CreateConnection();
        }

        public List<SupplierModel> GetAll()
        {
            List<SupplierModel> lstData = new List<SupplierModel>();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT Code,Name,Address,PinCode,City,State,Mobile,Email,GSTNo,CreatedBy,CreatedDateTime FROM tblSupplier";
                
                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    SupplierModel objSupplier = new SupplierModel();
                    objSupplier.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objSupplier.Name = Convert.ToString(DatabaseContext.dbdr["Name"]);
                    objSupplier.Address = Convert.ToString(DatabaseContext.dbdr["Address"]);
                    objSupplier.PinCode = Convert.ToString(DatabaseContext.dbdr["PinCode"]);
                    objSupplier.City = Convert.ToString(DatabaseContext.dbdr["City"]);
                    objSupplier.State = Convert.ToString(DatabaseContext.dbdr["State"]);
                    objSupplier.Mobile = Convert.ToString(DatabaseContext.dbdr["Mobile"]);
                    objSupplier.Email = Convert.ToString(DatabaseContext.dbdr["Email"]);
                    objSupplier.GSTNo = Convert.ToString(DatabaseContext.dbdr["GSTNo"]);
                    objSupplier.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objSupplier.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objSupplier);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public List<SupplierModel> GetByDates(string strFromDate, string strToDate)
        {
            List<SupplierModel> lstData = new List<SupplierModel>();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT Code,Name,Address,PinCode,City,State,Mobile,Email,GSTNo,CreatedBy,CreatedDateTime FROM tblSupplier";

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();

                while (DatabaseContext.dbdr.Read())
                {
                    SupplierModel objSupplier = new SupplierModel();
                    objSupplier.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objSupplier.Name = Convert.ToString(DatabaseContext.dbdr["Name"]);
                    objSupplier.Address = Convert.ToString(DatabaseContext.dbdr["Address"]);
                    objSupplier.PinCode = Convert.ToString(DatabaseContext.dbdr["PinCode"]);
                    objSupplier.City = Convert.ToString(DatabaseContext.dbdr["City"]);
                    objSupplier.State = Convert.ToString(DatabaseContext.dbdr["State"]);
                    objSupplier.Mobile = Convert.ToString(DatabaseContext.dbdr["Mobile"]);
                    objSupplier.Email = Convert.ToString(DatabaseContext.dbdr["Email"]);
                    objSupplier.GSTNo = Convert.ToString(DatabaseContext.dbdr["GSTNo"]);
                    objSupplier.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objSupplier.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objSupplier);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public SupplierModel GetByID(Int32 CustomerCode)
        {
            SupplierModel objSupplier = new SupplierModel();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT Code,Name,Address,PinCode,City,State,Mobile,Email,GSTNo,CreatedBy,CreatedDateTime FROM tblSupplier WHERE Code = " + CustomerCode;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    objSupplier.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objSupplier.Name = Convert.ToString(DatabaseContext.dbdr["Name"]);
                    objSupplier.Address = Convert.ToString(DatabaseContext.dbdr["Address"]);
                    objSupplier.PinCode = Convert.ToString(DatabaseContext.dbdr["PinCode"]);
                    objSupplier.City = Convert.ToString(DatabaseContext.dbdr["City"]);
                    objSupplier.State = Convert.ToString(DatabaseContext.dbdr["State"]);
                    objSupplier.Mobile = Convert.ToString(DatabaseContext.dbdr["Mobile"]);
                    objSupplier.Email = Convert.ToString(DatabaseContext.dbdr["Email"]);
                    objSupplier.GSTNo = Convert.ToString(DatabaseContext.dbdr["GSTNo"]);
                    objSupplier.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objSupplier.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return objSupplier;
        }

        public void Add(SupplierModel objSupplier)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "INSERT INTO tblSupplier (Name,Address,PinCode,City,State,Mobile,Email,GSTNo,CreatedBy,CreatedDateTime) VALUES(@Name,@Address,@PinCode,@City,@State,@Mobile,@Email,@GSTNo,@CreatedBy,@CreatedDateTime)";
                
                DatabaseContext.dbcmd.Parameters.AddWithValue("Name", objSupplier.Name);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Address", objSupplier.Address);
                DatabaseContext.dbcmd.Parameters.AddWithValue("PinCode", objSupplier.PinCode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("City", objSupplier.City);
                DatabaseContext.dbcmd.Parameters.AddWithValue("State", objSupplier.State);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Mobile", objSupplier.Mobile);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Email", objSupplier.Email);
                DatabaseContext.dbcmd.Parameters.AddWithValue("GSTNo", objSupplier.GSTNo);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objSupplier.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Update(SupplierModel objSupplier)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "UPDATE tblSupplier SET Name = @Name,Address = @Address,PinCode = @PinCode,City = @City,State = @State,Mobile = @Mobile,Email = @Email,GSTNo = @GSTNo, CreatedBy = @CreatedBy,CreatedDateTime = @CreatedDateTime WHERE Code = " + objSupplier.Code;

                DatabaseContext.dbcmd.Parameters.AddWithValue("Name", objSupplier.Name);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Address", objSupplier.Address);
                DatabaseContext.dbcmd.Parameters.AddWithValue("PinCode", objSupplier.PinCode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("City", objSupplier.City);
                DatabaseContext.dbcmd.Parameters.AddWithValue("State", objSupplier.State);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Mobile", objSupplier.Mobile);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Email", objSupplier.Email);
                DatabaseContext.dbcmd.Parameters.AddWithValue("GSTNo", objSupplier.GSTNo);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objSupplier.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Delete(Int32 CustomerCode)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "DELETE FROM tblSupplier WHERE Code = " + CustomerCode;
                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
