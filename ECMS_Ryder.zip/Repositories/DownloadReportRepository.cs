﻿using ECMS_Ryder.HelperClasses;
using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace ECMS_Ryder.Repositories
{
    interface iDownloadReportRepository
    {
        DataTable DownloadAllEmails();
        DataTable DownloadUnAssignedEmails();
        DataTable DownloadAssignedEmails();
        DataTable DownloadCompletedEmails();
    }

    internal class DownloadReportRepository : iDownloadReportRepository
    {
        private readonly string strConnectionString = "";

        public DownloadReportRepository(string _strConnectionString)
        {
            strConnectionString = _strConnectionString;
        }

        public DataTable DownloadAllEmails()
        {
            string strQuery = "";
            DataTable dataTable = new DataTable();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    OleDbCommand cmd = new OleDbCommand();

                    strQuery = "";
                    strQuery = strQuery + "SELECT EmailDetails.EmailDetailsId, EmailDetails.EmailAddress, EmailDetails.FolderName, EmailDetails.SenderName," + Environment.NewLine;
                    strQuery = strQuery + "EmailDetails.SenderEmailAddress, EmailDetails.To, EmailDetails.Cc, EmailDetails.Bcc, EmailDetails.ReceivedTime, " + Environment.NewLine;
                    strQuery = strQuery + "EmailDetails.Subject, EmailDetails.Body, EmailDetails.Priority, EmailDetails.HasAttachments, EmailDetails.EntryID," + Environment.NewLine;
                    strQuery = strQuery + "EmailDetails.ConversationID, EmailDetails.Status, EmailDetails.SyncBy, EmailDetails.SyncDateTime," + Environment.NewLine;
                    strQuery = strQuery + "EmailDetails.LastUpdatedBy, EmailDetails.LastUpdatedDateTime, EmailDetails.AssignTo, EmailDetails.AssignedBy, EmailDetails.AssignedDateTime, EmailDetails.AccountNumber" + Environment.NewLine;
                    strQuery = strQuery + "FROM EmailDetails" + Environment.NewLine;
                    strQuery = strQuery + "WHERE EmailDetails.EmailAddress = '" + clsDBConnection.strEmailAddress + "'";

                    cmd.Connection = connection;
                    cmd.CommandText = strQuery;
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter(cmd);

                    oleDbDataAdapter.Fill(dataTable);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in DownloadAllEmails:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return dataTable;
        }

        public DataTable DownloadUnAssignedEmails()
        {
            string strQuery = "";
            DataTable dataTable = new DataTable();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    OleDbCommand cmd = new OleDbCommand();

                    strQuery = "";
                    strQuery = strQuery + "SELECT EmailDetails.EmailDetailsId, EmailDetails.EmailAddress, EmailDetails.FolderName, EmailDetails.SenderName," + Environment.NewLine;
                    strQuery = strQuery + "EmailDetails.SenderEmailAddress, EmailDetails.To, EmailDetails.Cc, EmailDetails.Bcc, EmailDetails.ReceivedTime, " + Environment.NewLine;
                    strQuery = strQuery + "EmailDetails.Subject, EmailDetails.Body, EmailDetails.Priority, EmailDetails.HasAttachments, EmailDetails.EntryID," + Environment.NewLine;
                    strQuery = strQuery + "EmailDetails.ConversationID, EmailDetails.Status, EmailDetails.SyncBy, EmailDetails.SyncDateTime," + Environment.NewLine;
                    strQuery = strQuery + "EmailDetails.LastUpdatedBy, EmailDetails.LastUpdatedDateTime, EmailDetails.AssignTo, EmailDetails.AssignedBy, EmailDetails.AssignedDateTime, EmailDetails.AccountNumber" + Environment.NewLine;
                    strQuery = strQuery + "FROM EmailDetails" + Environment.NewLine;
                    strQuery = strQuery + "WHERE EmailDetails.EmailAddress = '" + clsDBConnection.strEmailAddress + "' AND EmailDetails.AssignTo IS NULL";

                    cmd.Connection = connection;
                    cmd.CommandText = strQuery;
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter(cmd);

                    oleDbDataAdapter.Fill(dataTable);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in DownloadUnAssignedEmails:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return dataTable;
        }

        public DataTable DownloadAssignedEmails()
        {
            string strQuery = "";
            DataTable dataTable = new DataTable();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    OleDbCommand cmd = new OleDbCommand();

                    strQuery = "";
                    strQuery = strQuery + "SELECT EmailDetails.EmailDetailsId, EmailDetails.EmailAddress, EmailDetails.FolderName, EmailDetails.SenderName," + Environment.NewLine;
                    strQuery = strQuery + "EmailDetails.SenderEmailAddress, EmailDetails.To, EmailDetails.Cc, EmailDetails.Bcc, EmailDetails.ReceivedTime, " + Environment.NewLine;
                    strQuery = strQuery + "EmailDetails.Subject, EmailDetails.Body, EmailDetails.Priority, EmailDetails.HasAttachments, EmailDetails.EntryID," + Environment.NewLine;
                    strQuery = strQuery + "EmailDetails.ConversationID, EmailDetails.Status, EmailDetails.SyncBy, EmailDetails.SyncDateTime," + Environment.NewLine;
                    strQuery = strQuery + "EmailDetails.LastUpdatedBy, EmailDetails.LastUpdatedDateTime, EmailDetails.AssignTo,UserDetails.UserName AS AssignedUser, EmailDetails.AssignedBy, EmailDetails.AssignedDateTime, EmailDetails.AccountNumber" + Environment.NewLine;
                    strQuery = strQuery + "FROM EmailDetails INNER JOIN UserDetails ON EmailDetails.AssignTo = UserDetails.UID" + Environment.NewLine;
                    strQuery = strQuery + "WHERE EmailDetails.Status <> 'Completed' AND EmailDetails.EmailAddress = '" + clsDBConnection.strEmailAddress +"'" + Environment.NewLine;

                    if (clsDBConnection.strLoggedInUserRole != "Admin")
                    {
                        strQuery = strQuery + "AND EmailDetails.AssignTo = '" + clsDBConnection.strLoggedInUID +"'";
                    }
                    else
                    {
                        strQuery = strQuery + "AND EmailDetails.AssignTo IS NOT NULL" ;
                    }

                    cmd.Connection = connection;
                    cmd.CommandText = strQuery;
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter(cmd);

                    oleDbDataAdapter.Fill(dataTable);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in DownloadAssignedEmails:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return dataTable;
        }

        public DataTable DownloadCompletedEmails()
        {
            string strQuery = "";
            DataTable dataTable = new DataTable();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    OleDbCommand cmd = new OleDbCommand();

                    strQuery = "";
                    strQuery = strQuery + "SELECT EmailDetails.EmailDetailsId, EmailDetails.EmailAddress, EmailDetails.FolderName, EmailDetails.SenderName, EmailDetails.SenderEmailAddress, EmailDetails.To, EmailDetails.Cc, EmailDetails.Bcc, EmailDetails.ReceivedTime, EmailDetails.Subject, EmailDetails.Body, EmailDetails.Priority, EmailDetails.HasAttachments, EmailDetails.EntryID, EmailDetails.ConversationID, EmailDetails.Status, EmailDetails.SyncBy, EmailDetails.SyncDateTime, EmailDetails.LastUpdatedBy, EmailDetails.LastUpdatedDateTime, EmailDetails.AssignTo, EmailDetails.AssignedBy, EmailDetails.AssignedDateTime, EmailDetails.AccountNumber, DispositionDetails.DispositionDetailsId, DispositionDetails.StartTime, DispositionDetails.Category, DispositionDetails.SubCategory, DispositionDetails.Inclusions, DispositionDetails.Dependency, DispositionDetails.ManualFollowUp, DispositionDetails.Comments, DispositionDetails.EntryUser, DispositionDetails.EntryDateTime" + Environment.NewLine;
                    strQuery = strQuery + "FROM DispositionDetails INNER JOIN EmailDetails ON DispositionDetails.EmailDetailsId = EmailDetails.EmailDetailsId" + Environment.NewLine;
                    strQuery = strQuery + "WHERE EmailDetails.Status = 'Completed' AND EmailDetails.EmailAddress = '" + clsDBConnection.strEmailAddress + "'" + Environment.NewLine;

                    if (clsDBConnection.strLoggedInUserRole != "Admin")
                    {
                        strQuery = strQuery + "AND EmailDetails.AssignTo = '" + clsDBConnection.strLoggedInUID + "'";
                    }

                    cmd.Connection = connection;
                    cmd.CommandText = strQuery;
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter(cmd);

                    oleDbDataAdapter.Fill(dataTable);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in DownloadCompletedEmails:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return dataTable;
        }
    }
}
