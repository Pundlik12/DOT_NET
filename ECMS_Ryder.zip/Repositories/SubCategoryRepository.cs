﻿using System;
using System.Data;
using System.Data.OleDb;
using ECMS_Ryder.Models;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ECMS_Ryder.Repositories
{
    interface iSubCategoryRepository
    {
        List<SubCategoryDetails> GetAllSubCategories();
        SubCategoryDetails GetSubCategoryByID(string subCategoryDetailsID);
        void CreateSubCategory(SubCategoryDetails subCategoryDetails);
        void UpdateSubCategory(SubCategoryDetails subCategoryDetails);
        void DeleteSubCategory(Int32 SubCategoryDetailsId);
    }

    internal class SubCategoryRepository : iSubCategoryRepository
    {
        private readonly string strConnectionString = "";

        public SubCategoryRepository(string _strConnectionString)
        {
            strConnectionString = _strConnectionString;
        }

        public List<SubCategoryDetails> GetAllSubCategories()
        {
            List<SubCategoryDetails> subCategories = new List<SubCategoryDetails>();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "SELECT SubCategoryDetails.SubCategoryId,SubCategoryDetails.CategoryId,CategoryDetails.Category,SubCategoryDetails.SubCategory FROM SubCategoryDetails INNER JOIN CategoryDetails ON SubCategoryDetails.CategoryId = CategoryDetails.CategoryId";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    OleDbDataReader OleDbDataReader = cmd.ExecuteReader();

                    while (OleDbDataReader.Read())
                    {
                        SubCategoryDetails subCategoriesDetails = new SubCategoryDetails();

                        subCategoriesDetails.SubCategoryId = Convert.ToInt32(OleDbDataReader["SubCategoryId"]);
                        subCategoriesDetails.CategoryId = Convert.ToInt32(OleDbDataReader["CategoryId"]);
                        subCategoriesDetails.Category = Convert.ToString(OleDbDataReader["Category"]);
                        subCategoriesDetails.SubCategory = Convert.ToString(OleDbDataReader["SubCategory"]);
                        
                        //subCategoriesDetails.EntryUser = Convert.ToString(OleDbDataReader["EntryUser"]);
                        //subCategoriesDetails.EntryDateTime = Convert.ToString(OleDbDataReader["EntryDateTime"]);

                        subCategories.Add(subCategoriesDetails);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetAllSubCategories:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                subCategories = null;
            }

            return subCategories;
        }

        public SubCategoryDetails GetSubCategoryByID(string SubCategoryID)
        {
            SubCategoryDetails subCategoriesDetails = new SubCategoryDetails();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "SELECT SubCategoryDetails.SubCategoryId,SubCategoryDetails.CategoryId,CategoryDetails.Category,SubCategoryDetails.SubCategory FROM SubCategoryDetails INNER JOIN CategoryDetails ON SubCategoryDetails.CategoryId = CategoryDetails.CategoryId WHERE SubCategoryDetails.SubCategoryID = @SubCategoryID";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.AddWithValue("@SubCategoryID", SubCategoryID);

                    OleDbDataReader OleDbDataReader = cmd.ExecuteReader();

                    while (OleDbDataReader.Read())
                    {
                        subCategoriesDetails.SubCategoryId = Convert.ToInt32(OleDbDataReader["SubCategoryId"]);
                        subCategoriesDetails.CategoryId = Convert.ToInt32(OleDbDataReader["CategoryId"]);
                        subCategoriesDetails.Category = Convert.ToString(OleDbDataReader["Category"]);
                        subCategoriesDetails.SubCategory = Convert.ToString(OleDbDataReader["SubCategory"]);

                        //subCategoriesDetails.EntryUser = Convert.ToString(OleDbDataReader["EntryUser"]);
                        //subCategoriesDetails.EntryDateTime = Convert.ToString(OleDbDataReader["EntryDateTime"]);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetSubCategoryByID:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                subCategoriesDetails = null;
            }

            return subCategoriesDetails;
        }

        public void CreateSubCategory(SubCategoryDetails subCategoryDetails)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "INSERT INTO SubCategoryDetails (CategoryId, SubCategory) VALUES(@CategoryId, @SubCategory)";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.AddWithValue("@CategoryId", subCategoryDetails.CategoryId);
                    //cmd.Parameters.AddWithValue("@Category", subCategoryDetails.Category);
                    cmd.Parameters.AddWithValue("@SubCategory", subCategoryDetails.SubCategory);

                    //cmd.Parameters.AddWithValue("@EntryUser", subCategoryDetails.EntryUser);
                    //cmd.Parameters.AddWithValue("@EntryDateTime", subCategoryDetails.EntryDateTime);

                    cmd.ExecuteNonQuery();

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in CreateSubCategory:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void UpdateSubCategory(SubCategoryDetails subCategoryDetails)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "UPDATE SubCategoryDetails SET CategoryId = @CategoryId, SubCategory = @SubCategory WHERE SubCategoryId = @SubCategoryId";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.AddWithValue("@CategoryId", subCategoryDetails.CategoryId);
                    //cmd.Parameters.AddWithValue("@Category", subCategoryDetails.Category);
                    cmd.Parameters.AddWithValue("@SubCategory", subCategoryDetails.SubCategory);

                    //cmd.Parameters.AddWithValue("@EntryUser", subCategoryDetails.EntryUser);
                    //cmd.Parameters.AddWithValue("@EntryDateTime", subCategoryDetails.EntryDateTime);
                    
                    cmd.Parameters.AddWithValue("@SubCategoryId", subCategoryDetails.SubCategoryId);

                    cmd.ExecuteNonQuery();

                    connection.Close();
                }                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in UpdateSubCategory:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void DeleteSubCategory(int SubCategoryId)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "DELETE FROM SubCategoryDetails WHERE SubCategoryId = @SubCategoryId";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.AddWithValue("@SubCategoryId", SubCategoryId);

                    cmd.ExecuteNonQuery();

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in DeleteSubCategory:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
