﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.Bibliography;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Wordprocessing;
using InventoryManagement.BusinessLogic;
using InventoryManagement.DataAccessLogic;
using Microsoft.Office.Interop.Excel;
using DataTable = System.Data.DataTable;


namespace InventoryManagement
{
    public class common
    {
        static string strBasePath = String.Concat(System.AppDomain.CurrentDomain.BaseDirectory, @"DB.mdb");
        public static string strProjectTitle = ConfigurationManager.AppSettings["AppName"].ToString();
        public static string strLoggedInUser = Environment.UserName;
        public static DateTime dtLastPasswordChanged;
        public static string strConnectionString = String.Format(ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString.ToString(), strBasePath);
        public static string strNotificationType = "";
        public static string strNotificationMsg = "";
        static System.Threading.Mutex mutex;
        public static string strKey = "b14ca5898a4e4133bbce2ea2315a1916";

        public static string strUserCode = "";
        public static string strUserEmail= "";
        public static string strUserRole = "";
        public static string strCompanyCode = "";

        public static string ChallanNo = "";
        public static string Name = "";
        public static string Address1 = "";
        public static string Address2 = "";
        public static string Address3 = "";
        public static string State = "";
        public static string PhoneNo = "";
        public static string MobileNo = "";

        static common()
        {
            if (File.Exists(strBasePath) == false)
            {
                MessageBox.Show("Database is not configured.Please contact to administrator.", strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Environment.Exit(1);
            }
        }

        public static void CheckApplicationIsRunning(string strApplicationName)
        {
            mutex = new System.Threading.Mutex(true, strApplicationName, out bool flag);
            
            if (!flag)
            {
                MessageBox.Show("Application is already running.", strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Environment.Exit(1);
            }            
        }

        public static void CheckLicense()
        {
            string strLicenseDate = System.Configuration.ConfigurationManager.AppSettings["LDate"].ToString();
            Int32 strAlertDays = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["AlertDaysBefore"].ToString());

            strLicenseDate = DecryptString(strKey, strLicenseDate);
            DateTime enDate = DateTime.Parse(strLicenseDate);
            DateTime today = DateTime.Today;
            double daysremain = (enDate - today).TotalDays;

            if (daysremain <= strAlertDays && daysremain >= 0)
            {
                strNotificationType = "License Expire";
                strNotificationMsg = $"Your software license will expire in {daysremain} Days.";
                MessageBox.Show($"Your software license will expire in {daysremain} Days.", strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            if (enDate < DateTime.Today)
            {
                MessageBox.Show("Your software license is expired." + Environment.NewLine + Environment.NewLine + "Please Contact to Administrator", strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Environment.Exit(Environment.ExitCode);
            }
        }

        public static Boolean CheckPasswordExpired()
        {
            Boolean isPasswordExpired = false;
            Int32 strAlertDays = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["AlertDaysBefore"].ToString());
            Int32 strPasswordIntervalInDays = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["PasswordIntervalInDays"].ToString());

            DateTime enDate = dtLastPasswordChanged.AddDays(strPasswordIntervalInDays).Date;
            DateTime today = DateTime.Today;
            double daysremain = (enDate - today).TotalDays;

            if (daysremain <= strAlertDays && daysremain >= 0)
            {
                strNotificationType = "Password Expired";
                strNotificationMsg = $"Your password will expire in {daysremain} Days.";
                MessageBox.Show($"Your password will expire in {daysremain} Days.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            if (enDate < DateTime.Today)
            {
                isPasswordExpired = true;
            }

            return isPasswordExpired;
        }

        public static void WriteLog(string strErrorMsg)
        {
            try
            {
                string strLogFilePath = System.AppDomain.CurrentDomain.BaseDirectory + @"\ErrorLog";

                if (System.IO.Directory.Exists(strLogFilePath) == false)
                {
                    System.IO.Directory.CreateDirectory(strLogFilePath);
                }

                using (StreamWriter sw = new StreamWriter(strLogFilePath + @"\ErrorLog.txt", true))
                {
                    sw.WriteLine(strErrorMsg);
                    sw.WriteLine("==================================================== " + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public static Boolean ExportToExcel(DataTable dtData, string strFilePath, string strSheetName)
        {
            Boolean isSuccess = false;
            try
            {
                using (XLWorkbook workbook = new XLWorkbook())
                {
                    workbook.Worksheets.Add(dtData, strSheetName);
                    workbook.SaveAs(strFilePath);
                }
                isSuccess = true;
            }
            catch (Exception ex)
            {
                isSuccess = false;
                MessageBox.Show("Error exporting file: " + ex.Message, strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return isSuccess;
        }

        public static DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }

            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

		public static void PrintInvoice(DataTable dt)
        {
            DataTable dtCompany = new DataTable();
            try
            {
                string strQuery = "";
                strQuery = strQuery + "SELECT com.Name as CompanyName,com.Address,com.PinCode,com.City,com.State,Mobile,Email,GSTNo\n";
                strQuery = strQuery + "FROM tblCompany as com";
                
                DatabaseContext.OpenConnection();

                DatabaseContext.CreateAdapter(strQuery);
                DatabaseContext.dbAdapter.Fill(dtCompany);

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            killProcessesByName("EXCEL");

            if (dtCompany != null && dtCompany.Rows.Count >= 0)
            {
                string strTemplatePath = AppDomain.CurrentDomain.BaseDirectory + @"Template.xltx";
                
                if (File.Exists(strTemplatePath) == true)
                {
                    Microsoft.Office.Interop.Excel.Application xlApp = null;
                    Microsoft.Office.Interop.Excel.Workbook XlWbk = null;
                    Microsoft.Office.Interop.Excel.Worksheet xlSht = null;

                    try
                    {
                        xlApp = new Microsoft.Office.Interop.Excel.Application();
                        XlWbk = xlApp.Workbooks.Open(strTemplatePath);
                        xlSht = XlWbk.Sheets[1];
                        xlApp.Visible = true;

                        xlSht.Range["B3"].Value = Convert.ToString(dtCompany.Rows[0]["CompanyName"]);
                        xlSht.Range["B4"].Value = Convert.ToString(dtCompany.Rows[0]["Address"]) + " " + Convert.ToString(dtCompany.Rows[0]["City"]) + " " + Convert.ToString(dtCompany.Rows[0]["State"]) + " " + Convert.ToString(dtCompany.Rows[0]["PinCode"]);
                        xlSht.Range["B6"].Value = Convert.ToString(dtCompany.Rows[0]["GSTNo"]);

                        xlSht.Range["F11"].Value = Convert.ToString(dt.Rows[0]["ChallanNo"]);
                        xlSht.Range["G11"].Value = Convert.ToString(dt.Rows[0]["ChallanDate"]);
                        xlSht.Range["B10"].Value = Convert.ToString(dt.Rows[0]["CustomerName"]);
                        xlSht.Range["B11"].Value = Convert.ToString(dt.Rows[0]["Address"]) + " " + Convert.ToString(dt.Rows[0]["City"]) + " " + Convert.ToString(dt.Rows[0]["State"]) + " " + Convert.ToString(dt.Rows[0]["PinCode"]);
                        xlSht.Range["B12"].Value = Convert.ToString(dt.Rows[0]["GSTNo"]);

                        double dblTotalAmount = Convert.ToDouble(dt.Rows[0]["TotalAmount"]);
                        string words = NumberToWordsConverter.Convert(dblTotalAmount);

                        xlSht.Range["B19"].Value = words;
                        xlSht.Range["E19"].Value = Convert.ToString(dtCompany.Rows[0]["CompanyName"]);

                        var distinctValues = dt.AsEnumerable().Select(row => row["ItemType"].ToString()).Distinct();
                        Int32 ItemTypeCount = distinctValues.Count();

                        Int32 rowCount = dt.Rows.Count - 1;
                        Int32 ExcelRowCounter = 15;
                        string strItemType = "";
                        string strOldItemType = "";

                        Int32 TotalRows = (rowCount + ItemTypeCount);
                        


                        for (int iRowCounter = 0; iRowCounter <= rowCount; iRowCounter++)
                        {
                            xlSht.Range["B" + ExcelRowCounter].Select();
                            xlSht.Range["B" + ExcelRowCounter].EntireRow.Insert();
                            strItemType = Convert.ToString(dt.Rows[iRowCounter]["ItemType"]);

                            if (strOldItemType == "" || strOldItemType != strItemType)
                            {
                                xlSht.Range["B" + ExcelRowCounter].Value = strItemType;
                                ExcelRowCounter = ExcelRowCounter + 1;
                                xlSht.Range["B" + ExcelRowCounter].EntireRow.Insert();
                            }

                            xlSht.Range["B" + ExcelRowCounter].Select();
                            xlSht.Range["B" + ExcelRowCounter].Value = Convert.ToString(dt.Rows[iRowCounter]["Description"]);
                            xlSht.Range["C" + ExcelRowCounter].Value = Convert.ToString(dt.Rows[iRowCounter]["HSNNumber"]);
                            xlSht.Range["D" + ExcelRowCounter].Value = Convert.ToString(dt.Rows[iRowCounter]["Qty"]);
                            xlSht.Range["E" + ExcelRowCounter].Value = Convert.ToString(dt.Rows[iRowCounter]["Rate"]);
                            xlSht.Range["F" + ExcelRowCounter].Value = Convert.ToString(dt.Rows[iRowCounter]["GST"]);
                            xlSht.Range["G" + ExcelRowCounter].Value = Convert.ToString(dt.Rows[iRowCounter]["Amount"]);

                            strOldItemType = strItemType;
                            ExcelRowCounter = ExcelRowCounter + 1;
                        }

                        double iLastRecordRowNumber = ExcelRowCounter - 1;

                        //Make Record Header in bold font
                        for (int iRowCounter = 15; iRowCounter < iLastRecordRowNumber; iRowCounter++)
                        {
                            string strHSNNumber = Convert.ToString(xlSht.Range["D" + iRowCounter].Value);
                            
                            if (strHSNNumber == "" || strHSNNumber == null)
                            {
                                xlSht.Range["B" + (iRowCounter)].Font.Bold = true;
                            }
                        }

                        //For splitting pages
                        double StartRowNumber = 14;
                        double EndRowNumber = 14;
                        double MaxRecordPerPage = 63;
                        double PageCount = 1;
                        
                        ExcelRowCounter = 15;
                        
                        while (true)
                        {
                            string strDescription = Convert.ToString(xlSht.Range["B" + (ExcelRowCounter)].Value);
                            
                            if (strDescription == "" || strDescription == null)
                            {
                                break;
                            }

                            if (ExcelRowCounter == 61 || ExcelRowCounter == 124 || ExcelRowCounter == 187)
                            {
                                EndRowNumber = ExcelRowCounter + 1;
                                
                                xlSht.Range["B" + ExcelRowCounter].EntireRow.Insert();
                                xlSht.Range["B" + ExcelRowCounter].EntireRow.Insert();
                                xlSht.Range["B" + ExcelRowCounter].EntireRow.Insert();
                                xlSht.Range["B" + ExcelRowCounter].EntireRow.Insert();
                                xlSht.Range["B" + ExcelRowCounter].EntireRow.Insert();

                                Range borderRange = xlSht.Range["B" + (EndRowNumber + 1) + ":G" + (EndRowNumber + 2)];
                                borderRange.Select();
                                borderRange.Borders.LineStyle = XlLineStyle.xlLineStyleNone;

                                borderRange = xlSht.Range["B" + StartRowNumber + ":G" + EndRowNumber];
                                borderRange.Select();
                                FormatRange(borderRange);

                                ExcelRowCounter = ExcelRowCounter + 4;
                                StartRowNumber = ExcelRowCounter;
                                PageCount = PageCount + 1;
                            }

                            ExcelRowCounter = ExcelRowCounter + 1;
                        }
                        
                        EndRowNumber = ExcelRowCounter;

                        double pagelength = 0;
                        double UpperLimit = 0;
                        double LowerLimit = 0;

                        pagelength = (MaxRecordPerPage * PageCount);
                        
                        UpperLimit = pagelength;
                        LowerLimit = pagelength - 7;

                        if (EndRowNumber >= LowerLimit && EndRowNumber < UpperLimit)
                        {
                            double NoOfRecordsToBeInsert = Math.Abs(EndRowNumber - UpperLimit);

                            for (int i = 0; i < NoOfRecordsToBeInsert; i++)
                            {
                                xlSht.Range["B" + EndRowNumber].EntireRow.Insert();
                            }

                            Range borderRange1 = xlSht.Range["B" + pagelength + ":G" + (pagelength + 1)];
                            borderRange1.Select();
                            borderRange1.Borders.LineStyle = XlLineStyle.xlLineStyleNone;
                            
                            FormatRange(xlSht.Range["B" + StartRowNumber + ":G" + (pagelength - 1)]);
                        }
                        else
                        {
                            FormatRange(xlSht.Range["B" + StartRowNumber + ":G" + (EndRowNumber + 1)]);
                        }
                            
                        //XlWbk.PrintOutEx(Copies: 1);
                        string strOutputDir = System.AppDomain.CurrentDomain.BaseDirectory + "Output";
                        
                        if (Directory.Exists(strOutputDir) == false)
                        {
                            Directory.CreateDirectory(strOutputDir);
                        }

                        string strOutputFilePath = strOutputDir + "\\" + common.ChallanNo.Replace("/","");

                        if (File.Exists(strOutputFilePath + ".xlsx"))
                        {
                            File.Delete(strOutputFilePath + ".xlsx");
                        }

                        XlWbk.SaveAs(strOutputFilePath + ".xlsx");
                        XlWbk.ExportAsFixedFormat(XlFixedFormatType.xlTypePDF, strOutputFilePath + ".PDF");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error PrintInvoice: " + ex.ToString(), strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    //Close workbook
                    if (xlSht != null)
                    {
                        xlSht = null;
                    }

                    if (XlWbk != null)
                    {
                        XlWbk.Close(false);
                        XlWbk = null;
                    }

                    if (xlApp != null)
                    {
                        xlApp.Quit();
                        xlApp = null;
                    }

                    killProcessesByName("EXCEL");
                }
                else
                {
                    MessageBox.Show("Invoice template not found.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
            else
            {
                MessageBox.Show("Company details not found.Invoice is not generated.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private static void FormatRange(Range range)
        {
            // Clear diagonal borders
            range.Borders[XlBordersIndex.xlDiagonalDown].LineStyle = XlLineStyle.xlLineStyleNone;
            range.Borders[XlBordersIndex.xlDiagonalUp].LineStyle = XlLineStyle.xlLineStyleNone;

            // Set edge borders
            SetBorder(range.Borders[XlBordersIndex.xlEdgeLeft]);
            SetBorder(range.Borders[XlBordersIndex.xlEdgeTop]);
            SetBorder(range.Borders[XlBordersIndex.xlEdgeBottom]);
            SetBorder(range.Borders[XlBordersIndex.xlEdgeRight]);

            // Clear inside horizontal borders
            range.Borders[XlBordersIndex.xlInsideHorizontal].LineStyle = XlLineStyle.xlLineStyleNone;
        }

        private static void SetBorder(Microsoft.Office.Interop.Excel.Border border)
        {
            border.LineStyle = XlLineStyle.xlContinuous;
            border.ColorIndex = 0;
            border.TintAndShade = 0;
            border.Weight = XlBorderWeight.xlMedium;
        }

        public static DataTable DataGridView_To_Datatable(DataGridView dataGridView)
        {
            // Create a new DataTable
            DataTable dataTable = new DataTable();

            try
            {                
                // Add columns to the DataTable based on the DataGridView columns
                foreach (DataGridViewColumn column in dataGridView.Columns)
                {
                    dataTable.Columns.Add(column.HeaderText, column.ValueType);
                }

                // Add rows to the DataTable from the DataGridView rows
                foreach (DataGridViewRow row in dataGridView.Rows)
                {
                    // Skip the new row placeholder
                    if (!row.IsNewRow)
                    {
                        DataRow dataRow = dataTable.NewRow();
                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            dataRow[cell.ColumnIndex] = cell.Value ?? DBNull.Value;
                        }
                        dataTable.Rows.Add(dataRow);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error." + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return dataTable;
        }

        public static void killProcessesByName(string strProcess)
        {
            try
            {
                Process[] LocalProcesses = Process.GetProcessesByName(strProcess);
                
                foreach (Process item in LocalProcesses)
                {
                    item.Kill();
                }
            }
            catch (Exception)
            {
            }
        }

        public static string EncryptString(string key, string plainText)
        {
            try
            {
                byte[] iv = new byte[16];
                byte[] array;

                using (Aes aes = Aes.Create())
                {
                    aes.Key = Encoding.UTF8.GetBytes(key);
                    aes.IV = iv;

                    ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                    using (MemoryStream memoryStream = new MemoryStream())
                    {
                        using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, encryptor, CryptoStreamMode.Write))
                        {
                            using (StreamWriter streamWriter = new StreamWriter((Stream)cryptoStream))
                            {
                                streamWriter.Write(plainText);
                            }

                            array = memoryStream.ToArray();
                        }
                    }
                }

                return Convert.ToBase64String(array);
            }
            catch (Exception)
            {
                return "";
            }
        }

        public static string DecryptString(string key, string cipherText)
        {
            try
            {
                byte[] iv = new byte[16];
                byte[] buffer = Convert.FromBase64String(cipherText);

                using (Aes aes = Aes.Create())
                {
                    aes.Key = Encoding.UTF8.GetBytes(key);
                    aes.IV = iv;
                    ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                    using (MemoryStream memoryStream = new MemoryStream(buffer))
                    {
                        using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, decryptor, CryptoStreamMode.Read))
                        {
                            using (StreamReader streamReader = new StreamReader((Stream)cryptoStream))
                            {
                                return streamReader.ReadToEnd();
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                return "";
            }
        }
    }
}