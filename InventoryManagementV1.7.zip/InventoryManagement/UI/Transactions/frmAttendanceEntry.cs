﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;
using InventoryManagement.DataAccessLogic;

namespace InventoryManagement.UI
{
    public partial class frmAttendanceEntry : Form
    {
        IGenericRepository<AttendanceModel> objAttendanceDal = null;
        IGenericRepository<EmployeeModel> objEmployeeDal = null;
        bool flag = false;

        public frmAttendanceEntry()
        {
            InitializeComponent();
        }

        private void frmBillList_Load(object sender, EventArgs e)
        {
            objAttendanceDal = new AttendanceDAL();
            objEmployeeDal = new EmployeeDAL();

            List<EmployeeModel> empList = objEmployeeDal.GetAll();
            
            cboEmployee.DataSource = empList;
            cboEmployee.DisplayMember = "EmployeeName";
            cboEmployee.ValueMember = "EmployeeID";
            
            clearfields();
            flag = true;
        }
        
        private void cboEmployee_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (flag)
            {
                if (cboEmployee.SelectedIndex != -1)
                {
                    txtCheckIn.Text = "";
                    txtCheckOut.Text = "";

                    List<AttendanceModel> attendances = objAttendanceDal.GetAll();

                    List<AttendanceModel> attendance = attendances.Where(x => x.EmployeeID == Convert.ToString(cboEmployee.SelectedValue) && Convert.ToDateTime(x.AttendanceDate) == Convert.ToDateTime(dtpAttendanceDate.Text)).ToList();

                    if (attendance.Count <= 0)
                    {
                        txtCheckIn.Text = Convert.ToString(DateTime.Now.ToString("HH:mm"));
                        txtCheckIn.ReadOnly = false;
                        txtCheckOut.ReadOnly = true;
                        txtCheckIn.Focus();
                        btnCheckIn.Enabled = true;
                    }
                    else
                    {
                        txtCheckIn.Text = Convert.ToString(attendance[0].CheckIn);
                        txtCheckOut.Text = Convert.ToString(attendance[0].CheckOut);
                        
                        if (txtCheckOut.Text == "")
                        {
                            txtCheckOut.Text = Convert.ToString(DateTime.Now.ToString("HH:mm"));
                            txtCheckOut.ReadOnly = false;
                            txtCheckIn.ReadOnly = true;
                            txtCheckOut.Focus();
                            btnCheckOut.Enabled = true;
                        }
                        else
                        {
                            txtCheckOut.ReadOnly = true;
                            txtCheckIn.ReadOnly = true;
                            cboEmployee.Focus();
                            btnCheckOut.Enabled = false;
                        }
                    }
                }
            }
        }

        private void btnCheckIn_Click(object sender, EventArgs e)
        {
            if(txtCheckIn.Text != "")
            {
                if (ValidateTimeFormat(txtCheckIn.Text))
                {
                    AttendanceModel objAttendance = new AttendanceModel();
                    objAttendance.AttendanceDate = dtpAttendanceDate.Text;
                    objAttendance.EmployeeID = Convert.ToString(cboEmployee.SelectedValue);
                    objAttendance.CheckIn = txtCheckIn.Text.Trim();
                    objAttendance.CheckOut = txtCheckOut.Text.Trim();
                    objAttendance.Status = "Present";
                    objAttendance.CreatedBy = common.strUserEmail;

                    objAttendanceDal.Add(objAttendance);
                    clearfields();
                }
            }
            else
            {
                txtCheckIn.Focus();
                MessageBox.Show("Please enter check in time.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            if (txtCheckOut.Text != "")
            {
                if (ValidateTimeFormat(txtCheckOut.Text))
                {
                    AttendanceModel objAttendance = new AttendanceModel();
                    objAttendance.AttendanceDate = dtpAttendanceDate.Text;
                    objAttendance.EmployeeID = Convert.ToString(cboEmployee.SelectedValue);
                    objAttendance.CheckIn = txtCheckIn.Text.Trim();
                    objAttendance.CheckOut = txtCheckOut.Text.Trim();
                    objAttendance.Status = "Present";
                    objAttendance.CreatedBy = common.strUserEmail;

                    objAttendanceDal.Update(objAttendance);

                    clearfields();
                }
            }
            else
            {
                txtCheckOut.Focus();
                MessageBox.Show("Please enter check out time.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void clearfields()
        {
            cboEmployee.SelectedIndex = -1;
            txtCheckIn.Text = "";
            txtCheckOut.Text = "";
            txtCheckIn.ReadOnly = true;
            txtCheckOut.ReadOnly = true;
            btnCheckIn.Enabled = false;
            btnCheckOut.Enabled = false;
            cboEmployee.Focus();
        }

        private Boolean ValidateTimeFormat(string strTime)
        {
            string strCheckInTime = strTime;
            string[] ArrCheckInTime = strCheckInTime.Split(':');
            
            if (ArrCheckInTime.Length == 2)
            {
                Int32 strHrs = Convert.ToInt32(ArrCheckInTime[0]);
                Int32 strMins = Convert.ToInt32(ArrCheckInTime[1]);

                if (strHrs > 24)
                {
                    MessageBox.Show("Hours can not be greater than 24.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return false;
                }

                if (strMins > 60)
                {
                    MessageBox.Show("Minutes can not be greater than 60.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return false;
                }

                return true;
            }
            else
            {
                MessageBox.Show("Incorrect time format.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
