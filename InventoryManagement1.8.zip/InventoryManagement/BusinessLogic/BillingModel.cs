﻿
using System;

namespace InventoryManagement.BusinessLogic
{
    public class BillingModel
    {
        public string ChallanNo { get; set; }
        public DateTime ChallanDate { get; set; }
        public Int32 CustomerCode { get; set; }
        public string CustomerName { get; set; }
        public double ChallanAmount { get; set; }
        public double PaidAmount { get; set; }
        public double PendingAmount { get; set; }
    }
}
