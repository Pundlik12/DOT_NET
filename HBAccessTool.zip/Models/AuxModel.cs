﻿using System;

namespace HBAccessTool
{
    public class AuxModel
    {
        public int AuxDetailsID { get; set; }
        public int UserID { get; set; }
        public string AuxName { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public int ParentAuxDetailsID { get; set; }
    }
}
