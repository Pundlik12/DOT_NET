﻿using System;
using System.Data;
using System.Windows.Forms;
using ECMS_Ryder.HelperClasses;
using ECMS_Ryder.Repositories;

namespace ECMS_Ryder.Forms
{
    public partial class frmSummaryReport : Form
    {
        private readonly SummaryReportRepository _repository;
        private readonly clsExcelLayer objClsExcelLayer;
        private DataTable data = new DataTable();

        public frmSummaryReport()
        {
            InitializeComponent();

            _repository = new SummaryReportRepository(clsDBConnection.strConnectionString);
            objClsExcelLayer = new clsExcelLayer();
        }

        private void rbEmailWise_CheckedChanged(object sender, EventArgs e)
        {
            dgvEmails.DataSource = null;
            data = null;
        }

        private void rbReceivedDateWise_CheckedChanged(object sender, EventArgs e)
        {
            dgvEmails.DataSource = null;
            data = null;
        }

        private void rbAssignedUserWise_CheckedChanged(object sender, EventArgs e)
        {
            dgvEmails.DataSource = null;
            data = null;
        }

        private void btnView_Click(object sender, System.EventArgs e)
        {
            DisplayData();
        }

        private void btnDownload_Click(object sender, EventArgs e)
        {
            if (dgvEmails.Rows.Count == 0)
            {
                DisplayData();
            }
            
            string strOutputFilePath = System.AppDomain.CurrentDomain.BaseDirectory + "Summary Reports";

            if (System.IO.Directory.Exists(strOutputFilePath) == false)
            {
                System.IO.Directory.CreateDirectory(strOutputFilePath);
            }

            if (rbAssignedUserWise.Checked == true)
            {
                strOutputFilePath = strOutputFilePath + "\\AssignedUserWise_" + DateTime.Now.ToString("ddMMMyyyy HHmmss") + ".xlsx";
            }
            else if (rbEmailWise.Checked == true)
            {
                strOutputFilePath = strOutputFilePath + "\\EmailWise_" + DateTime.Now.ToString("ddMMMyyyy HHmmss") + ".xlsx";
            }
            else if (rbReceivedDateWise.Checked == true)
            {
                strOutputFilePath = strOutputFilePath + "\\ReceivedDateWise_" + DateTime.Now.ToString("ddMMMyyyy HHmmss") + ".xlsx";
            }
                
            objClsExcelLayer.ExportToExcel(data, strOutputFilePath);            
        }

        private void DisplayData()
        {
            Cursor = Cursors.WaitCursor;
            Int32 iColumnCounter = dgvEmails.Columns.Count;

            for (int i = 0; i < iColumnCounter; i++)
            {
                dgvEmails.Columns.RemoveAt(0);
            }

            if (rbReceivedDateWise.Checked == true)
            {
                data = _repository.ReceivedDateWiseSummaryReport();
            }
            else if (rbAssignedUserWise.Checked == true)
            {
                data = _repository.AssignedUserWiseSummaryReport();
            }
            else
            {
                data = _repository.EmailWiseSummaryReport();
            }

            dgvEmails.DataSource = data;
            Cursor = Cursors.Default;
        }

    }
}
