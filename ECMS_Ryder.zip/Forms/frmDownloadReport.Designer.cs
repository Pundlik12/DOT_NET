﻿namespace ECMS_Ryder.Forms
{
    partial class frmDownloadReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dgvEmails = new System.Windows.Forms.DataGridView();
            this.EmailDetailsId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmailAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FolderName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SenderName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SenderEmailAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.To = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Bcc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReceivedTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Subject = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Body = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Priority = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HasAttachments = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EntryID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ConversationID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SyncBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SyncDateTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastUpdatedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastUpdatedDateTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssignTo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssignedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssignedDateTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblEmailsCount = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rbUnAssigned = new System.Windows.Forms.RadioButton();
            this.rbCompleted = new System.Windows.Forms.RadioButton();
            this.rbAssigned = new System.Windows.Forms.RadioButton();
            this.rbAll = new System.Windows.Forms.RadioButton();
            this.btnDownload = new System.Windows.Forms.Button();
            this.btnView = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmails)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dgvEmails);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(0, 136);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Size = new System.Drawing.Size(1437, 625);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Data";
            // 
            // dgvEmails
            // 
            this.dgvEmails.AllowUserToAddRows = false;
            this.dgvEmails.AllowUserToDeleteRows = false;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEmails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvEmails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EmailDetailsId,
            this.EmailAddress,
            this.FolderName,
            this.SenderName,
            this.SenderEmailAddress,
            this.To,
            this.CC,
            this.Bcc,
            this.ReceivedTime,
            this.Subject,
            this.Body,
            this.Priority,
            this.HasAttachments,
            this.EntryID,
            this.ConversationID,
            this.Status,
            this.SyncBy,
            this.SyncDateTime,
            this.LastUpdatedBy,
            this.LastUpdatedDateTime,
            this.AssignTo,
            this.AssignedBy,
            this.AssignedDateTime});
            this.dgvEmails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvEmails.Location = new System.Drawing.Point(3, 22);
            this.dgvEmails.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvEmails.MultiSelect = false;
            this.dgvEmails.Name = "dgvEmails";
            this.dgvEmails.ReadOnly = true;
            this.dgvEmails.RowHeadersVisible = false;
            this.dgvEmails.RowHeadersWidth = 51;
            this.dgvEmails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEmails.Size = new System.Drawing.Size(1431, 601);
            this.dgvEmails.TabIndex = 0;
            // 
            // EmailDetailsId
            // 
            this.EmailDetailsId.DataPropertyName = "EmailDetailsId";
            this.EmailDetailsId.HeaderText = "EmailId";
            this.EmailDetailsId.MinimumWidth = 6;
            this.EmailDetailsId.Name = "EmailDetailsId";
            this.EmailDetailsId.ReadOnly = true;
            this.EmailDetailsId.Width = 93;
            // 
            // EmailAddress
            // 
            this.EmailAddress.DataPropertyName = "EmailAddress";
            this.EmailAddress.HeaderText = "Email Address";
            this.EmailAddress.MinimumWidth = 6;
            this.EmailAddress.Name = "EmailAddress";
            this.EmailAddress.ReadOnly = true;
            this.EmailAddress.Width = 135;
            // 
            // FolderName
            // 
            this.FolderName.DataPropertyName = "FolderName";
            this.FolderName.HeaderText = "Folder Name";
            this.FolderName.MinimumWidth = 6;
            this.FolderName.Name = "FolderName";
            this.FolderName.ReadOnly = true;
            this.FolderName.Width = 123;
            // 
            // SenderName
            // 
            this.SenderName.DataPropertyName = "SenderName";
            this.SenderName.HeaderText = "Sender Name";
            this.SenderName.MinimumWidth = 6;
            this.SenderName.Name = "SenderName";
            this.SenderName.ReadOnly = true;
            this.SenderName.Width = 128;
            // 
            // SenderEmailAddress
            // 
            this.SenderEmailAddress.DataPropertyName = "SenderEmailAddress";
            this.SenderEmailAddress.HeaderText = "Sender Email Address";
            this.SenderEmailAddress.MinimumWidth = 6;
            this.SenderEmailAddress.Name = "SenderEmailAddress";
            this.SenderEmailAddress.ReadOnly = true;
            this.SenderEmailAddress.Width = 187;
            // 
            // To
            // 
            this.To.DataPropertyName = "To";
            this.To.HeaderText = "To";
            this.To.MinimumWidth = 6;
            this.To.Name = "To";
            this.To.ReadOnly = true;
            this.To.Width = 57;
            // 
            // CC
            // 
            this.CC.DataPropertyName = "CC";
            this.CC.HeaderText = "CC";
            this.CC.MinimumWidth = 6;
            this.CC.Name = "CC";
            this.CC.ReadOnly = true;
            this.CC.Width = 62;
            // 
            // Bcc
            // 
            this.Bcc.DataPropertyName = "Bcc";
            this.Bcc.HeaderText = "Bcc";
            this.Bcc.MinimumWidth = 6;
            this.Bcc.Name = "Bcc";
            this.Bcc.ReadOnly = true;
            this.Bcc.Width = 68;
            // 
            // ReceivedTime
            // 
            this.ReceivedTime.DataPropertyName = "ReceivedTime";
            this.ReceivedTime.HeaderText = "Received Time";
            this.ReceivedTime.MinimumWidth = 6;
            this.ReceivedTime.Name = "ReceivedTime";
            this.ReceivedTime.ReadOnly = true;
            this.ReceivedTime.Width = 137;
            // 
            // Subject
            // 
            this.Subject.DataPropertyName = "Subject";
            this.Subject.HeaderText = "Subject";
            this.Subject.MinimumWidth = 6;
            this.Subject.Name = "Subject";
            this.Subject.ReadOnly = true;
            this.Subject.Width = 94;
            // 
            // Body
            // 
            this.Body.DataPropertyName = "Body";
            this.Body.HeaderText = "Body";
            this.Body.MinimumWidth = 6;
            this.Body.Name = "Body";
            this.Body.ReadOnly = true;
            this.Body.Width = 76;
            // 
            // Priority
            // 
            this.Priority.DataPropertyName = "Priority";
            this.Priority.HeaderText = "Priority";
            this.Priority.MinimumWidth = 6;
            this.Priority.Name = "Priority";
            this.Priority.ReadOnly = true;
            this.Priority.Width = 91;
            // 
            // HasAttachments
            // 
            this.HasAttachments.DataPropertyName = "HasAttachments";
            this.HasAttachments.HeaderText = "Has Attachments";
            this.HasAttachments.MinimumWidth = 6;
            this.HasAttachments.Name = "HasAttachments";
            this.HasAttachments.ReadOnly = true;
            this.HasAttachments.Width = 154;
            // 
            // EntryID
            // 
            this.EntryID.DataPropertyName = "EntryID";
            this.EntryID.HeaderText = "Entry ID";
            this.EntryID.MinimumWidth = 6;
            this.EntryID.Name = "EntryID";
            this.EntryID.ReadOnly = true;
            this.EntryID.Width = 92;
            // 
            // ConversationID
            // 
            this.ConversationID.DataPropertyName = "ConversationID";
            this.ConversationID.HeaderText = "Conversation ID";
            this.ConversationID.MinimumWidth = 6;
            this.ConversationID.Name = "ConversationID";
            this.ConversationID.ReadOnly = true;
            this.ConversationID.Width = 145;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.MinimumWidth = 6;
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.Width = 86;
            // 
            // SyncBy
            // 
            this.SyncBy.DataPropertyName = "SyncBy";
            this.SyncBy.HeaderText = "Sync By";
            this.SyncBy.MinimumWidth = 6;
            this.SyncBy.Name = "SyncBy";
            this.SyncBy.ReadOnly = true;
            this.SyncBy.Width = 92;
            // 
            // SyncDateTime
            // 
            this.SyncDateTime.DataPropertyName = "SyncDateTime";
            this.SyncDateTime.HeaderText = "Sync DateTime";
            this.SyncDateTime.MinimumWidth = 6;
            this.SyncDateTime.Name = "SyncDateTime";
            this.SyncDateTime.ReadOnly = true;
            this.SyncDateTime.Width = 140;
            // 
            // LastUpdatedBy
            // 
            this.LastUpdatedBy.DataPropertyName = "LastUpdatedBy";
            this.LastUpdatedBy.HeaderText = "Last Updated By";
            this.LastUpdatedBy.MinimumWidth = 6;
            this.LastUpdatedBy.Name = "LastUpdatedBy";
            this.LastUpdatedBy.ReadOnly = true;
            this.LastUpdatedBy.Width = 131;
            // 
            // LastUpdatedDateTime
            // 
            this.LastUpdatedDateTime.DataPropertyName = "LastUpdatedDateTime";
            this.LastUpdatedDateTime.HeaderText = "Last Updated DateTime";
            this.LastUpdatedDateTime.MinimumWidth = 6;
            this.LastUpdatedDateTime.Name = "LastUpdatedDateTime";
            this.LastUpdatedDateTime.ReadOnly = true;
            this.LastUpdatedDateTime.Width = 197;
            // 
            // AssignTo
            // 
            this.AssignTo.DataPropertyName = "AssignTo";
            this.AssignTo.HeaderText = "Assign To";
            this.AssignTo.MinimumWidth = 6;
            this.AssignTo.Name = "AssignTo";
            this.AssignTo.ReadOnly = true;
            this.AssignTo.Width = 104;
            // 
            // AssignedBy
            // 
            this.AssignedBy.DataPropertyName = "AssignedBy";
            this.AssignedBy.HeaderText = "Assigned By";
            this.AssignedBy.MinimumWidth = 6;
            this.AssignedBy.Name = "AssignedBy";
            this.AssignedBy.ReadOnly = true;
            this.AssignedBy.Width = 121;
            // 
            // AssignedDateTime
            // 
            this.AssignedDateTime.DataPropertyName = "AssignedDateTime";
            this.AssignedDateTime.HeaderText = "Assigned DateTime";
            this.AssignedDateTime.MinimumWidth = 6;
            this.AssignedDateTime.Name = "AssignedDateTime";
            this.AssignedDateTime.ReadOnly = true;
            this.AssignedDateTime.Width = 169;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblEmailsCount);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.rbUnAssigned);
            this.groupBox1.Controls.Add(this.rbCompleted);
            this.groupBox1.Controls.Add(this.rbAssigned);
            this.groupBox1.Controls.Add(this.rbAll);
            this.groupBox1.Controls.Add(this.btnDownload);
            this.groupBox1.Controls.Add(this.btnView);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(0, 53);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(1437, 83);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // lblEmailsCount
            // 
            this.lblEmailsCount.AutoSize = true;
            this.lblEmailsCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailsCount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblEmailsCount.Location = new System.Drawing.Point(1358, 32);
            this.lblEmailsCount.Name = "lblEmailsCount";
            this.lblEmailsCount.Size = new System.Drawing.Size(26, 29);
            this.lblEmailsCount.TabIndex = 7;
            this.lblEmailsCount.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1179, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 29);
            this.label2.TabIndex = 6;
            this.label2.Text = "Emails Count:-";
            // 
            // rbUnAssigned
            // 
            this.rbUnAssigned.AutoSize = true;
            this.rbUnAssigned.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbUnAssigned.Location = new System.Drawing.Point(123, 30);
            this.rbUnAssigned.Name = "rbUnAssigned";
            this.rbUnAssigned.Size = new System.Drawing.Size(164, 33);
            this.rbUnAssigned.TabIndex = 1;
            this.rbUnAssigned.Text = "UnAssigned";
            this.rbUnAssigned.UseVisualStyleBackColor = true;
            this.rbUnAssigned.CheckedChanged += new System.EventHandler(this.rbUnAssigned_CheckedChanged);
            // 
            // rbCompleted
            // 
            this.rbCompleted.AutoSize = true;
            this.rbCompleted.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbCompleted.Location = new System.Drawing.Point(463, 30);
            this.rbCompleted.Name = "rbCompleted";
            this.rbCompleted.Size = new System.Drawing.Size(153, 33);
            this.rbCompleted.TabIndex = 3;
            this.rbCompleted.TabStop = true;
            this.rbCompleted.Text = "Completed";
            this.rbCompleted.UseVisualStyleBackColor = true;
            this.rbCompleted.CheckedChanged += new System.EventHandler(this.rbCompleted_CheckedChanged);
            // 
            // rbAssigned
            // 
            this.rbAssigned.AutoSize = true;
            this.rbAssigned.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbAssigned.Location = new System.Drawing.Point(308, 30);
            this.rbAssigned.Name = "rbAssigned";
            this.rbAssigned.Size = new System.Drawing.Size(134, 33);
            this.rbAssigned.TabIndex = 2;
            this.rbAssigned.Text = "Assigned";
            this.rbAssigned.UseVisualStyleBackColor = true;
            this.rbAssigned.CheckedChanged += new System.EventHandler(this.rbAssigned_CheckedChanged);
            // 
            // rbAll
            // 
            this.rbAll.AutoSize = true;
            this.rbAll.Checked = true;
            this.rbAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbAll.Location = new System.Drawing.Point(41, 30);
            this.rbAll.Name = "rbAll";
            this.rbAll.Size = new System.Drawing.Size(61, 33);
            this.rbAll.TabIndex = 0;
            this.rbAll.TabStop = true;
            this.rbAll.Text = "All";
            this.rbAll.UseVisualStyleBackColor = true;
            this.rbAll.CheckedChanged += new System.EventHandler(this.rbAll_CheckedChanged);
            // 
            // btnDownload
            // 
            this.btnDownload.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnDownload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDownload.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDownload.Location = new System.Drawing.Point(858, 24);
            this.btnDownload.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDownload.Name = "btnDownload";
            this.btnDownload.Size = new System.Drawing.Size(184, 47);
            this.btnDownload.TabIndex = 5;
            this.btnDownload.Text = "Download";
            this.btnDownload.UseVisualStyleBackColor = false;
            this.btnDownload.Click += new System.EventHandler(this.btnDownload_Click);
            // 
            // btnView
            // 
            this.btnView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnView.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnView.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnView.Location = new System.Drawing.Point(671, 24);
            this.btnView.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(173, 47);
            this.btnView.TabIndex = 4;
            this.btnView.Text = "View";
            this.btnView.UseVisualStyleBackColor = false;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1437, 53);
            this.label1.TabIndex = 0;
            this.label1.Text = "Download Report";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmDownloadReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1437, 753);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "frmDownloadReport";
            this.ShowIcon = false;
            this.Text = "Download Report";
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmails)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dgvEmails;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDownload;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.RadioButton rbAll;
        private System.Windows.Forms.RadioButton rbAssigned;
        private System.Windows.Forms.RadioButton rbCompleted;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmailDetailsId;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmailAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn FolderName;
        private System.Windows.Forms.DataGridViewTextBoxColumn SenderName;
        private System.Windows.Forms.DataGridViewTextBoxColumn SenderEmailAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn To;
        private System.Windows.Forms.DataGridViewTextBoxColumn CC;
        private System.Windows.Forms.DataGridViewTextBoxColumn Bcc;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReceivedTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn Subject;
        private System.Windows.Forms.DataGridViewTextBoxColumn Body;
        private System.Windows.Forms.DataGridViewTextBoxColumn Priority;
        private System.Windows.Forms.DataGridViewTextBoxColumn HasAttachments;
        private System.Windows.Forms.DataGridViewTextBoxColumn EntryID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ConversationID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn SyncBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn SyncDateTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn LastUpdatedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn LastUpdatedDateTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn AssignTo;
        private System.Windows.Forms.DataGridViewTextBoxColumn AssignedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn AssignedDateTime;
        private System.Windows.Forms.RadioButton rbUnAssigned;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblEmailsCount;
    }
}