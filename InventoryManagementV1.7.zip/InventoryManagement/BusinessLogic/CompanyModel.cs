﻿
namespace InventoryManagement.BusinessLogic
{
    public class CompanyModel
    {
        public int Code { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string PinCode { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string GSTNo { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDateTime { get; set; }
    }
}
