﻿
namespace ECMS_Ryder.Models
{
    internal class CPIMDetails
    {
        public int CPIMDetailsID { get; set; }
        public string HQNBR { get; set; }
        public string CustomerName { get; set; }
        public string AssignToUserName { get; set; }
        public string AssignToUID { get; set; }
        public string UploadUser { get; set; }
        public string UploadDateTime { get; set; }
    }
}
