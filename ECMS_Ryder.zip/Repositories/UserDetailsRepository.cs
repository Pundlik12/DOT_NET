﻿using System;
using System.Data;
using System.Data.OleDb;
using ECMS_Ryder.Models;
using System.Collections.Generic;
using System.Windows.Forms;
using ECMS_Ryder.HelperClasses;

namespace ECMS_Ryder.Repositories
{
    interface iUserDetailsRepository
    {
        List<UserDetails> GetAllUsers();
        UserDetails GetUserByUID(string UserID);
        Boolean CheckUserExists(string UserID);
        void RegisterUser(UserDetails user);
        void UpdateUser(UserDetails user);
        void DeleteUser(string strUID);
    }

    internal class UserDetailsRepository : iUserDetailsRepository
    {
        private readonly string strConnectionString = "";

        public UserDetailsRepository(string _strConnectionString)
        {
            strConnectionString = _strConnectionString;
        }

        public List<UserDetails> GetAllUsers()
        {
            List<UserDetails> users = new List<UserDetails>();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "GetAllUsers";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;

                    OleDbDataReader OleDbDataReader = cmd.ExecuteReader();

                    while (OleDbDataReader.Read())
                    {
                        UserDetails userDetails = new UserDetails();
                        userDetails.UserId = Convert.ToInt32(OleDbDataReader["UserId"]);
                        userDetails.UID = Convert.ToString(OleDbDataReader["UID"]);
                        userDetails.UserName = Convert.ToString(OleDbDataReader["UserName"]);

                        if (Convert.ToString(OleDbDataReader["Role"]) == UserRole.Admin.ToString())
                        {
                            userDetails.Role = UserRole.Admin.ToString();
                        }
                        else
                        {
                            userDetails.Role = UserRole.Associate.ToString();
                        }

                        if (Convert.ToString(OleDbDataReader["IsActive"]) == UserStatus.Active.ToString())
                        {
                            userDetails.IsActive = UserStatus.Active.ToString();
                        }
                        else
                        {
                            userDetails.IsActive = UserStatus.InActive.ToString();
                        }

                        userDetails.EntryUser = Convert.ToString(OleDbDataReader["EntryUser"]);
                        userDetails.EntryDateTime = Convert.ToString(OleDbDataReader["EntryDateTime"]);
                        
                        users.Add(userDetails);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetAllUsers:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                users = null;
            }

            return users;
        }

        public UserDetails GetUserByUID(string UserID)
        {
            UserDetails userDetails = new UserDetails();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "GetUserByUID";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UID", UserID);

                    OleDbDataReader OleDbDataReader = cmd.ExecuteReader();

                    while (OleDbDataReader.Read())
                    {                        
                        userDetails.UserId = Convert.ToInt32(OleDbDataReader["UserId"]);
                        userDetails.UID = Convert.ToString(OleDbDataReader["UID"]);
                        userDetails.UserName = Convert.ToString(OleDbDataReader["UserName"]);

                        if (Convert.ToString(OleDbDataReader["Role"]) == UserRole.Admin.ToString())
                        {
                            userDetails.Role = UserRole.Admin.ToString();
                        }
                        else
                        {
                            userDetails.Role = UserRole.Associate.ToString();
                        }

                        if (Convert.ToString(OleDbDataReader["IsActive"]) == UserStatus.Active.ToString())
                        {
                            userDetails.IsActive = UserStatus.Active.ToString();
                        }
                        else
                        {
                            userDetails.IsActive = UserStatus.InActive.ToString();
                        }

                        userDetails.EntryUser = Convert.ToString(OleDbDataReader["EntryUser"]);
                        userDetails.EntryDateTime = Convert.ToString(OleDbDataReader["EntryDateTime"]);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetUserByUID:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return userDetails;
        }

        public bool CheckUserExists(string UserID)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "GetUserByUID";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UID", UserID);
                    
                    OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter(cmd);
                    DataTable dataTable = new DataTable();

                    oleDbDataAdapter.Fill(dataTable);
                    
                    if (dataTable.Rows.Count > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                clsDBConnection.strErrorMsg = ex.ToString();
                MessageBox.Show("Error in CheckUserExists:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        public void DeleteUser(string strUID)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "DeleteUser";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UID", strUID);

                    cmd.ExecuteNonQuery();

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in DeleteUser:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void RegisterUser(UserDetails user)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "RegisterUser";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@UID", user.UID);
                    cmd.Parameters.AddWithValue("@UserName", user.UserName);
                    cmd.Parameters.AddWithValue("@Role", user.Role);
                    cmd.Parameters.AddWithValue("@IsActive", user.IsActive);
                    cmd.Parameters.AddWithValue("@EntryUser", clsDBConnection.strLoggedInUID);
                    cmd.Parameters.AddWithValue("@EntryDateTime", user.EntryDateTime);

                    cmd.ExecuteNonQuery();

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in RegisterUser:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void UpdateUser(UserDetails user)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "UpdateUser";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@UserName", user.UserName);
                    cmd.Parameters.AddWithValue("@Role", user.Role);
                    cmd.Parameters.AddWithValue("@IsActive", user.IsActive);
                    cmd.Parameters.AddWithValue("@EntryUser", clsDBConnection.strLoggedInUID);
                    cmd.Parameters.AddWithValue("@EntryDateTime", user.EntryDateTime);
                    cmd.Parameters.AddWithValue("@UID", user.UID);

                    cmd.ExecuteNonQuery();

                    connection.Close();
                }                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in UpdateUser:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
