﻿using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.IO.Compression;
using System.Windows.Forms;
using System.Configuration;
using System.Security.Cryptography;

namespace UnifeederAutomation
{
    public class clsCommon
    {
        static string strProjectTitle = ConfigurationManager.AppSettings["ProjectName"].ToString();

        public static void CheckApplicationIsRunning(string strApplicationName)
        {
            System.Threading.Mutex mutex = new System.Threading.Mutex(true, strApplicationName, out bool flag);

            if (!flag)
            {
                MessageBox.Show("Application is already running.", strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Environment.Exit(1);
            }
        }

        public static void CheckLicense()
        {
            string strLicenseDate = System.Configuration.ConfigurationManager.AppSettings["LDate"].ToString();
            var key = "b14ca5898a4e4133bbce2ea2315a1916";
            strLicenseDate = clsCommon.DecryptString(key, strLicenseDate);
            
            try
            {
                DateTime.Parse(strLicenseDate);
            }
            catch (Exception)
            {
                MessageBox.Show($"Invalid Expiry Date.", strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Environment.Exit(Environment.ExitCode);
            }

            //string strLicenseDate = System.Configuration.ConfigurationManager.AppSettings["LDate"].ToString();
            Int32 strAlertDays = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["AlertDaysBefore"].ToString());

            DateTime enDate = DateTime.Parse(strLicenseDate);
            DateTime today = DateTime.Today;
            double daysremain = (enDate - today).TotalDays;

            if (daysremain <= strAlertDays && daysremain >= 0)
            {
                MessageBox.Show($"Your software license will expire in {daysremain} Days.", strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            if (enDate < DateTime.Today)
            {
                MessageBox.Show("Your software license is expired." + Environment.NewLine + Environment.NewLine + "Please Contact to Administrator", strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Environment.Exit(Environment.ExitCode);
            }
        }

        public static void WriteLog(string textToWrite)
	    {
		    string strFilePath = System.AppDomain.CurrentDomain.BaseDirectory + @"Log\";
            if (System.IO.Directory.Exists(strFilePath) == false)
            {
                System.IO.Directory.CreateDirectory(strFilePath);
            }

            using (StreamWriter sw = new StreamWriter(strFilePath + @"\Log.txt", true))
            {
                sw.WriteLine(textToWrite);
                sw.WriteLine("==================================================== " + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));
            }
        }

        public static List<string> GetAllFiles(string strFilePath,string strExtention = "txt")
	    {
            List<string> lstFiles = new List<string>();
            try
            {
                DirectoryInfo d = new DirectoryInfo(strFilePath);
                FileInfo[] Files = d.GetFiles("*." + strExtention);

                foreach (FileInfo file in Files)
                {
                    lstFiles.Add(file.Name);
                }
            }
            catch (Exception ex)
            {
                WriteLog("Error In GetAllFiles Function:- " + ex.ToString());
            }

		    return lstFiles;
	    }

        public static void ExtractZipFiles(string strFilePath)
        {
            try
            {
                string destFolder = System.IO.Path.GetDirectoryName(strFilePath) + @"\" + System.IO.Path.GetFileNameWithoutExtension(strFilePath);

                if (System.IO.Directory.Exists(destFolder) == false)
                {
                    System.IO.Directory.CreateDirectory(destFolder);
                }

                using (ZipArchive archive = ZipFile.OpenRead(strFilePath))
                {
                    foreach (ZipArchiveEntry entry in archive.Entries)
                    {
                        //entry.ExtractToFile(Path.Combine(destFolder, entry.FullName));
                        entry.ExtractToFile(Path.Combine(destFolder, entry.Name));
                    }
                }
            }
            catch (Exception ex)
            {
                WriteLog("Error in ExtractZipFiles function:- " + ex.ToString());
            }
        }

        public static void DeleteFolder(string strFilePath)
        {
            try
            {
                System.IO.DirectoryInfo di = new DirectoryInfo(strFilePath);

                foreach (FileInfo file in di.GetFiles())
                {
                    file.Delete();
                }

                foreach (DirectoryInfo dir in di.GetDirectories())
                {
                    dir.Delete(true);
                }
            }
            catch (Exception ex)
            {
                WriteLog("Error In DeleteFolder Function:- " + ex.ToString());
            }
        }

        public static string EncryptString(string key, string plainText)
        {
            try
            {
                byte[] iv = new byte[16];
                byte[] array;

                using (Aes aes = Aes.Create())
                {
                    aes.Key = Encoding.UTF8.GetBytes(key);
                    aes.IV = iv;

                    ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                    using (MemoryStream memoryStream = new MemoryStream())
                    {
                        using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, encryptor, CryptoStreamMode.Write))
                        {
                            using (StreamWriter streamWriter = new StreamWriter((Stream)cryptoStream))
                            {
                                streamWriter.Write(plainText);
                            }

                            array = memoryStream.ToArray();
                        }
                    }
                }

                return Convert.ToBase64String(array);
            }
            catch (Exception)
            {
                return "";
            }
        }

        public static string DecryptString(string key, string cipherText)
        {
            try
            {
                byte[] iv = new byte[16];
                byte[] buffer = Convert.FromBase64String(cipherText);

                using (Aes aes = Aes.Create())
                {
                    aes.Key = Encoding.UTF8.GetBytes(key);
                    aes.IV = iv;
                    ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                    using (MemoryStream memoryStream = new MemoryStream(buffer))
                    {
                        using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, decryptor, CryptoStreamMode.Read))
                        {
                            using (StreamReader streamReader = new StreamReader((Stream)cryptoStream))
                            {
                                return streamReader.ReadToEnd();
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                return "";
            }
        }
    }
}
