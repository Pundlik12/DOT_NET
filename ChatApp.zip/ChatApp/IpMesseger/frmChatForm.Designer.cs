﻿namespace ChatApp
{
    partial class frmChatForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSendFile = new Button();
            btnSend = new Button();
            txtMessage = new TextBox();
            txtChat = new TextBox();
            btnAddIpAddress = new Button();
            cboUserName = new ComboBox();
            label1 = new Label();
            label2 = new Label();
            txtIPAddress = new TextBox();
            txtHostName = new TextBox();
            label3 = new Label();
            SuspendLayout();
            // 
            // btnSendFile
            // 
            btnSendFile.Location = new Point(109, 431);
            btnSendFile.Name = "btnSendFile";
            btnSendFile.Size = new Size(91, 41);
            btnSendFile.TabIndex = 7;
            btnSendFile.Text = "Send File";
            btnSendFile.UseVisualStyleBackColor = true;
            btnSendFile.Click += btnSendFile_Click;
            // 
            // btnSend
            // 
            btnSend.Location = new Point(4, 431);
            btnSend.Name = "btnSend";
            btnSend.Size = new Size(91, 41);
            btnSend.TabIndex = 5;
            btnSend.Text = "&Send";
            btnSend.UseVisualStyleBackColor = true;
            btnSend.Click += btnSendMessage_Click;
            // 
            // txtMessage
            // 
            txtMessage.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtMessage.Location = new Point(5, 397);
            txtMessage.Name = "txtMessage";
            txtMessage.Size = new Size(458, 27);
            txtMessage.TabIndex = 4;
            // 
            // txtChat
            // 
            txtChat.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtChat.Location = new Point(5, 120);
            txtChat.Multiline = true;
            txtChat.Name = "txtChat";
            txtChat.Size = new Size(458, 269);
            txtChat.TabIndex = 8;
            // 
            // btnAddIpAddress
            // 
            btnAddIpAddress.Location = new Point(430, 4);
            btnAddIpAddress.Name = "btnAddIpAddress";
            btnAddIpAddress.Size = new Size(34, 41);
            btnAddIpAddress.TabIndex = 10;
            btnAddIpAddress.Text = "......";
            btnAddIpAddress.UseVisualStyleBackColor = true;
            btnAddIpAddress.Click += btnAddIpAddress_Click;
            // 
            // cboUserName
            // 
            cboUserName.DropDownStyle = ComboBoxStyle.DropDownList;
            cboUserName.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cboUserName.FormattingEnabled = true;
            cboUserName.Location = new Point(95, 81);
            cboUserName.Name = "cboUserName";
            cboUserName.Size = new Size(327, 28);
            cboUserName.TabIndex = 11;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(5, 86);
            label1.Name = "label1";
            label1.Size = new Size(85, 20);
            label1.TabIndex = 12;
            label1.Text = "Select User:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(4, 12);
            label2.Name = "label2";
            label2.Size = new Size(78, 20);
            label2.TabIndex = 13;
            label2.Text = "IP Address";
            // 
            // txtIPAddress
            // 
            txtIPAddress.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtIPAddress.Location = new Point(95, 9);
            txtIPAddress.Name = "txtIPAddress";
            txtIPAddress.ReadOnly = true;
            txtIPAddress.Size = new Size(327, 27);
            txtIPAddress.TabIndex = 14;
            // 
            // txtHostName
            // 
            txtHostName.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtHostName.Location = new Point(95, 45);
            txtHostName.Name = "txtHostName";
            txtHostName.ReadOnly = true;
            txtHostName.Size = new Size(327, 27);
            txtHostName.TabIndex = 16;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(5, 48);
            label3.Name = "label3";
            label3.Size = new Size(84, 20);
            label3.TabIndex = 15;
            label3.Text = "Host Name";
            // 
            // frmChatForm
            // 
            AcceptButton = btnSend;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(470, 478);
            Controls.Add(txtHostName);
            Controls.Add(label3);
            Controls.Add(txtIPAddress);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(cboUserName);
            Controls.Add(btnAddIpAddress);
            Controls.Add(txtChat);
            Controls.Add(btnSendFile);
            Controls.Add(btnSend);
            Controls.Add(txtMessage);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            Name = "frmChatForm";
            SizeGripStyle = SizeGripStyle.Hide;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "IP Messanger";
            FormClosing += frmChatForm_FormClosing;
            Load += frmChatForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnSendFile;
        private Button btnSend;
        private TextBox txtMessage;
        private TextBox txtChat;
        private Button btnAddIpAddress;
        private ComboBox cboUserName;
        private Label label1;
        private Label label2;
        private TextBox txtIPAddress;
        private TextBox txtHostName;
        private Label label3;
    }
}