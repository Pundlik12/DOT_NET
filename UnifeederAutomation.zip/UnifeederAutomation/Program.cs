﻿using System;
using System.Windows.Forms;

namespace UnifeederAutomation
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            //var key = "b14ca5898a4e4133bbce2ea2315a1916";
            //string test = clsCommon.EncryptString(key,"30-May-2023");
            //string test1 = clsCommon.DecryptString(key, test);

            clsCommon.CheckLicense();
            //clsAutomation Automation = new clsAutomation();
            //Automation.Automate();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmMain());
            System.Environment.Exit(0);
        }
    }
}
