﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;

namespace InventoryManagement.DataAccessLogic
{
    public class CustomerDAL : IGenericRepository<CustomerModel>
    {
        public CustomerDAL()
        {
            DatabaseContext.CreateConnection();
        }

        public List<CustomerModel> GetAll()
        {
            List<CustomerModel> lstData = new List<CustomerModel>();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT Code,Name,Address,PinCode,City,State,Mobile,Email,GSTNo,CompanyCode,CreatedBy,CreatedDateTime FROM tblCustomer WHERE CompanyCode = " + common.strCompanyCode;
                
                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    CustomerModel objCustomer = new CustomerModel();
                    objCustomer.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objCustomer.Name = Convert.ToString(DatabaseContext.dbdr["Name"]);
                    objCustomer.Address = Convert.ToString(DatabaseContext.dbdr["Address"]);
                    objCustomer.PinCode = Convert.ToString(DatabaseContext.dbdr["PinCode"]);
                    objCustomer.City = Convert.ToString(DatabaseContext.dbdr["City"]);
                    objCustomer.State = Convert.ToString(DatabaseContext.dbdr["State"]);
                    objCustomer.Mobile = Convert.ToString(DatabaseContext.dbdr["Mobile"]);
                    objCustomer.Email = Convert.ToString(DatabaseContext.dbdr["Email"]);
                    objCustomer.GSTNo = Convert.ToString(DatabaseContext.dbdr["GSTNo"]);
                    objCustomer.CompanyCode = Convert.ToString(DatabaseContext.dbdr["CompanyCode"]);
                    objCustomer.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objCustomer.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objCustomer);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public List<CustomerModel> GetByDates(string strFromDate, string strToDate)
        {
            List<CustomerModel> lstData = new List<CustomerModel>();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT Code,Name,Address,PinCode,City,State,Mobile,Email,GSTNo,CompanyCode,CreatedBy,CreatedDateTime FROM tblCustomer WHERE CompanyCode = " + common.strCompanyCode;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();

                while (DatabaseContext.dbdr.Read())
                {
                    CustomerModel objCustomer = new CustomerModel();
                    objCustomer.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objCustomer.Name = Convert.ToString(DatabaseContext.dbdr["Name"]);
                    objCustomer.Address = Convert.ToString(DatabaseContext.dbdr["Address"]);
                    objCustomer.PinCode = Convert.ToString(DatabaseContext.dbdr["PinCode"]);
                    objCustomer.City = Convert.ToString(DatabaseContext.dbdr["City"]);
                    objCustomer.State = Convert.ToString(DatabaseContext.dbdr["State"]);
                    objCustomer.Mobile = Convert.ToString(DatabaseContext.dbdr["Mobile"]);
                    objCustomer.Email = Convert.ToString(DatabaseContext.dbdr["Email"]);
                    objCustomer.GSTNo = Convert.ToString(DatabaseContext.dbdr["GSTNo"]);
                    objCustomer.CompanyCode = Convert.ToString(DatabaseContext.dbdr["CompanyCode"]);
                    objCustomer.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objCustomer.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);

                    lstData.Add(objCustomer);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return lstData;
        }

        public CustomerModel GetByID(Int32 CustomerCode)
        {
            CustomerModel objCustomer = new CustomerModel();
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "SELECT Code,Name,Address,PinCode,City,State,Mobile,Email,GSTNo,CompanyCode,CreatedBy,CreatedDateTime FROM tblCustomer WHERE Code = " + CustomerCode;

                DatabaseContext.OpenConnection();
                DatabaseContext.dbdr = DatabaseContext.dbcmd.ExecuteReader();
                
                while (DatabaseContext.dbdr.Read())
                {
                    objCustomer.Code = Convert.ToInt32(DatabaseContext.dbdr["Code"]);
                    objCustomer.Name = Convert.ToString(DatabaseContext.dbdr["Name"]);
                    objCustomer.Address = Convert.ToString(DatabaseContext.dbdr["Address"]);
                    objCustomer.PinCode = Convert.ToString(DatabaseContext.dbdr["PinCode"]);
                    objCustomer.City = Convert.ToString(DatabaseContext.dbdr["City"]);
                    objCustomer.State = Convert.ToString(DatabaseContext.dbdr["State"]);
                    objCustomer.Mobile = Convert.ToString(DatabaseContext.dbdr["Mobile"]);
                    objCustomer.Email = Convert.ToString(DatabaseContext.dbdr["Email"]);
                    objCustomer.GSTNo = Convert.ToString(DatabaseContext.dbdr["GSTNo"]);
                    objCustomer.CompanyCode = Convert.ToString(DatabaseContext.dbdr["CompanyCode"]);
                    objCustomer.CreatedBy = Convert.ToString(DatabaseContext.dbdr["CreatedBy"]);
                    objCustomer.CreatedDateTime = Convert.ToString(DatabaseContext.dbdr["CreatedDateTime"]);
                }

                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return objCustomer;
        }

        public void Add(CustomerModel objCustomer)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "INSERT INTO tblCustomer (Name,Address,PinCode,City,State,Mobile,Email,GSTNo,CompanyCode,CreatedBy,CreatedDateTime) VALUES(@Name,@Address,@PinCode,@City,@State,@Mobile,@Email,@GSTNo,@CompanyCode,@CreatedBy,@CreatedDateTime)";
                
                DatabaseContext.dbcmd.Parameters.AddWithValue("Name", objCustomer.Name);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Address", objCustomer.Address);
                DatabaseContext.dbcmd.Parameters.AddWithValue("PinCode", objCustomer.PinCode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("City", objCustomer.City);
                DatabaseContext.dbcmd.Parameters.AddWithValue("State", objCustomer.State);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Mobile", objCustomer.Mobile);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Email", objCustomer.Email);
                DatabaseContext.dbcmd.Parameters.AddWithValue("GSTNo", objCustomer.GSTNo);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CompanyCode", common.strCompanyCode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objCustomer.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Update(CustomerModel objCustomer)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "UPDATE tblCustomer SET Name = @Name,Address = @Address,PinCode = @PinCode,City = @City,State = @State,Mobile = @Mobile,Email = @Email,GSTNo = @GSTNo, CreatedBy = @CreatedBy,CreatedDateTime = @CreatedDateTime WHERE Code = " + objCustomer.Code;

                DatabaseContext.dbcmd.Parameters.AddWithValue("Name", objCustomer.Name);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Address", objCustomer.Address);
                DatabaseContext.dbcmd.Parameters.AddWithValue("PinCode", objCustomer.PinCode);
                DatabaseContext.dbcmd.Parameters.AddWithValue("City", objCustomer.City);
                DatabaseContext.dbcmd.Parameters.AddWithValue("State", objCustomer.State);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Mobile", objCustomer.Mobile);
                DatabaseContext.dbcmd.Parameters.AddWithValue("Email", objCustomer.Email);
                DatabaseContext.dbcmd.Parameters.AddWithValue("GSTNo", objCustomer.GSTNo);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedBy", objCustomer.CreatedBy);
                DatabaseContext.dbcmd.Parameters.AddWithValue("CreatedDateTime", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Delete(Int32 CustomerCode)
        {
            try
            {
                DatabaseContext.CreateCommand();
                DatabaseContext.dbcmd.CommandText = "DELETE FROM tblCustomer WHERE Code = " + CustomerCode;
                DatabaseContext.OpenConnection();
                DatabaseContext.dbcmd.ExecuteNonQuery();
                DatabaseContext.CloseConnection();
                DatabaseContext.dbcmd = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:- " + ex.ToString(), common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
