﻿
namespace InventoryManagement.BusinessLogic
{
    public class PayrollModel
    {
        public string PayrollID { get; set; }
        public string EmployeeID { get; set; }
        public string MonthName { get; set; }
        public string BasicSalary { get; set; }
        public string Deductions { get; set; }
        public string NetSalary { get; set; }
        public string Status { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDateTime { get; set; }
    }
}
