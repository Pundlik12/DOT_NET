﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace ECMS_Ryder.Repositories
{
    interface iSummaryReportRepository
    {
        DataTable EmailWiseSummaryReport();
        DataTable ReceivedDateWiseSummaryReport();
        DataTable AssignedUserWiseSummaryReport();
    }

    internal class SummaryReportRepository : iSummaryReportRepository
    {
        private readonly string strConnectionString = "";

        public SummaryReportRepository(string _strConnectionString)
        {
            strConnectionString = _strConnectionString;
        }

        public DataTable EmailWiseSummaryReport()
        {
            string strQuery = "";
            DataTable dataTable = new DataTable();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;

                    strQuery = "";
                    strQuery = "SELECT Main.EmailAddress, SUM(Main.Total)AS TotalEmails,Main.AssignedUser, SUM(Main.AssignedCount)AS Assigned, SUM(Main.UnAssignedCount)AS UnAssigned, SUM(Main.CompletedCount)AS Completed" + Environment.NewLine;
                    strQuery = strQuery + "FROM(SELECT EmailDetails.EmailAddress,UserDetails.UserName AS AssignedUser, 1 AS Total, IIF(EmailDetails.AssignTo IS NULL,1,0) AS UnAssignedCount, IIF(EmailDetails.AssignTo IS NULL,0,1) AS AssignedCount, IIF(EmailDetails.Status='New',0,1)AS CompletedCount FROM EmailDetails LEFT JOIN UserDetails ON EmailDetails.AssignTo = UserDetails.UID)AS Main" + Environment.NewLine;
                    strQuery = strQuery + "GROUP BY Main.EmailAddress,Main.AssignedUser";

                    cmd.CommandText = strQuery;
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;
                    
                    OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter(cmd);
                    
                    oleDbDataAdapter.Fill(dataTable);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in EmailWiseSummaryReport:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return dataTable;
        }

        public DataTable ReceivedDateWiseSummaryReport()
        {
            string strQuery = "";
            DataTable dataTable = new DataTable();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    OleDbCommand cmd = new OleDbCommand();

                    strQuery = "";
                    strQuery = "SELECT EmailAddress,ReceivedDate,SUM(Total) AS ReceivedCount" + Environment.NewLine;
                    strQuery = strQuery + "FROM(SELECT EmailAddress,DateValue(ReceivedTime)AS ReceivedDate,1 AS Total FROM EmailDetails)" + Environment.NewLine;
                    strQuery = strQuery + "GROUP BY EmailAddress,ReceivedDate";

                    cmd.Connection = connection;
                    cmd.CommandText = strQuery;
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter(cmd);

                    oleDbDataAdapter.Fill(dataTable);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in ReceivedDateWiseSummaryReport:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return dataTable;
        }

        public DataTable AssignedUserWiseSummaryReport()
        {
            string strQuery = "";
            DataTable dataTable = new DataTable();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    OleDbCommand cmd = new OleDbCommand();

                    strQuery = "";
                    strQuery = "SELECT EmailAddress,AssignedUser,SUM(Total) AS AssignedCount,SUM(CompletedCount)AS CompletedCount " + Environment.NewLine;
                    strQuery = strQuery + "FROM(SELECT EmailDetails.EmailAddress,UserDetails.UserName AS AssignedUser,1 AS Total,IIF(EmailDetails.Status='New',0,1)AS CompletedCount FROM EmailDetails INNER JOIN UserDetails ON EmailDetails.AssignTo = UserDetails.UID)" + Environment.NewLine;
                    strQuery = strQuery + "GROUP BY EmailAddress,AssignedUser";

                    cmd.Connection = connection;
                    cmd.CommandText = strQuery;
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.Text;

                    OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter(cmd);

                    oleDbDataAdapter.Fill(dataTable);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in AssignedUserWiseSummaryReport:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return dataTable;
        }
    }
}
