﻿using System;
using System.Data;
using System.Data.OleDb;
using ECMS_Ryder.Models;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ECMS_Ryder.Repositories
{
    interface iMasterDetailsRepository
    {
        List<CategoryDetails> GetAllCategories();
        List<SubCategoryDetails> GetAllSubCategories();
        List<InclusionDetails> GetAllInclusions();
    }

    internal class MasterDetailsRepository : iMasterDetailsRepository
    {
        private readonly string strConnectionString = "";

        public MasterDetailsRepository(string _strConnectionString)
        {
            strConnectionString = _strConnectionString;
        }

        public List<CategoryDetails> GetAllCategories()
        {
            List<CategoryDetails> categories = new List<CategoryDetails>();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "GetAllCategories";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;

                    OleDbDataReader OleDbDataReader = cmd.ExecuteReader();

                    while (OleDbDataReader.Read())
                    {
                        CategoryDetails categoryDetails = new CategoryDetails();
                        categoryDetails.CategoryId = Convert.ToInt32(OleDbDataReader["CategoryId"]);
                        categoryDetails.Category = Convert.ToString(OleDbDataReader["Category"]);
                        categories.Add(categoryDetails);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetAllCategories:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                categories = null;
            }

            return categories;
        }

        public List<SubCategoryDetails> GetAllSubCategories()
        {
            List<SubCategoryDetails> subCategories = new List<SubCategoryDetails>();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "GetAllSubCategories";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;

                    OleDbDataReader OleDbDataReader = cmd.ExecuteReader();

                    while (OleDbDataReader.Read())
                    {
                        SubCategoryDetails subCategoryDetails = new SubCategoryDetails();
                        subCategoryDetails.SubCategoryId = Convert.ToInt32(OleDbDataReader["SubCategoryId"]);
                        subCategoryDetails.CategoryId = Convert.ToInt32(OleDbDataReader["CategoryId"]);
                        subCategoryDetails.SubCategory = Convert.ToString(OleDbDataReader["SubCategory"]);
                        subCategories.Add(subCategoryDetails);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetAllSubCategories:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                subCategories = null;
            }

            return subCategories;
        }

        public List<InclusionDetails> GetAllInclusions()
        {
            List<InclusionDetails> inclusions = new List<InclusionDetails>();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConnectionString))
                {
                    connection.Open();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = "GetAllInclusions";
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;

                    OleDbDataReader OleDbDataReader = cmd.ExecuteReader();

                    while (OleDbDataReader.Read())
                    {
                        InclusionDetails inclusionDetails = new InclusionDetails();
                        inclusionDetails.InclusionId = Convert.ToInt32(OleDbDataReader["InclusionId"]);
                        inclusionDetails.SubCategoryId = Convert.ToInt32(OleDbDataReader["SubCategoryId"]);
                        inclusionDetails.Inclusion = Convert.ToString(OleDbDataReader["Inclusion"]);
                        inclusions.Add(inclusionDetails);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in GetAllInclusions:- " + ex.ToString(), "ECMS Tool - Ryder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                inclusions = null;
            }

            return inclusions;
        }
    }
}
