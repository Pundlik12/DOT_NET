﻿using System.Collections.Generic;

namespace HBAccessTool
{
    public interface iTransactions
    {
        List<TransactionModel> GetAllTransactions();
        TransactionModel GetTransactionByID(int TransactionID);
        int AddTransaction(TransactionModel TM);
        int UpdateTransaction(TransactionModel TM);
        int DeleteTransaction(int TransactionID);
    }
}
