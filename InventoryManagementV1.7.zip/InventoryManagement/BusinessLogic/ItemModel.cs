﻿
namespace InventoryManagement.BusinessLogic
{
    public class ItemModel
    {
        public int Code { get; set; }
        public string Name { get; set; }
        public string GSTPercent { get; set; }
        public string HSNNumber { get; set; }
        public string CompanyCode { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDateTime { get; set; }
    }
}
