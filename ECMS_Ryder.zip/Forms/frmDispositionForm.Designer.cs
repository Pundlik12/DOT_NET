﻿namespace ECMS_Ryder.Forms
{
    partial class frmDispositionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.SearchGroupBox = new System.Windows.Forms.GroupBox();
            this.lblEmailsCount = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtSearchText = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cmbSearchCriteria = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.dgvEmails = new System.Windows.Forms.DataGridView();
            this.EmailDetailsId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmailAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FolderName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Subject = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Priority = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HasAttachments = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReceivedTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SenderName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SenderEmailAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.To = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Bcc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Body = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EntryID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ConversationID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SyncBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SyncDateTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastUpdatedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastUpdatedDateTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssignTo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssignedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssignedDateTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.cmbSubCategory = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbCategory = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSubjectLine = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.EmailsGroupBox = new System.Windows.Forms.GroupBox();
            this.lblOpenEmail = new System.Windows.Forms.LinkLabel();
            this.label9 = new System.Windows.Forms.Label();
            this.lblTimer = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtComments = new System.Windows.Forms.TextBox();
            this.stopWatch = new System.Windows.Forms.Timer(this.components);
            this.DispositionGroupBox = new System.Windows.Forms.GroupBox();
            this.SearchGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmails)).BeginInit();
            this.EmailsGroupBox.SuspendLayout();
            this.DispositionGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Rockwell", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1437, 52);
            this.label1.TabIndex = 0;
            this.label1.Text = "Process/Dispose Emails";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SearchGroupBox
            // 
            this.SearchGroupBox.Controls.Add(this.lblEmailsCount);
            this.SearchGroupBox.Controls.Add(this.label10);
            this.SearchGroupBox.Controls.Add(this.txtSearchText);
            this.SearchGroupBox.Controls.Add(this.label11);
            this.SearchGroupBox.Controls.Add(this.cmbSearchCriteria);
            this.SearchGroupBox.Controls.Add(this.label12);
            this.SearchGroupBox.Dock = System.Windows.Forms.DockStyle.Top;
            this.SearchGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchGroupBox.Location = new System.Drawing.Point(0, 52);
            this.SearchGroupBox.Name = "SearchGroupBox";
            this.SearchGroupBox.Size = new System.Drawing.Size(1437, 69);
            this.SearchGroupBox.TabIndex = 1;
            this.SearchGroupBox.TabStop = false;
            this.SearchGroupBox.Text = "Search";
            // 
            // lblEmailsCount
            // 
            this.lblEmailsCount.AutoSize = true;
            this.lblEmailsCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailsCount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblEmailsCount.Location = new System.Drawing.Point(1307, 28);
            this.lblEmailsCount.Name = "lblEmailsCount";
            this.lblEmailsCount.Size = new System.Drawing.Size(26, 29);
            this.lblEmailsCount.TabIndex = 5;
            this.lblEmailsCount.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(1128, 26);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(169, 29);
            this.label10.TabIndex = 4;
            this.label10.Text = "Emails Count:-";
            // 
            // txtSearchText
            // 
            this.txtSearchText.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchText.Location = new System.Drawing.Point(611, 22);
            this.txtSearchText.Name = "txtSearchText";
            this.txtSearchText.Size = new System.Drawing.Size(481, 38);
            this.txtSearchText.TabIndex = 3;
            this.txtSearchText.TextChanged += new System.EventHandler(this.txtSearchText_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(476, 30);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(132, 25);
            this.label11.TabIndex = 2;
            this.label11.Text = "Search Text:-";
            // 
            // cmbSearchCriteria
            // 
            this.cmbSearchCriteria.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSearchCriteria.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSearchCriteria.FormattingEnabled = true;
            this.cmbSearchCriteria.Items.AddRange(new object[] {
            "Select",
            "SenderName",
            "To",
            "Cc",
            "Bcc",
            "Subject",
            "Priority",
            "HasAttachments"});
            this.cmbSearchCriteria.Location = new System.Drawing.Point(150, 25);
            this.cmbSearchCriteria.Name = "cmbSearchCriteria";
            this.cmbSearchCriteria.Size = new System.Drawing.Size(292, 33);
            this.cmbSearchCriteria.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(22, 28);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(115, 25);
            this.label12.TabIndex = 0;
            this.label12.Text = "Search on:-";
            // 
            // dgvEmails
            // 
            this.dgvEmails.AllowUserToAddRows = false;
            this.dgvEmails.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEmails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvEmails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EmailDetailsId,
            this.EmailAddress,
            this.FolderName,
            this.Subject,
            this.Priority,
            this.HasAttachments,
            this.ReceivedTime,
            this.SenderName,
            this.SenderEmailAddress,
            this.To,
            this.CC,
            this.Bcc,
            this.Body,
            this.EntryID,
            this.ConversationID,
            this.Status,
            this.SyncBy,
            this.SyncDateTime,
            this.LastUpdatedBy,
            this.LastUpdatedDateTime,
            this.AssignTo,
            this.AssignedBy,
            this.AssignedDateTime});
            this.dgvEmails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvEmails.Location = new System.Drawing.Point(3, 23);
            this.dgvEmails.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvEmails.MultiSelect = false;
            this.dgvEmails.Name = "dgvEmails";
            this.dgvEmails.RowHeadersVisible = false;
            this.dgvEmails.RowHeadersWidth = 51;
            this.dgvEmails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEmails.Size = new System.Drawing.Size(1431, 346);
            this.dgvEmails.TabIndex = 0;
            this.dgvEmails.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEmails_CellDoubleClick);
            // 
            // EmailDetailsId
            // 
            this.EmailDetailsId.DataPropertyName = "EmailDetailsId";
            this.EmailDetailsId.HeaderText = "EmailId";
            this.EmailDetailsId.MinimumWidth = 6;
            this.EmailDetailsId.Name = "EmailDetailsId";
            this.EmailDetailsId.ReadOnly = true;
            this.EmailDetailsId.Width = 81;
            // 
            // EmailAddress
            // 
            this.EmailAddress.DataPropertyName = "EmailAddress";
            this.EmailAddress.HeaderText = "Email Address";
            this.EmailAddress.MinimumWidth = 6;
            this.EmailAddress.Name = "EmailAddress";
            this.EmailAddress.ReadOnly = true;
            this.EmailAddress.Width = 114;
            // 
            // FolderName
            // 
            this.FolderName.DataPropertyName = "FolderName";
            this.FolderName.HeaderText = "Folder Name";
            this.FolderName.MinimumWidth = 6;
            this.FolderName.Name = "FolderName";
            this.FolderName.ReadOnly = true;
            this.FolderName.Width = 106;
            // 
            // Subject
            // 
            this.Subject.DataPropertyName = "Subject";
            this.Subject.HeaderText = "Subject";
            this.Subject.MinimumWidth = 6;
            this.Subject.Name = "Subject";
            this.Subject.ReadOnly = true;
            this.Subject.Width = 81;
            // 
            // Priority
            // 
            this.Priority.DataPropertyName = "Priority";
            this.Priority.HeaderText = "Priority";
            this.Priority.MinimumWidth = 6;
            this.Priority.Name = "Priority";
            this.Priority.ReadOnly = true;
            this.Priority.Width = 77;
            // 
            // HasAttachments
            // 
            this.HasAttachments.DataPropertyName = "HasAttachments";
            this.HasAttachments.HeaderText = "Has Attachments";
            this.HasAttachments.MinimumWidth = 6;
            this.HasAttachments.Name = "HasAttachments";
            this.HasAttachments.ReadOnly = true;
            this.HasAttachments.Width = 126;
            // 
            // ReceivedTime
            // 
            this.ReceivedTime.DataPropertyName = "ReceivedTime";
            this.ReceivedTime.HeaderText = "Received Time";
            this.ReceivedTime.MinimumWidth = 6;
            this.ReceivedTime.Name = "ReceivedTime";
            this.ReceivedTime.ReadOnly = true;
            this.ReceivedTime.Width = 119;
            // 
            // SenderName
            // 
            this.SenderName.DataPropertyName = "SenderName";
            this.SenderName.HeaderText = "Sender Name";
            this.SenderName.MinimumWidth = 6;
            this.SenderName.Name = "SenderName";
            this.SenderName.ReadOnly = true;
            this.SenderName.Width = 110;
            // 
            // SenderEmailAddress
            // 
            this.SenderEmailAddress.DataPropertyName = "SenderEmailAddress";
            this.SenderEmailAddress.HeaderText = "Sender Email Address";
            this.SenderEmailAddress.MinimumWidth = 6;
            this.SenderEmailAddress.Name = "SenderEmailAddress";
            this.SenderEmailAddress.ReadOnly = true;
            this.SenderEmailAddress.Width = 156;
            // 
            // To
            // 
            this.To.DataPropertyName = "To";
            this.To.HeaderText = "To";
            this.To.MinimumWidth = 6;
            this.To.Name = "To";
            this.To.ReadOnly = true;
            this.To.Width = 53;
            // 
            // CC
            // 
            this.CC.DataPropertyName = "CC";
            this.CC.HeaderText = "CC";
            this.CC.MinimumWidth = 6;
            this.CC.Name = "CC";
            this.CC.ReadOnly = true;
            this.CC.Width = 54;
            // 
            // Bcc
            // 
            this.Bcc.DataPropertyName = "Bcc";
            this.Bcc.HeaderText = "Bcc";
            this.Bcc.MinimumWidth = 6;
            this.Bcc.Name = "Bcc";
            this.Bcc.ReadOnly = true;
            this.Bcc.Width = 59;
            // 
            // Body
            // 
            this.Body.DataPropertyName = "Body";
            this.Body.HeaderText = "Body";
            this.Body.MinimumWidth = 6;
            this.Body.Name = "Body";
            this.Body.ReadOnly = true;
            this.Body.Width = 68;
            // 
            // EntryID
            // 
            this.EntryID.DataPropertyName = "EntryID";
            this.EntryID.HeaderText = "Entry ID";
            this.EntryID.MinimumWidth = 6;
            this.EntryID.Name = "EntryID";
            this.EntryID.ReadOnly = true;
            this.EntryID.Width = 76;
            // 
            // ConversationID
            // 
            this.ConversationID.DataPropertyName = "ConversationID";
            this.ConversationID.HeaderText = "Conversation ID";
            this.ConversationID.MinimumWidth = 6;
            this.ConversationID.Name = "ConversationID";
            this.ConversationID.ReadOnly = true;
            this.ConversationID.Width = 120;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.MinimumWidth = 6;
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.Width = 73;
            // 
            // SyncBy
            // 
            this.SyncBy.DataPropertyName = "SyncBy";
            this.SyncBy.HeaderText = "Sync By";
            this.SyncBy.MinimumWidth = 6;
            this.SyncBy.Name = "SyncBy";
            this.SyncBy.ReadOnly = true;
            this.SyncBy.Width = 79;
            // 
            // SyncDateTime
            // 
            this.SyncDateTime.DataPropertyName = "SyncDateTime";
            this.SyncDateTime.HeaderText = "Sync DateTime";
            this.SyncDateTime.MinimumWidth = 6;
            this.SyncDateTime.Name = "SyncDateTime";
            this.SyncDateTime.ReadOnly = true;
            this.SyncDateTime.Width = 119;
            // 
            // LastUpdatedBy
            // 
            this.LastUpdatedBy.DataPropertyName = "LastUpdatedBy";
            this.LastUpdatedBy.HeaderText = "Last Updated By";
            this.LastUpdatedBy.MinimumWidth = 6;
            this.LastUpdatedBy.Name = "LastUpdatedBy";
            this.LastUpdatedBy.ReadOnly = true;
            this.LastUpdatedBy.Width = 110;
            // 
            // LastUpdatedDateTime
            // 
            this.LastUpdatedDateTime.DataPropertyName = "LastUpdatedDateTime";
            this.LastUpdatedDateTime.HeaderText = "Last Updated DateTime";
            this.LastUpdatedDateTime.MinimumWidth = 6;
            this.LastUpdatedDateTime.Name = "LastUpdatedDateTime";
            this.LastUpdatedDateTime.ReadOnly = true;
            this.LastUpdatedDateTime.Width = 164;
            // 
            // AssignTo
            // 
            this.AssignTo.DataPropertyName = "AssignTo";
            this.AssignTo.HeaderText = "Assign To";
            this.AssignTo.MinimumWidth = 6;
            this.AssignTo.Name = "AssignTo";
            this.AssignTo.ReadOnly = true;
            this.AssignTo.Width = 90;
            // 
            // AssignedBy
            // 
            this.AssignedBy.DataPropertyName = "AssignedBy";
            this.AssignedBy.HeaderText = "Assigned By";
            this.AssignedBy.MinimumWidth = 6;
            this.AssignedBy.Name = "AssignedBy";
            this.AssignedBy.ReadOnly = true;
            this.AssignedBy.Width = 103;
            // 
            // AssignedDateTime
            // 
            this.AssignedDateTime.DataPropertyName = "AssignedDateTime";
            this.AssignedDateTime.HeaderText = "Assigned DateTime";
            this.AssignedDateTime.MinimumWidth = 6;
            this.AssignedDateTime.Name = "AssignedDateTime";
            this.AssignedDateTime.ReadOnly = true;
            this.AssignedDateTime.Width = 143;
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(955, 193);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(137, 46);
            this.btnClear.TabIndex = 15;
            this.btnClear.Text = "Cancel";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnSubmit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubmit.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(812, 193);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(137, 46);
            this.btnSubmit.TabIndex = 14;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // cmbSubCategory
            // 
            this.cmbSubCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSubCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSubCategory.FormattingEnabled = true;
            this.cmbSubCategory.Location = new System.Drawing.Point(242, 112);
            this.cmbSubCategory.Name = "cmbSubCategory";
            this.cmbSubCategory.Size = new System.Drawing.Size(347, 33);
            this.cmbSubCategory.TabIndex = 5;
            this.cmbSubCategory.Leave += new System.EventHandler(this.cmbSubCategory_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(69, 117);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(149, 22);
            this.label5.TabIndex = 4;
            this.label5.Text = "Sub Category:-";
            // 
            // cmbCategory
            // 
            this.cmbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCategory.FormattingEnabled = true;
            this.cmbCategory.Location = new System.Drawing.Point(243, 64);
            this.cmbCategory.Name = "cmbCategory";
            this.cmbCategory.Size = new System.Drawing.Size(347, 33);
            this.cmbCategory.TabIndex = 3;
            this.cmbCategory.Leave += new System.EventHandler(this.cmbCategory_Leave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(109, 67);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 22);
            this.label4.TabIndex = 2;
            this.label4.Text = "Category:-";
            // 
            // txtSubjectLine
            // 
            this.txtSubjectLine.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSubjectLine.Location = new System.Drawing.Point(242, 21);
            this.txtSubjectLine.Name = "txtSubjectLine";
            this.txtSubjectLine.ReadOnly = true;
            this.txtSubjectLine.Size = new System.Drawing.Size(1183, 30);
            this.txtSubjectLine.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(89, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 22);
            this.label2.TabIndex = 0;
            this.label2.Text = "SubjectLine:-";
            // 
            // EmailsGroupBox
            // 
            this.EmailsGroupBox.Controls.Add(this.dgvEmails);
            this.EmailsGroupBox.Dock = System.Windows.Forms.DockStyle.Top;
            this.EmailsGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailsGroupBox.Location = new System.Drawing.Point(0, 121);
            this.EmailsGroupBox.Name = "EmailsGroupBox";
            this.EmailsGroupBox.Size = new System.Drawing.Size(1437, 372);
            this.EmailsGroupBox.TabIndex = 2;
            this.EmailsGroupBox.TabStop = false;
            this.EmailsGroupBox.Text = "Emails";
            // 
            // lblOpenEmail
            // 
            this.lblOpenEmail.AutoSize = true;
            this.lblOpenEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOpenEmail.Location = new System.Drawing.Point(1230, 80);
            this.lblOpenEmail.Name = "lblOpenEmail";
            this.lblOpenEmail.Size = new System.Drawing.Size(103, 22);
            this.lblOpenEmail.TabIndex = 16;
            this.lblOpenEmail.TabStop = true;
            this.lblOpenEmail.Text = "Open Email";
            this.lblOpenEmail.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblOpenEmail_LinkClicked);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label9.Location = new System.Drawing.Point(1223, 138);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(136, 22);
            this.label9.TabIndex = 17;
            this.label9.Text = "Time Elapsed";
            // 
            // lblTimer
            // 
            this.lblTimer.AutoSize = true;
            this.lblTimer.Font = new System.Drawing.Font("Rockwell", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblTimer.Location = new System.Drawing.Point(1228, 177);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(120, 31);
            this.lblTimer.TabIndex = 18;
            this.lblTimer.Text = "00:00:00";
            this.lblTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(98, 164);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(120, 22);
            this.label8.TabIndex = 12;
            this.label8.Text = "Comments:-";
            // 
            // txtComments
            // 
            this.txtComments.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComments.Location = new System.Drawing.Point(242, 160);
            this.txtComments.Multiline = true;
            this.txtComments.Name = "txtComments";
            this.txtComments.Size = new System.Drawing.Size(539, 90);
            this.txtComments.TabIndex = 13;
            // 
            // DispositionGroupBox
            // 
            this.DispositionGroupBox.Controls.Add(this.lblOpenEmail);
            this.DispositionGroupBox.Controls.Add(this.txtSubjectLine);
            this.DispositionGroupBox.Controls.Add(this.label9);
            this.DispositionGroupBox.Controls.Add(this.label5);
            this.DispositionGroupBox.Controls.Add(this.lblTimer);
            this.DispositionGroupBox.Controls.Add(this.cmbSubCategory);
            this.DispositionGroupBox.Controls.Add(this.label8);
            this.DispositionGroupBox.Controls.Add(this.cmbCategory);
            this.DispositionGroupBox.Controls.Add(this.txtComments);
            this.DispositionGroupBox.Controls.Add(this.btnSubmit);
            this.DispositionGroupBox.Controls.Add(this.label4);
            this.DispositionGroupBox.Controls.Add(this.btnClear);
            this.DispositionGroupBox.Controls.Add(this.label2);
            this.DispositionGroupBox.Dock = System.Windows.Forms.DockStyle.Top;
            this.DispositionGroupBox.Location = new System.Drawing.Point(0, 493);
            this.DispositionGroupBox.Name = "DispositionGroupBox";
            this.DispositionGroupBox.Size = new System.Drawing.Size(1437, 256);
            this.DispositionGroupBox.TabIndex = 3;
            this.DispositionGroupBox.TabStop = false;
            this.DispositionGroupBox.Text = "Disposition";
            // 
            // frmDispositionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1437, 753);
            this.Controls.Add(this.DispositionGroupBox);
            this.Controls.Add(this.EmailsGroupBox);
            this.Controls.Add(this.SearchGroupBox);
            this.Controls.Add(this.label1);
            this.Name = "frmDispositionForm";
            this.ShowIcon = false;
            this.Text = "Process/Dispose Emails";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmDispositionForm_FormClosing);
            this.Load += new System.EventHandler(this.frmDispositionForm_Load);
            this.SearchGroupBox.ResumeLayout(false);
            this.SearchGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmails)).EndInit();
            this.EmailsGroupBox.ResumeLayout(false);
            this.DispositionGroupBox.ResumeLayout(false);
            this.DispositionGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox SearchGroupBox;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.ComboBox cmbSubCategory;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbCategory;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtSubjectLine;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox EmailsGroupBox;
        private System.Windows.Forms.DataGridView dgvEmails;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtComments;
        private System.Windows.Forms.Timer stopWatch;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.LinkLabel lblOpenEmail;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmailDetailsId;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmailAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn FolderName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Subject;
        private System.Windows.Forms.DataGridViewTextBoxColumn Priority;
        private System.Windows.Forms.DataGridViewTextBoxColumn HasAttachments;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReceivedTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn SenderName;
        private System.Windows.Forms.DataGridViewTextBoxColumn SenderEmailAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn To;
        private System.Windows.Forms.DataGridViewTextBoxColumn CC;
        private System.Windows.Forms.DataGridViewTextBoxColumn Bcc;
        private System.Windows.Forms.DataGridViewTextBoxColumn Body;
        private System.Windows.Forms.DataGridViewTextBoxColumn EntryID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ConversationID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn SyncBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn SyncDateTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn LastUpdatedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn LastUpdatedDateTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn AssignTo;
        private System.Windows.Forms.DataGridViewTextBoxColumn AssignedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn AssignedDateTime;
        private System.Windows.Forms.GroupBox DispositionGroupBox;
        private System.Windows.Forms.Label lblEmailsCount;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtSearchText;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cmbSearchCriteria;
        private System.Windows.Forms.Label label12;
    }
}