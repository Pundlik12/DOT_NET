﻿namespace InventoryManagement
{
    partial class frmMDIForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MenuStrip = new System.Windows.Forms.MenuStrip();
            this.FileToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.ChangePasswordToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.ExitToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.MasterStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.ItemsToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.CustomerToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.SupplierToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.EmployeeToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.TransactionToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.ChallanEntryToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.PaymentEntryToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.ExpensesEntryToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.AttendanceEntryToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.AttendanceRegularisationToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.LeaveRequestToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.ReportsToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.challanReportToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.paymentReportToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.expenseReportToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.UtilityToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.UserManagementToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.CompanyInfoToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // MenuStrip
            // 
            this.MenuStrip.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MenuStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.MenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FileToolStripMenu,
            this.MasterStripMenu,
            this.TransactionToolStripMenu,
            this.ReportsToolStripMenu,
            this.UtilityToolStripMenu});
            this.MenuStrip.Location = new System.Drawing.Point(0, 0);
            this.MenuStrip.Name = "MenuStrip";
            this.MenuStrip.Size = new System.Drawing.Size(1370, 33);
            this.MenuStrip.TabIndex = 0;
            this.MenuStrip.Text = "menuStrip1";
            // 
            // FileToolStripMenu
            // 
            this.FileToolStripMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ChangePasswordToolStripMenu,
            this.ExitToolStripMenu});
            this.FileToolStripMenu.Name = "FileToolStripMenu";
            this.FileToolStripMenu.Size = new System.Drawing.Size(53, 29);
            this.FileToolStripMenu.Text = "File";
            // 
            // ChangePasswordToolStripMenu
            // 
            this.ChangePasswordToolStripMenu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChangePasswordToolStripMenu.Name = "ChangePasswordToolStripMenu";
            this.ChangePasswordToolStripMenu.Size = new System.Drawing.Size(205, 26);
            this.ChangePasswordToolStripMenu.Text = "Change Password";
            this.ChangePasswordToolStripMenu.Click += new System.EventHandler(this.ChangePasswordToolStripMenu_Click);
            // 
            // ExitToolStripMenu
            // 
            this.ExitToolStripMenu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitToolStripMenu.Name = "ExitToolStripMenu";
            this.ExitToolStripMenu.Size = new System.Drawing.Size(205, 26);
            this.ExitToolStripMenu.Text = "Exit";
            this.ExitToolStripMenu.Click += new System.EventHandler(this.ExitToolStripMenu_Click);
            // 
            // MasterStripMenu
            // 
            this.MasterStripMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ItemsToolStripMenu,
            this.CustomerToolStripMenu,
            this.SupplierToolStripMenu,
            this.EmployeeToolStripMenu});
            this.MasterStripMenu.Name = "MasterStripMenu";
            this.MasterStripMenu.Size = new System.Drawing.Size(90, 29);
            this.MasterStripMenu.Text = "Masters";
            // 
            // ItemsToolStripMenu
            // 
            this.ItemsToolStripMenu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemsToolStripMenu.Name = "ItemsToolStripMenu";
            this.ItemsToolStripMenu.Size = new System.Drawing.Size(180, 26);
            this.ItemsToolStripMenu.Text = "Items";
            this.ItemsToolStripMenu.Click += new System.EventHandler(this.ItemsToolStripMenu_Click);
            // 
            // CustomerToolStripMenu
            // 
            this.CustomerToolStripMenu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerToolStripMenu.Name = "CustomerToolStripMenu";
            this.CustomerToolStripMenu.Size = new System.Drawing.Size(180, 26);
            this.CustomerToolStripMenu.Text = "Customer";
            this.CustomerToolStripMenu.Click += new System.EventHandler(this.CustomerToolStripMenu_Click);
            // 
            // SupplierToolStripMenu
            // 
            this.SupplierToolStripMenu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SupplierToolStripMenu.Name = "SupplierToolStripMenu";
            this.SupplierToolStripMenu.Size = new System.Drawing.Size(180, 26);
            this.SupplierToolStripMenu.Text = "Supplier";
            this.SupplierToolStripMenu.Click += new System.EventHandler(this.SupplierToolStripMenu_Click);
            // 
            // EmployeeToolStripMenu
            // 
            this.EmployeeToolStripMenu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeeToolStripMenu.Name = "EmployeeToolStripMenu";
            this.EmployeeToolStripMenu.Size = new System.Drawing.Size(180, 26);
            this.EmployeeToolStripMenu.Text = "Employee";
            this.EmployeeToolStripMenu.Click += new System.EventHandler(this.EmployeeToolStripMenu_Click);
            // 
            // TransactionToolStripMenu
            // 
            this.TransactionToolStripMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ChallanEntryToolStripMenu,
            this.PaymentEntryToolStripMenu,
            this.ExpensesEntryToolStripMenu,
            this.AttendanceEntryToolStripMenu,
            this.AttendanceRegularisationToolStripMenu,
            this.LeaveRequestToolStripMenu});
            this.TransactionToolStripMenu.Name = "TransactionToolStripMenu";
            this.TransactionToolStripMenu.Size = new System.Drawing.Size(128, 29);
            this.TransactionToolStripMenu.Text = "Transactions";
            // 
            // ChallanEntryToolStripMenu
            // 
            this.ChallanEntryToolStripMenu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChallanEntryToolStripMenu.Name = "ChallanEntryToolStripMenu";
            this.ChallanEntryToolStripMenu.Size = new System.Drawing.Size(304, 26);
            this.ChallanEntryToolStripMenu.Text = "Challan Entry";
            this.ChallanEntryToolStripMenu.Click += new System.EventHandler(this.ChallanEntryToolStripMenu_Click);
            // 
            // PaymentEntryToolStripMenu
            // 
            this.PaymentEntryToolStripMenu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PaymentEntryToolStripMenu.Name = "PaymentEntryToolStripMenu";
            this.PaymentEntryToolStripMenu.Size = new System.Drawing.Size(304, 26);
            this.PaymentEntryToolStripMenu.Text = "Payment Entry";
            this.PaymentEntryToolStripMenu.Click += new System.EventHandler(this.PaymentEntryToolStripMenu_Click);
            // 
            // ExpensesEntryToolStripMenu
            // 
            this.ExpensesEntryToolStripMenu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExpensesEntryToolStripMenu.Name = "ExpensesEntryToolStripMenu";
            this.ExpensesEntryToolStripMenu.Size = new System.Drawing.Size(304, 26);
            this.ExpensesEntryToolStripMenu.Text = "Expenses Entry";
            this.ExpensesEntryToolStripMenu.Click += new System.EventHandler(this.expensesEntryToolStripMenuItem_Click);
            // 
            // AttendanceEntryToolStripMenu
            // 
            this.AttendanceEntryToolStripMenu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AttendanceEntryToolStripMenu.Name = "AttendanceEntryToolStripMenu";
            this.AttendanceEntryToolStripMenu.Size = new System.Drawing.Size(304, 26);
            this.AttendanceEntryToolStripMenu.Text = "Attendance Entry";
            this.AttendanceEntryToolStripMenu.Click += new System.EventHandler(this.AttendanceEntryToolStripMenu_Click);
            // 
            // AttendanceRegularisationToolStripMenu
            // 
            this.AttendanceRegularisationToolStripMenu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AttendanceRegularisationToolStripMenu.Name = "AttendanceRegularisationToolStripMenu";
            this.AttendanceRegularisationToolStripMenu.Size = new System.Drawing.Size(304, 26);
            this.AttendanceRegularisationToolStripMenu.Text = "Attendance Regularisation Entry";
            this.AttendanceRegularisationToolStripMenu.Click += new System.EventHandler(this.AttendanceRegularisationToolStripMenu_Click);
            // 
            // LeaveRequestToolStripMenu
            // 
            this.LeaveRequestToolStripMenu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeaveRequestToolStripMenu.Name = "LeaveRequestToolStripMenu";
            this.LeaveRequestToolStripMenu.Size = new System.Drawing.Size(304, 26);
            this.LeaveRequestToolStripMenu.Text = "Leave Request Entry";
            this.LeaveRequestToolStripMenu.Click += new System.EventHandler(this.LeaveRequestToolStripMenu_Click);
            // 
            // ReportsToolStripMenu
            // 
            this.ReportsToolStripMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.challanReportToolStripMenu,
            this.paymentReportToolStripMenu,
            this.expenseReportToolStripMenu});
            this.ReportsToolStripMenu.Name = "ReportsToolStripMenu";
            this.ReportsToolStripMenu.Size = new System.Drawing.Size(87, 29);
            this.ReportsToolStripMenu.Text = "Reports";
            // 
            // challanReportToolStripMenu
            // 
            this.challanReportToolStripMenu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.challanReportToolStripMenu.Name = "challanReportToolStripMenu";
            this.challanReportToolStripMenu.Size = new System.Drawing.Size(180, 26);
            this.challanReportToolStripMenu.Text = "Challan";
            this.challanReportToolStripMenu.Click += new System.EventHandler(this.challanReportToolStripMenu_Click);
            // 
            // paymentReportToolStripMenu
            // 
            this.paymentReportToolStripMenu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paymentReportToolStripMenu.Name = "paymentReportToolStripMenu";
            this.paymentReportToolStripMenu.Size = new System.Drawing.Size(180, 26);
            this.paymentReportToolStripMenu.Text = "Payment";
            this.paymentReportToolStripMenu.Click += new System.EventHandler(this.paymentReportToolStripMenu_Click);
            // 
            // expenseReportToolStripMenu
            // 
            this.expenseReportToolStripMenu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expenseReportToolStripMenu.Name = "expenseReportToolStripMenu";
            this.expenseReportToolStripMenu.Size = new System.Drawing.Size(180, 26);
            this.expenseReportToolStripMenu.Text = "Expense";
            this.expenseReportToolStripMenu.Click += new System.EventHandler(this.expenseReportToolStripMenu_Click);
            // 
            // UtilityToolStripMenu
            // 
            this.UtilityToolStripMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.UserManagementToolStripMenu,
            this.CompanyInfoToolStripMenu});
            this.UtilityToolStripMenu.Name = "UtilityToolStripMenu";
            this.UtilityToolStripMenu.Size = new System.Drawing.Size(73, 29);
            this.UtilityToolStripMenu.Text = "Utility";
            // 
            // UserManagementToolStripMenu
            // 
            this.UserManagementToolStripMenu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserManagementToolStripMenu.Name = "UserManagementToolStripMenu";
            this.UserManagementToolStripMenu.Size = new System.Drawing.Size(210, 26);
            this.UserManagementToolStripMenu.Text = "User Management";
            this.UserManagementToolStripMenu.Click += new System.EventHandler(this.UserManagementToolStripMenu_Click);
            // 
            // CompanyInfoToolStripMenu
            // 
            this.CompanyInfoToolStripMenu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompanyInfoToolStripMenu.Name = "CompanyInfoToolStripMenu";
            this.CompanyInfoToolStripMenu.Size = new System.Drawing.Size(210, 26);
            this.CompanyInfoToolStripMenu.Text = "Company Info";
            this.CompanyInfoToolStripMenu.Click += new System.EventHandler(this.CompanyInfoToolStripMenu_Click);
            // 
            // frmMDIForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 655);
            this.Controls.Add(this.MenuStrip);
            this.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IsMdiContainer = true;
            this.KeyPreview = true;
            this.MainMenuStrip = this.MenuStrip;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmMDIForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MDI Form";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMDIForm_FormClosing);
            this.Load += new System.EventHandler(this.frmMDIForm_Load);
            this.MenuStrip.ResumeLayout(false);
            this.MenuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MenuStrip;
        private System.Windows.Forms.ToolStripMenuItem FileToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem MasterStripMenu;
        private System.Windows.Forms.ToolStripMenuItem TransactionToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem ReportsToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem ChangePasswordToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem ExitToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem CustomerToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem ItemsToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem UtilityToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem UserManagementToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem CompanyInfoToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem ChallanEntryToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem PaymentEntryToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem ExpensesEntryToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem challanReportToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem paymentReportToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem expenseReportToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem SupplierToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem EmployeeToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem AttendanceRegularisationToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem AttendanceEntryToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem LeaveRequestToolStripMenu;
    }
}