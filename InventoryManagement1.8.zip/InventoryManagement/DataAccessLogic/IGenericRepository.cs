﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Security.AccessControl;

namespace InventoryManagement.DataAccessLogic
{
    public interface IGenericRepository<AnyType>
    {
        List<AnyType> GetAll();
        List<AnyType> GetByDates(string strFromDate, string strToDate);
        AnyType GetByID(Int32 ID);
        void Add(AnyType objAnyType);
        void Update(AnyType objAnyType);
        void Delete(Int32 ID);
    }

    public interface iReports
    {
        DataTable PrintChallan();
    }
}