﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using InventoryManagement.BusinessLogic;
using InventoryManagement.DataAccessLogic;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace InventoryManagement
{
    public partial class frmCustomerItems : Form
    {
        string strCustomerItemCode = "";
        CustomerItemModel objCustomerItem = null;
        IGenericRepository<ItemModel> objItemDal = null;
        IGenericRepository<CustomerItemModel> objCustomerItemDal = null;

        public frmCustomerItems(string strCutsomerCode, string strCustomerName)
        {
            InitializeComponent();
            
            lblCustomerCode.Text = strCutsomerCode;
            lblCustomerName.Text = strCustomerName;
        }

        private void frmCustomerItems_Load(object sender, EventArgs e)
        {
            objItemDal = new ItemDAL();
            objCustomerItemDal = new CustomerItemDAL();

            FillDropdowns();
            DisplayData();
            ClearFields();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cboItem.Text.Trim() == "Select")
            {
                cboItem.Focus();
                MessageBox.Show("Please select item.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (txtRate.Text.Trim() == "")
            {
                txtRate.Focus();
                MessageBox.Show("Please enter rate.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                Boolean isValidRate = false;
                try
                {
                    Convert.ToDouble(txtRate.Text.Trim());
                    isValidRate = true;
                }
                catch (Exception)
                {
                    isValidRate = false;
                    txtRate.Select();
                    MessageBox.Show("Rate should be numeric.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }

                if (isValidRate == true)
                {
                    Cursor = Cursors.WaitCursor;
                    objCustomerItem = new CustomerItemModel();
                    objCustomerItem.CustomerCode = lblCustomerCode.Text;
                    objCustomerItem.CustomerName = lblCustomerName.Text;
                    objCustomerItem.ItemCode = Convert.ToString(cboItem.SelectedValue);
                    objCustomerItem.ItemName = cboItem.SelectedText;
                    objCustomerItem.Rate = txtRate.Text.Trim();
                    objCustomerItem.CreatedBy = common.strUserEmail;

                    if (btnSave.Text == "Save")
                    {
                        objCustomerItemDal.Add(objCustomerItem);
                        ClearFields();
                        //MessageBox.Show("Customer Item saved successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        objCustomerItem.Code = Convert.ToInt32(strCustomerItemCode);
                        objCustomerItemDal.Update(objCustomerItem);
                        ClearFields();
                        //MessageBox.Show("Customer Item updated successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    Cursor = Cursors.Default;
                }
            }
        }

        private void FillDropdowns()
        {
            List<ItemModel> lstItem = new List<ItemModel>();
            lstItem = objItemDal.GetAll();

            cboItem.DataSource = lstItem;
            cboItem.DisplayMember = "Name";
            cboItem.ValueMember = "Code";
        }

        private void ClearFields()
        {
            strCustomerItemCode = "";
            cboItem.SelectedIndex = -1;
            txtRate.Text = "";
            btnSave.Text = "Save";
            dgvData.Enabled = true;
            cboItem.Select();
            DisplayData();
        }

        private void DisplayData()
        {
            List<CustomerItemModel> lstAllCustomerItems = objCustomerItemDal.GetAll();
            List<CustomerItemModel> lstCustomerItems = lstAllCustomerItems.Where(x=> x.CustomerCode == lblCustomerCode.Text).ToList();
            
            dgvData.DataSource = lstCustomerItems;
        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (e.ColumnIndex == 0)
                {
                    strCustomerItemCode = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Code"].Value);
                    cboItem.SelectedValue = Convert.ToInt32(dgvData.Rows[e.RowIndex].Cells["ItemCode"].Value);
                    txtRate.Text = Convert.ToString(dgvData.Rows[e.RowIndex].Cells["Rate"].Value);
                    btnSave.Text = "Update";
                    dgvData.Enabled = false;
                    cboItem.Select();
                }
                if (e.ColumnIndex == 1)
                {
                    if (MessageBox.Show("Do you want to delete?", common.strProjectTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        Int32 code = Convert.ToInt32(dgvData.Rows[e.RowIndex].Cells["Code"].Value);
                        objCustomerItemDal.Delete(code);

                        ClearFields();
                        //MessageBox.Show("Customer Item deleted successfully.", common.strProjectTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
