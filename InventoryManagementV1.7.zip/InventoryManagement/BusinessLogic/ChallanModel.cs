﻿using System;
using System.Collections.Generic;

namespace InventoryManagement.BusinessLogic
{
    public class ChallanHeaderModel
    {
        public Int32 ChallanHeaderCode { get; set; }
        public string ChallanNo { get; set; }
        public DateTime ChallanDate { get; set; }
        public Int32 CustomerCode { get; set; }
        public string CustomerName { get; set; }
        public double TotalGST { get; set; }
        public double TotalAmount { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDateTime { get; set; }
        public List<ChallanDetailsModel> ChallanDetails { get; set; }

    }

    public class ChallanDetailsModel
    {
        public Int32 ChallanDetailsCode { get; set; }
        public Int32 ChallanHeaderCode { get; set; }
        public Int32 ItemCode { get; set; }
        public string ItemName { get; set; }
        public string Description { get; set; }
        public double Rate { get; set; }
        public Int32 Qty { get; set; }
        public double GST { get; set; }
        public double Amount { get; set; }
    }
}
