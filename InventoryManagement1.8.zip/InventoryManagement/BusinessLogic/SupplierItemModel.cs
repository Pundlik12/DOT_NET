﻿
namespace InventoryManagement.BusinessLogic
{
    public class SupplierItemModel
    {
        public int Code { get; set; }
        public int SupplierCode { get; set; }
        public string Name { get; set; }
        public string HSNNumber { get; set; }
        public string Rate { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDateTime { get; set; }
    }
}
