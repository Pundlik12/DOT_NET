﻿using IpMesseger;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ChatApp
{
    public partial class frmChatForm : Form
    {
        public delegate void UpdateTextBoxDelegate(string text);
        Thread logReaderThread;

        private ChatClient client;
        private readonly HostService _hostService;

        public frmChatForm()
        {
            InitializeComponent();
            client = new ChatClient("127.0.0.1", 5000);
            _hostService = new HostService("hostinfo.json");
            LoadHosts();
        }

        private void frmChatForm_Load(object sender, EventArgs e)
        {
            string myIPAddress = NetworkInfo.GetHostDetails();
            string[] split_data = myIPAddress.Split('|');
            txtHostName.Text = split_data[0];
            txtIPAddress.Text = split_data[1];

            logReaderThread = new Thread(ReadLogFileContinuously);
            logReaderThread.IsBackground = true;
            logReaderThread.Start();
        }

        private void ReadLogFileContinuously()
        {
            string logPath = @"Log.txt";
            long lastMaxOffset = 0;
            
            Invoke(new UpdateTextBoxDelegate(UpdateTextBox), "");

            while (true)
            {
                if (File.Exists(logPath))
                {
                    using (FileStream fs = new FileStream(logPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        fs.Seek(lastMaxOffset, SeekOrigin.Begin);
                        using (StreamReader sr = new StreamReader(fs))
                        {
                            string newContent = sr.ReadToEnd();
                            lastMaxOffset = fs.Position;

                            if (!string.IsNullOrEmpty(newContent))
                            {
                                Invoke(new UpdateTextBoxDelegate(UpdateTextBox), newContent);
                            }
                        }
                    }
                }

                Thread.Sleep(1000); // Adjust polling interval as needed
            }
        }

        private void UpdateTextBox(string text)
        {
            if (text != "")
            {
                txtChat.AppendText(text + Environment.NewLine);
            }
            else
            {
                txtChat.AppendText(text);
            }
        }

        private async void LoadHosts()
        {
            var hosts = await _hostService.GetHostAsync();
            cboUserName.DataSource = null;
            cboUserName.DataSource = hosts;
            cboUserName.DisplayMember = "UserName";
            cboUserName.ValueMember = "IPAddress";
        }

        private void btnSendMessage_Click(object sender, EventArgs e)
        {
            if (txtMessage.Text.Trim() != string.Empty)
            {
                string message = txtMessage.Text;
                client.serverIp = Convert.ToString(cboUserName.SelectedValue);
                client.UserName = cboUserName.Text;

                if (client.SendMessage(message))
                {
                    string strLog = $"You=> {cboUserName.SelectedValue} [{cboUserName.Text}]:- " + message + Environment.NewLine;
                    var s = _hostService.WriteLog(strLog);
                    txtMessage.Clear();
                }
            }
            else
            {
                txtMessage.Focus();
                MessageBox.Show("Enter the message.", "IP Messeger", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void btnSendFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                client.serverIp = Convert.ToString(cboUserName.SelectedValue);

                if (client.SendFile(dialog.FileName))
                {
                    string strLog = $"You sent file=> {cboUserName.SelectedValue} [{cboUserName.Text}]:- {Path.GetFileName(dialog.FileName)}{Environment.NewLine}";
                    var s = _hostService.WriteLog(strLog);
                    txtChat.AppendText(strLog);
                }                
            }
        }

        private void btnAddIpAddress_Click(object sender, EventArgs e)
        {
            frmAddIPAddress frm = new frmAddIPAddress();
            frm.ShowDialog();
            LoadHosts();
        }

        private void frmChatForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.ExitThread();
            Application.Exit();
        }
    }
}
